from django.conf import settings
from decimal import Decimal
from django.core.validators import MinValueValidator
from django.db import models

from core.models import TimeStampedModel, SoftDeleteModel


class Category(TimeStampedModel, SoftDeleteModel):
    category_name = models.CharField(max_length=100, unique=True, db_index=True)

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ["category_name"]

    def __str__(self):
        return self.category_name


class Product(TimeStampedModel, SoftDeleteModel):
    class ApprovalStatus(models.TextChoices):
        PENDING = "PENDING", "Pending"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"

    class Condition(models.TextChoices):
        NEW = "NEW", "New"
        LIKE_NEW = "LIKE_NEW", "Like New"
        GOOD = "GOOD", "Good"
        FAIR = "FAIR", "Fair"
        USED = "USED", "Used"

    seller = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="products")
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="products", db_index=True)
    product_name = models.CharField(max_length=150, db_index=True)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    condition = models.CharField(max_length=10, choices=Condition.choices, default=Condition.GOOD)
    availability = models.BooleanField(default=True)
    approval_status = models.CharField(
        max_length=10, choices=ApprovalStatus.choices, default=ApprovalStatus.PENDING, db_index=True
    )
    views_count = models.PositiveIntegerField(default=0)
    sold = models.BooleanField(default=False)

    class Meta:
        indexes = [
            models.Index(fields=["product_name"]),
            models.Index(fields=["approval_status"]),
        ]
        ordering = ["-created_at"]

    def __str__(self):
        return self.product_name

    def is_visible(self):
        return self.approval_status == self.ApprovalStatus.APPROVED and self.is_active and not self.is_deleted


def product_image_upload_to(instance, filename):
    import os, uuid
    ext = filename.split(".")[-1]
    return os.path.join("products", f"{uuid.uuid4().hex}.{ext}")


class ProductImage(TimeStampedModel):
    """Up to 5 images per product (JPG/JPEG/PNG/WEBP, max 5MB, validated in forms/serializers)."""
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="images")
    image = models.ImageField(upload_to=product_image_upload_to)
    order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ["order", "created_at"]
