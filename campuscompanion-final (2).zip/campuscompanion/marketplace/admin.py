from django.contrib import admin
from .models import Category, Product, ProductImage


class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("category_name", "is_active")
    search_fields = ("category_name",)


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("product_name", "seller", "category", "price", "approval_status", "sold", "is_active")
    list_filter = ("approval_status", "category", "sold")
    search_fields = ("product_name",)
    inlines = [ProductImageInline]
    actions = ["approve_products", "reject_products"]

    @admin.action(description="Approve selected products")
    def approve_products(self, request, queryset):
        queryset.update(approval_status=Product.ApprovalStatus.APPROVED)

    @admin.action(description="Reject selected products")
    def reject_products(self, request, queryset):
        queryset.update(approval_status=Product.ApprovalStatus.REJECTED)
