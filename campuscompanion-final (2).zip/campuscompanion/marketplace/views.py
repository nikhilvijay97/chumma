from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets, permissions, filters
from rest_framework.decorators import action
from rest_framework.response import Response

from core.permissions import IsApprovedStudent, IsOwnerOrReadOnly
from .models import Category, Product
from .serializers import CategorySerializer, ProductSerializer


class CategoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Category.objects.filter(is_active=True)
    serializer_class = CategorySerializer
    permission_classes = [permissions.AllowAny]


class ProductViewSet(viewsets.ModelViewSet):
    """
    GET /api/products, POST /api/products, PUT/PATCH/DELETE /api/products/{id}
    Search by product name, category, seller, department (PRODUCT WORKFLOW spec).
    """
    serializer_class = ProductSerializer
    permission_classes = [IsApprovedStudent, IsOwnerOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["category", "seller", "seller__department", "condition"]
    search_fields = ["product_name", "description"]
    ordering_fields = ["price", "created_at"]

    def get_queryset(self):
        qs = Product.objects.select_related("seller", "category").filter(is_deleted=False)
        if self.request.user.is_staff:
            return qs
        # Non-staff only see approved+active listings, plus their own.
        from django.db.models import Q
        own_filter = Q()
        if self.request.user.is_authenticated:
            own_filter = Q(seller=self.request.user)
        return qs.filter(Q(approval_status=Product.ApprovalStatus.APPROVED) | own_filter)

    def perform_destroy(self, instance):
        instance.soft_delete()

    @action(detail=True, methods=["post"])
    def mark_sold(self, request, pk=None):
        product = self.get_object()
        if product.seller != request.user:
            return Response({"detail": "Not allowed."}, status=403)
        product.sold = True
        product.availability = False
        product.save(update_fields=["sold", "availability"])
        return Response({"detail": "Marked as sold."})
