from rest_framework import serializers

from core.validators import validate_image_file
from django.conf import settings
from .models import Category, Product, ProductImage


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "category_name"]


class ProductImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImage
        fields = ["id", "image", "order"]


class ProductSerializer(serializers.ModelSerializer):
    images = ProductImageSerializer(many=True, read_only=True)
    uploaded_images = serializers.ListField(
        child=serializers.ImageField(), write_only=True, required=False
    )
    seller_name = serializers.CharField(source="seller.full_name", read_only=True)
    category_name = serializers.CharField(source="category.category_name", read_only=True)

    class Meta:
        model = Product
        fields = [
            "id", "seller", "seller_name", "category", "category_name", "product_name",
            "description", "price", "condition", "availability", "approval_status",
            "sold", "images", "uploaded_images", "created_at",
        ]
        read_only_fields = ["seller", "approval_status", "sold", "created_at"]

    def validate_price(self, value):
        if value <= 0:
            raise serializers.ValidationError("Price cannot be negative or zero.")
        return value

    def validate_uploaded_images(self, files):
        if len(files) > settings.MAX_PRODUCT_IMAGES:
            raise serializers.ValidationError(f"Maximum {settings.MAX_PRODUCT_IMAGES} images allowed.")
        for f in files:
            validate_image_file(f)
        return files

    def create(self, validated_data):
        images = validated_data.pop("uploaded_images", [])
        validated_data["seller"] = self.context["request"].user
        product = Product.objects.create(**validated_data)
        for i, img in enumerate(images):
            ProductImage.objects.create(product=product, image=img, order=i)
        return product
