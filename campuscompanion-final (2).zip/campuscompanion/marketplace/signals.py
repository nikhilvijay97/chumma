from django.db.models.signals import pre_save, post_save
from django.dispatch import receiver

from .models import Product


@receiver(pre_save, sender=Product)
def _stash_old_price(sender, instance, **kwargs):
    if instance.pk:
        try:
            instance._old_price = Product.objects.get(pk=instance.pk).price
        except Product.DoesNotExist:
            instance._old_price = None
    else:
        instance._old_price = None


@receiver(post_save, sender=Product)
def _notify_wishlist_on_price_drop(sender, instance, created, **kwargs):
    if created:
        return
    old_price = getattr(instance, "_old_price", None)
    if old_price is None or instance.price >= old_price:
        return

    from wishlist.models import Wishlist
    from notifications.models import Notification

    for wish in Wishlist.objects.filter(product=instance).select_related("user"):
        Notification.objects.create(
            user=wish.user,
            title="Wishlist Price Drop",
            message=f'"{instance.product_name}" dropped to {instance.price}.',
            notification_type=Notification.NotificationType.INFO,
        )
        wish.last_notified_price = instance.price
        wish.save(update_fields=["last_notified_price"])
