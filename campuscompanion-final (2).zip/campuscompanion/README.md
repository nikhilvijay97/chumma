# Campus Companion — *"Where Students Connect"*

A production-quality Django + MySQL backend for a verified-student marketplace,
rental hub, academic resource-sharing community, and reward system.

## Modules

| App | Responsibility |
|---|---|
| `accounts` | Custom User model, Departments/Semesters/Subjects, registration, login (admission no. or email), admin verification |
| `marketplace` | Categories, Products, images, buy/sell approval workflow |
| `rental` | Rental items, requests, overlap prevention |
| `community` | Shared academic resources (question papers/notes), duplicate-paper prevention |
| `rewards` | Reward engine, contributor levels, redemption |
| `chat` | One-to-one messaging with read receipts |
| `wishlist` | Wishlist + price-drop notifications |
| `notifications` | In-app notification feed |
| `reports` | Report fake/spam/duplicate content |
| `adminpanel` | Admin dashboard, approve student/product/resource |
| `core` | Shared mixins: soft delete, UUID file renaming, audit log |
| `api` | Central URL aggregator mounted at `/api/` |
| `pages` | Frontend Django template views + sidebar/navbar + premium UI |

## Frontend pages (`pages` app)

A complete Django-template-based UI that talks to the REST API in JavaScript.

| Route | Purpose |
|---|---|
| `/` | Landing page (public) |
| `/login/`, `/register/`, `/forgot-password/`, `/reset-password/<token>/` | Auth flows |
| `/dashboard/` | Stats, recent activity, quick actions |
| `/profile/` | View & edit profile (incl. photo) |
| `/marketplace/`, `/marketplace/category/<id>/`, `/marketplace/product/<id>/` | Catalog, filter, details |
| `/rentals/`, `/rentals/<id>/` | List & request rentals, owner request management |
| `/community/` | Browse Resources (Question Papers, Notes, Lab Records) |
| `/upload-product/`, `/upload-rental/`, `/upload-resource/` | Contribute content (with duplicate-qp live check) |
| `/wishlist/` | Saved products |
| `/notifications/` | Activity feed with mark-all-read + light polling |
| `/chat/`, `/chat/<id>/` | Inbox + conversation room |
| `/reports/` | Submit reports & history |
| `/rewards/` | Points, badge, history, redemption |
| `/admin-area/`, `/admin-area/{students,products,resources,rewards,reports}/` | Admin tools (links to Django admin for destructive bulk actions) |

Static assets:
- `static/css/main.css` — premium dark glassmorphism design, fully responsive
- `static/js/app.js` — `CC` client (API + token storage + toasts + skeleton)
- `static/images/favicon.svg`

## Quick start (local / SQLite)

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # edit as needed; leave MySQL vars blank for SQLite
python manage.py migrate
python manage.py seed_demo_data      # 25+ students, 40+ products, etc.
python manage.py runserver
```

Open http://127.0.0.1:8000/ and you'll see the landing page.

Demo admin login: `admin` / `Admin@12345` (created by `seed_demo_data`).
Demo students: `ADM1001` … `ADM1030` / `Password@123`.

## MySQL setup

Set these env vars (see `.env.example`) before running `migrate`:

```
DB_ENGINE=mysql
MYSQL_DATABASE=campuscompanion
MYSQL_USER=...
MYSQL_PASSWORD=...
MYSQL_HOST=...
MYSQL_PORT=3306
```

## Key business rules implemented

- **Soft delete everywhere** (`is_active` / `is_deleted` on Users, Products,
  Rental Items, Shared Resources, Departments, Semesters, Subjects, Categories)
  instead of hard deletes, preserving history for admin investigation/restore.
- **Duplicate Question Paper prevention** — compares Department + Semester +
  Subject + Exam Type + Exam Year against *approved* records only, via
  database fields (never filenames). See `community/models.py` (`is_duplicate_question_paper`)
  and `POST /api/resources/duplicate-check` (returns `409 Conflict`).
- **Reward engine** (`rewards/services.py`) — awards points only after admin
  approval (+50 Question Paper, +80 PDF Notes, +100 Handwritten Notes, +60 Lab
  Record), updates contributor level (Bronze/Silver/Gold/Platinum), writes
  `RewardHistory`, and sends a `Notification`.
- **Rental overlap prevention** — `RentalRequest.clean()` and the serializer
  reject overlapping *accepted* bookings for the same item.
- **Login flow** — students authenticate with Admission Number *or* College
  Email (`accounts/backends.py`); pending/rejected accounts get a friendly
  message instead of a generic auth failure.
- **File validation** — only JPG/JPEG/PNG/WEBP for images, + PDF for resources;
  size caps enforced in `core/validators.py`; all uploads renamed to UUIDs
  (`core/models.py`).
- **Audit log** (`core.AuditLog`) — login/logout, approvals, rejections,
  reward issuance, duplicate rejections; admin-only in Django admin.
- **Role-based access** — `core/permissions.py` (`IsApprovedStudent`,
  `IsOwnerOrReadOnly`, `IsAdminRole`) keeps students out of admin routes.

## API surface (all mounted under `/api/`)

```
POST   /register                     Student registration (Pending until approved)
POST   /login                        Login by Admission Number or Email
POST   /logout
GET    /profile / PATCH /profile

GET    /departments  /semesters  /subjects

GET/POST /products   PUT/PATCH/DELETE /products/{id}
GET/POST /categories

GET/POST /rentals     POST /rental-request
POST     /rental-request/{id}/accept|reject|complete

GET/POST /resources   POST /upload-resource
POST     /resources/duplicate-check   -> 409 if duplicate

GET  /points          POST /redeem

GET  /messages?with=<id>   POST /send-message   DELETE /messages/{id}

GET  /wishlist   POST /wishlist/add   DELETE /wishlist/remove

GET  /notifications   POST /notifications {"mark_all_read": true}

POST /reports

GET  /admin/dashboard
POST /approve-student   POST /approve-product   POST /approve-resource
```

All endpoints (except register/login/category/department/semester/subject
reads) require `Authorization: Token <token>` from the login response.

## Demo data

`python manage.py seed_demo_data` creates 30 students, 45 products, 22 rental
items, 32 question papers, 55 notes, 22 notifications, 16 chat messages, 11
reports, and an admin superuser — enough to exercise every module immediately
after deployment.

## Deployment targets

Designed to run unmodified on:
- **Localhost** (SQLite, `DEBUG=True`)
- **PythonAnywhere / Render / Railway** — set the MySQL env vars + `DJANGO_SECRET_KEY`
  + `DJANGO_DEBUG=False` + `DJANGO_ALLOWED_HOSTS`, then
  `python manage.py migrate && python manage.py collectstatic --noinput`
  and run via `gunicorn campuscompanion.wsgi`. `whitenoise` is included for
  static file serving.

No secrets are hardcoded anywhere — everything is read from environment
variables (`os.environ`) in `campuscompanion/settings.py`.
