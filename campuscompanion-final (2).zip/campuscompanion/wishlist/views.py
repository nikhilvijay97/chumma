from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Wishlist
from .serializers import WishlistSerializer


class WishlistListView(APIView):
    """GET /api/wishlist"""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        qs = Wishlist.objects.filter(user=request.user).select_related("product")
        return Response(WishlistSerializer(qs, many=True).data)


class WishlistAddView(APIView):
    """POST /api/wishlist/add — { product }"""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = WishlistSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        _, created = Wishlist.objects.get_or_create(
            user=request.user, product_id=request.data.get("product"),
        )
        return Response({"detail": "Added to wishlist." if created else "Already in wishlist."},
                         status=status.HTTP_201_CREATED)


class WishlistRemoveView(APIView):
    """DELETE /api/wishlist/remove — { product }"""
    permission_classes = [permissions.IsAuthenticated]

    def delete(self, request):
        deleted, _ = Wishlist.objects.filter(user=request.user, product_id=request.data.get("product")).delete()
        return Response({"detail": "Removed." if deleted else "Not in wishlist."})
