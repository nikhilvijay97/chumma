"""
Central API aggregator — mounts every module's endpoints under /api/.
"""
from django.urls import path, include

urlpatterns = [
    path("", include("accounts.urls")),
    path("", include("marketplace.urls")),
    path("", include("rental.urls")),
    path("", include("community.urls")),
    path("", include("rewards.urls")),
    path("", include("chat.urls")),
    path("", include("wishlist.urls")),
    path("", include("notifications.urls")),
    path("", include("reports.urls")),
    path("", include("adminpanel.urls")),
]
