from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Notification
from .serializers import NotificationSerializer


class NotificationListView(APIView):
    """GET /api/notifications — includes unread_count; supports ?mark_all_read=1"""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        qs = Notification.objects.filter(user=request.user)
        unread_count = qs.filter(is_read=False).count()
        return Response({
            "unread_count": unread_count,
            "results": NotificationSerializer(qs[:100], many=True).data,
        })

    def post(self, request):
        if request.data.get("mark_all_read"):
            Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
            return Response({"detail": "All notifications marked as read."})
        return Response({"detail": "No action taken."}, status=400)
