from django.db.models import Count, Q
from django.utils import timezone
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.models import User
from core.models import AuditLog
from community.models import SharedResource
from marketplace.models import Product
from rental.models import RentalItem
from reports.models import Report
from rewards.models import RewardRedemption
from rewards.services import DuplicateQuestionPaperError, approve_shared_resource


class IsStaffOnly(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_staff)


class DashboardView(APIView):
    """GET /api/admin/dashboard — cards + basic chart data."""
    permission_classes = [IsStaffOnly]

    def get(self, request):
        data = {
            "cards": {
                "total_students": User.objects.filter(is_deleted=False).count(),
                "approved_students": User.objects.filter(status=User.Status.APPROVED).count(),
                "pending_students": User.objects.filter(status=User.Status.PENDING).count(),
                "marketplace_products": Product.objects.filter(is_deleted=False).count(),
                "pending_products": Product.objects.filter(approval_status=Product.ApprovalStatus.PENDING).count(),
                "rental_items": RentalItem.objects.filter(is_deleted=False).count(),
                "resources": SharedResource.objects.filter(is_deleted=False).count(),
                "pending_resources": SharedResource.objects.filter(
                    approval_status=SharedResource.ApprovalStatus.PENDING
                ).count(),
                "reward_requests": RewardRedemption.objects.filter(status=RewardRedemption.Status.PENDING).count(),
                "reports": Report.objects.filter(status=Report.Status.OPEN).count(),
            },
            "charts": {
                "popular_categories": list(
                    Product.objects.filter(approval_status=Product.ApprovalStatus.APPROVED)
                    .values("category__category_name").annotate(total=Count("id")).order_by("-total")[:10]
                ),
                "most_active_students": list(
                    User.objects.filter(status=User.Status.APPROVED)
                    .order_by("-reward_points").values("full_name", "reward_points")[:10]
                ),
            },
            "latest_activities": list(
                AuditLog.objects.order_by("-created_at").values("action", "description", "created_at")[:20]
            ),
        }
        return Response(data)


class ApproveStudentView(APIView):
    permission_classes = [IsStaffOnly]

    def post(self, request):
        user = User.objects.filter(pk=request.data.get("user_id")).first()
        if not user:
            return Response({"detail": "Student not found."}, status=status.HTTP_404_NOT_FOUND)
        action = request.data.get("action", "approve")
        if action == "approve":
            user.status = User.Status.APPROVED
            user.is_active = True
            user.save(update_fields=["status", "is_active"])
            from notifications.models import Notification
            Notification.objects.create(
                user=user, title="Registration Approved",
                message="Your account has been verified. You can now log in.",
                notification_type=Notification.NotificationType.SUCCESS,
            )
            AuditLog.objects.create(actor=request.user, action="STUDENT_VERIFICATION",
                                     description=f"Approved {user.admission_number}")
        else:
            user.status = User.Status.REJECTED
            user.rejection_reason = request.data.get("reason", "")
            user.save(update_fields=["status", "rejection_reason"])
            AuditLog.objects.create(actor=request.user, action="STUDENT_VERIFICATION",
                                     description=f"Rejected {user.admission_number}")
        return Response({"detail": f"Student {action}d."})


class ApproveProductView(APIView):
    permission_classes = [IsStaffOnly]

    def post(self, request):
        product = Product.objects.filter(pk=request.data.get("product_id")).first()
        if not product:
            return Response({"detail": "Product not found."}, status=status.HTTP_404_NOT_FOUND)
        action = request.data.get("action", "approve")
        product.approval_status = Product.ApprovalStatus.APPROVED if action == "approve" else Product.ApprovalStatus.REJECTED
        product.save(update_fields=["approval_status"])
        from notifications.models import Notification
        if action == "approve":
            Notification.objects.create(
                user=product.seller, title="Product Approved",
                message=f'"{product.product_name}" is now visible in the Marketplace.',
                notification_type=Notification.NotificationType.SUCCESS,
            )
        AuditLog.objects.create(
            actor=request.user,
            action="PRODUCT_APPROVAL" if action == "approve" else "PRODUCT_REJECTION",
            description=f"{action} product {product.product_name} (id={product.pk})",
        )
        return Response({"detail": f"Product {action}d."})


class ApproveResourceView(APIView):
    permission_classes = [IsStaffOnly]

    def post(self, request):
        resource = SharedResource.objects.filter(pk=request.data.get("resource_id")).first()
        if not resource:
            return Response({"detail": "Resource not found."}, status=status.HTTP_404_NOT_FOUND)
        action = request.data.get("action", "approve")
        if action == "approve":
            try:
                points = approve_shared_resource(resource, admin_user=request.user)
            except DuplicateQuestionPaperError as exc:
                return Response({"detail": str(exc)}, status=status.HTTP_409_CONFLICT)
            return Response({"detail": f"Resource approved. +{points} points awarded."})
        else:
            resource.approval_status = SharedResource.ApprovalStatus.REJECTED
            resource.save(update_fields=["approval_status"])
            AuditLog.objects.create(actor=request.user, action="RESOURCE_REJECTION",
                                     description=f"Rejected resource {resource.title} (id={resource.pk})")
            return Response({"detail": "Resource rejected."})
