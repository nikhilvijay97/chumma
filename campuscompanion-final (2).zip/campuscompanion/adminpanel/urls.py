from django.urls import path

from .views import DashboardView, ApproveStudentView, ApproveProductView, ApproveResourceView

urlpatterns = [
    path("admin/dashboard", DashboardView.as_view(), name="admin-dashboard"),
    path("approve-student", ApproveStudentView.as_view(), name="approve-student"),
    path("approve-product", ApproveProductView.as_view(), name="approve-product"),
    path("approve-resource", ApproveResourceView.as_view(), name="approve-resource"),
]
