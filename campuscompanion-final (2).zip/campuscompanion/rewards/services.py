"""
Reward Engine — awards points when a SharedResource is approved, updates the
user's total points and contributor badge, logs history, and fires a
notification. Called explicitly by the admin-approval view/action rather than
via a signal, so it only ever runs once per approval and can return errors
to the caller (e.g. duplicate question paper rejection).
"""
from django.db import transaction

from .models import RewardHistory, REWARD_POINTS_MAP


class DuplicateQuestionPaperError(Exception):
    """Raised when an approved Question Paper with the same combination exists."""
    pass


@transaction.atomic
def approve_shared_resource(resource, admin_user=None):
    """
    Approve a SharedResource: run duplicate check (question papers only),
    award points, update contributor level, log history + audit, notify user.
    """
    from community.models import SharedResource
    from notifications.models import Notification
    from core.models import AuditLog

    if resource.is_duplicate_question_paper():
        resource.approval_status = SharedResource.ApprovalStatus.REJECTED
        resource.save(update_fields=["approval_status"])
        AuditLog.objects.create(
            actor=admin_user,
            action="DUPLICATE_REJECTION",
            description=f"Duplicate question paper rejected: {resource.title} (id={resource.pk})",
        )
        raise DuplicateQuestionPaperError("This question paper is already available.")

    points = REWARD_POINTS_MAP.get(resource.resource_type, 0)

    resource.approval_status = SharedResource.ApprovalStatus.APPROVED
    resource.reward_points_awarded = points
    resource.save(update_fields=["approval_status", "reward_points_awarded"])

    user = resource.uploader
    user.reward_points = models_f(user.reward_points) + points
    user.save(update_fields=["reward_points"])
    user.update_contributor_level(save=True)

    RewardHistory.objects.create(
        user=user,
        resource=resource,
        points=points,
        reason=resource.get_resource_type_display(),
    )

    Notification.objects.create(
        user=user,
        title="Resource Approved",
        message=f'Your "{resource.title}" was approved. +{points} points awarded.',
        notification_type=Notification.NotificationType.SUCCESS,
    )

    AuditLog.objects.create(
        actor=admin_user,
        action="RESOURCE_APPROVAL",
        description=f"Approved resource {resource.title} (id={resource.pk}), +{points} pts to {user}",
    )
    return points


def models_f(value):
    """Small helper kept separate so reward point math stays in one place."""
    return value


@transaction.atomic
def redeem_points(user, requested_points, reward_type):
    from .models import RewardRedemption

    if requested_points <= 0:
        raise ValueError("requested_points must be positive.")
    if requested_points > user.reward_points:
        raise ValueError("Not enough reward points.")

    user.reward_points -= requested_points
    user.save(update_fields=["reward_points"])
    user.update_contributor_level(save=True)

    redemption = RewardRedemption.objects.create(
        user=user,
        requested_points=requested_points,
        reward_type=reward_type,
        status=RewardRedemption.Status.PENDING,
    )
    return redemption
