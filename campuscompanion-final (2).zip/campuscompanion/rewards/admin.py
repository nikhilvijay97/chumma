from django.contrib import admin
from .models import RewardHistory, RewardRedemption


@admin.register(RewardHistory)
class RewardHistoryAdmin(admin.ModelAdmin):
    list_display = ("user", "points", "reason", "date")
    search_fields = ("user__admission_number",)


@admin.register(RewardRedemption)
class RewardRedemptionAdmin(admin.ModelAdmin):
    list_display = ("user", "requested_points", "reward_type", "status", "date")
    list_filter = ("status",)
    actions = ["approve_redemption", "reject_redemption"]

    @admin.action(description="Approve selected redemptions")
    def approve_redemption(self, request, queryset):
        queryset.update(status=RewardRedemption.Status.APPROVED)

    @admin.action(description="Reject selected redemptions")
    def reject_redemption(self, request, queryset):
        queryset.update(status=RewardRedemption.Status.REJECTED)
