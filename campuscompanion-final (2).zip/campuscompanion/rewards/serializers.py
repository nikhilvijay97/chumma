from rest_framework import serializers

from .models import RewardHistory, RewardRedemption


class RewardHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = RewardHistory
        fields = ["id", "resource", "points", "reason", "date"]


class RewardRedemptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = RewardRedemption
        fields = ["id", "requested_points", "reward_type", "status", "date"]
        read_only_fields = ["status", "date"]


class PointsSummarySerializer(serializers.Serializer):
    reward_points = serializers.IntegerField()
    contributor_level = serializers.CharField()
    history = RewardHistorySerializer(many=True)
