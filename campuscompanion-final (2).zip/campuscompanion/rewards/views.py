from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import RewardHistory
from .serializers import PointsSummarySerializer, RewardRedemptionSerializer
from .services import redeem_points


class PointsView(APIView):
    """GET /api/points — current points, badge, and history."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        history = RewardHistory.objects.filter(user=user)[:50]
        data = {
            "reward_points": user.reward_points,
            "contributor_level": user.contributor_level,
            "history": history,
        }
        return Response(PointsSummarySerializer(data).data)


class RedeemView(APIView):
    """POST /api/redeem — { requested_points, reward_type }"""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = RewardRedemptionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            redemption = redeem_points(
                request.user,
                serializer.validated_data["requested_points"],
                serializer.validated_data["reward_type"],
            )
        except ValueError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(RewardRedemptionSerializer(redemption).data, status=status.HTTP_201_CREATED)
