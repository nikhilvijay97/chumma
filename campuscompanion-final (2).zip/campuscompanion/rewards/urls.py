from django.urls import path

from .views import PointsView, RedeemView

urlpatterns = [
    path("points", PointsView.as_view(), name="points"),
    path("redeem", RedeemView.as_view(), name="redeem"),
]
