from django.conf import settings
from django.db import models

from core.models import TimeStampedModel
from community.models import SharedResource

# Reward points by resource type — used by the reward engine.
REWARD_POINTS_MAP = {
    SharedResource.ResourceType.QUESTION_PAPER: 50,
    SharedResource.ResourceType.PDF_NOTES: 80,
    SharedResource.ResourceType.HANDWRITTEN_NOTES: 100,
    SharedResource.ResourceType.LAB_RECORD: 60,
}


class RewardHistory(TimeStampedModel):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="reward_history")
    resource = models.ForeignKey(
        SharedResource, on_delete=models.SET_NULL, null=True, blank=True, related_name="reward_entries"
    )
    points = models.IntegerField()
    reason = models.CharField(max_length=255)
    date = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date"]

    def __str__(self):
        return f"{self.user}: {self.points} pts ({self.reason})"


class RewardRedemption(TimeStampedModel):
    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="redemptions")
    requested_points = models.PositiveIntegerField()
    reward_type = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING, db_index=True)
    date = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date"]

    def __str__(self):
        return f"{self.user}: {self.reward_type} ({self.status})"
