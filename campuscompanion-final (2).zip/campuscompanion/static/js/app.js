/* =================================================================
   Campus Companion — Frontend SPA helper
   Re-uses the REST API. Token retrieved from localStorage or cookie.
   ================================================================= */
(function (global) {
  const TOKEN_KEY = "cc_token";
  const USER_KEY  = "cc_user";

  // ---- Storage helpers --------------------------------------------------
  const storage = {
    get_token() {
      try { return localStorage.getItem(TOKEN_KEY) || ""; } catch (e) { return ""; }
    },
    set_token(t) {
      try { localStorage.setItem(TOKEN_KEY, t); } catch (e) {}
    },
    clear_token() {
      try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); } catch (e) {}
    },
    get_user() {
      try { return JSON.parse(localStorage.getItem(USER_KEY) || "null"); } catch (e) { return null; }
    },
    set_user(u) { try { localStorage.setItem(USER_KEY, JSON.stringify(u)); } catch (e) {} },
  };

  // ---- Cookies (CSRF) ---------------------------------------------------
  function getCookie(name) {
    const m = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
    return m ? decodeURIComponent(m[1]) : "";
  }

  // ---- API client -------------------------------------------------------
  async function api(path, opts = {}) {
    const headers = Object.assign({ Accept: "application/json" }, opts.headers || {});
    const token = storage.get_token();
    if (token) headers["Authorization"] = "Token " + token;

    let body = opts.body;
    if (body && !(body instanceof FormData) && typeof body !== "string") {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(body);
    } else if (body instanceof FormData) {
      headers["X-CSRFToken"] = getCookie("csrftoken");
    }

    // For unsafe methods add CSRF header
    const m = (opts.method || "GET").toUpperCase();
    if (!["GET", "HEAD", "OPTIONS"].includes(m) && !(body instanceof FormData)) {
      headers["X-CSRFToken"] = getCookie("csrftoken");
    }

    const res = await fetch(path, { method: m, headers, body, credentials: "same-origin" });
    let data = null;
    const ct = res.headers.get("Content-Type") || "";
    if (ct.includes("application/json")) data = await res.json().catch(() => null);
    else data = await res.text().catch(() => null);

    if (!res.ok) {
      const detail = (data && (data.detail || JSON.stringify(data))) || res.statusText;
      const err = new Error(detail);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  // ---- Auth helpers -----------------------------------------------------
  async function login(identifier, password) {
    const res = await api("/api/login", { method: "POST", body: { username: identifier, password } });
    if (res && res.token) {
      storage.set_token(res.token);
      storage.set_user(res.user);
    }
    return res;
  }
  async function logout() {
    try { await api("/api/logout", { method: "POST" }); } catch (e) {}
    storage.clear_token();
  }

  async function fetchProfile() {
    const res = await api("/api/profile");
    storage.set_user(res);
    return res;
  }

  // ---- Toasts -----------------------------------------------------------
  function ensure_toast_host() {
    let host = document.querySelector(".toast-host");
    if (!host) {
      host = document.createElement("div");
      host.className = "toast-host";
      document.body.appendChild(host);
    }
    return host;
  }
  function toast(message, kind = "info", title = "") {
    const host = ensure_toast_host();
    const el = document.createElement("div");
    el.className = "toast " + kind;
    el.innerHTML = `
      <div>
        ${title ? `<div class="title">${escapeHtml(title)}</div>` : ""}
        <div class="msg">${escapeHtml(message)}</div>
      </div>
      <div class="close" aria-label="Close">&times;</div>`;
    host.appendChild(el);
    el.querySelector(".close").onclick = () => el.remove();
    setTimeout(() => { el.style.opacity = "0"; el.style.transform = "translateX(20px)"; }, 3500);
    setTimeout(() => el.remove(), 4200);
  }

  // ---- Render helpers ---------------------------------------------------
  function escapeHtml(s) {
    if (s == null) return "";
    return String(s).replace(/[&<>"']/g, c => (
      { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
    ));
  }
  function badge(text, kind = "") { return `<span class="badge ${kind}">${escapeHtml(text)}</span>`; }
  function format_money(v) {
    if (v == null || v === "") return "";
    return "₹" + Number(v).toLocaleString();
  }
  function initials(name) {
    if (!name) return "U";
    return name.split(/\s+/).slice(0, 2).map(s => s[0] || "").join("").toUpperCase() || "U";
  }
  function image_for(src, fallback_text = "Image") {
    if (src) return `<img src="${src}" alt="" loading="lazy" onerror="this.outerHTML='<div class=ph>' + (this.alt || 'Image') + '</div>'">`;
    return `<div class="ph">${escapeHtml(fallback_text)}</div>`;
  }
  function asp_money_or_free(v) { return v == null ? "" : format_money(v); }
  function relative_time(iso) {
    try {
      const d = new Date(iso);
      const diff = (Date.now() - d.getTime()) / 1000;
      if (diff < 60)   return "just now";
      if (diff < 3600) return Math.floor(diff / 60) + "m ago";
      if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
      return Math.floor(diff / 86400) + "d ago";
    } catch (e) { return ""; }
  }

  // ---- Skeleton ---------------------------------------------------------
  function skeleton_count(n) { return Array.from({ length: n }, () => '<div class="card"><div class="skeleton" style="aspect-ratio: 4/3"></div></div>').join(""); }

  // ---- Form helpers -----------------------------------------------------
  function read_form(form) {
    const data = {};
    Array.from(form.querySelectorAll("input,select,textarea")).forEach(el => {
      if (!el.name) return;
      if (el.type === "file") return; // handled separately
      if (el.type === "checkbox") { data[el.name] = el.checked; return; }
      data[el.name] = el.value;
    });
    return data;
  }
  function read_files(form, fields) {
    const fd = new FormData();
    Array.from(form.querySelectorAll("input,select,textarea")).forEach(el => {
      if (!el.name) return;
      if (el.type === "file") {
        if (el.files && el.files.length) {
          for (const f of el.files) fd.append(el.name, f);
        }
      } else {
        fd.append(el.name, el.value);
      }
    });
    return fd;
  }
  function fill_form(form, data) {
    if (!form || !data) return;
    Object.keys(data).forEach(k => {
      const el = form.elements[k];
      if (!el) return;
      if (el.type === "checkbox") el.checked = !!data[k]; else el.value = data[k] == null ? "" : data[k];
    });
  }

  // ---- Sidebar / nav active state --------------------------------------
  function set_active_nav() {
    const path = (location.pathname || "/").replace(/\/+$/, "/");
    document.querySelectorAll("[data-nav], .sidebar a, .navbar .nav-links a").forEach(a => {
      const target = a.getAttribute("href") || a.dataset.nav || "";
      if (!target) return;
      if (target === path || (target !== "/" && path.startsWith(target))) {
        a.classList.add("active");
      }
    });
  }

  // ---- Sidebar toggle (mobile) -----------------------------------------
  function bind_sidebar_toggle() {
    const sb = document.querySelector(".sidebar");
    const bd = document.querySelector(".sidebar-backdrop");
    const tg = document.querySelector(".nav-toggle");
    if (!sb) return;
    const open = () => { sb.classList.add("open"); bd && bd.classList.add("open"); document.body.classList.add("no-scroll"); };
    const close = () => { sb.classList.remove("open"); bd && bd.classList.remove("open"); document.body.classList.remove("no-scroll"); };
    tg && tg.addEventListener("click", e => { e.preventDefault(); sb.classList.contains("open") ? close() : open(); });
    bd && bd.addEventListener("click", close);
    document.querySelectorAll(".sidebar a").forEach(a => a.addEventListener("click", close));
  }

  // ---- Logout button ----------------------------------------------------
  function bind_logout_buttons() {
    document.querySelectorAll("[data-action=logout]").forEach(b => {
      b.addEventListener("click", async e => {
        e.preventDefault();
        try { await logout(); } finally { window.location.href = "/"; }
      });
    });
  }

  // ---- Image fallback onerror ------------------------------------------
  function attach_img_fallbacks(root = document) {
    root.querySelectorAll("img[data-fallback]").forEach(img => {
      img.onerror = () => {
        const fb = img.dataset.fallback || "Image";
        img.outerHTML = '<div class="ph">' + fb + '</div>';
      };
    });
  }

  // ---- Boot ------------------------------------------------------------
  function boot() {
    set_active_nav();
    bind_sidebar_toggle();
    bind_logout_buttons();
    attach_img_fallbacks(document);
  }
  document.addEventListener("DOMContentLoaded", boot);

  // Export
  global.CC = {
    api, storage, login, logout, fetchProfile,
    toast, escapeHtml, badge, format_money, initials, image_for,
    relative_time, read_form, read_files, fill_form, skeleton_count,
  };
})(window);
