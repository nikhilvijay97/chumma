from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsApprovedStudent(BasePermission):
    """Only verified (Approved) students may create/update content."""
    message = "Only verified students can perform this action."

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return True
        return bool(request.user and request.user.is_authenticated and request.user.is_approved())


class IsOwnerOrReadOnly(BasePermission):
    owner_field = "seller"

    def has_object_permission(self, request, view, obj):
        if request.method in SAFE_METHODS:
            return True
        owner = getattr(obj, self.owner_field, None) or getattr(obj, "owner", None) or getattr(obj, "uploader", None)
        return owner == request.user


class IsAdminRole(BasePermission):
    """Students cannot access admin routes."""
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_staff)
