import uuid
import os
from django.db import models


def _rename_with_uuid(subfolder, filename):
    ext = filename.split('.')[-1]
    new_name = f"{uuid.uuid4().hex}.{ext}"
    return os.path.join(subfolder, new_name)


def profile_upload_to(instance, filename):
    return _rename_with_uuid("profile", filename)


def student_id_upload_to(instance, filename):
    return _rename_with_uuid("student_ids", filename)


def resources_upload_to(instance, filename):
    return _rename_with_uuid("resources", filename)


def chat_upload_to(instance, filename):
    return _rename_with_uuid("chat", filename)


class TimeStampedModel(models.Model):
    """Abstract base with created_at / updated_at."""
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class SoftDeleteQuerySet(models.QuerySet):
    def alive(self):
        return self.filter(is_deleted=False)

    def dead(self):
        return self.filter(is_deleted=True)


class SoftDeleteManager(models.Manager):
    """Default manager returns only non-deleted rows."""
    def get_queryset(self):
        return SoftDeleteQuerySet(self.model, using=self._db).filter(is_deleted=False)


class AllObjectsManager(models.Manager):
    """Manager that returns everything, including soft-deleted rows (for admin/audit)."""
    def get_queryset(self):
        return SoftDeleteQuerySet(self.model, using=self._db)


class SoftDeleteModel(models.Model):
    """
    Abstract base implementing soft delete (is_active / is_deleted) instead of
    permanently removing rows. Preserves history and allows restoration.
    """
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    objects = SoftDeleteManager()
    all_objects = AllObjectsManager()

    class Meta:
        abstract = True

    def soft_delete(self):
        from django.utils import timezone
        self.is_deleted = True
        self.is_active = False
        self.deleted_at = timezone.now()
        self.save(update_fields=["is_deleted", "is_active", "deleted_at"])

    def restore(self):
        self.is_deleted = False
        self.is_active = True
        self.deleted_at = None
        self.save(update_fields=["is_deleted", "is_active", "deleted_at"])


class AuditLog(TimeStampedModel):
    """
    Central audit log for security-sensitive / admin actions.
    Accessible only by Admin (enforced at the view/permission layer).
    """
    ACTION_CHOICES = [
        ("LOGIN", "Login"),
        ("LOGOUT", "Logout"),
        ("ADMIN_LOGIN", "Admin Login"),
        ("STUDENT_VERIFICATION", "Student Verification"),
        ("PRODUCT_APPROVAL", "Product Approval"),
        ("PRODUCT_REJECTION", "Product Rejection"),
        ("RESOURCE_APPROVAL", "Resource Approval"),
        ("RESOURCE_REJECTION", "Resource Rejection"),
        ("DUPLICATE_REJECTION", "Duplicate Rejection"),
        ("REWARD_ISSUED", "Reward Issued"),
        ("REWARD_REDEEMED", "Reward Redeemed"),
        ("REPORT_ACTION", "Report Action"),
        ("ACCOUNT_SUSPENDED", "Account Suspended"),
        ("ACCOUNT_RESTORED", "Account Restored"),
        ("OTHER", "Other"),
    ]

    actor = models.ForeignKey(
        "accounts.User", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="audit_logs"
    )
    action = models.CharField(max_length=40, choices=ACTION_CHOICES)
    description = models.TextField(blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["action", "created_at"])]

    def __str__(self):
        return f"{self.action} by {self.actor} at {self.created_at}"
