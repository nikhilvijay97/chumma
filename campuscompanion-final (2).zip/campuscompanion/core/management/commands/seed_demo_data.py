"""
Populate the database with demo data so the app can be tested immediately
after deployment: 25+ students, 40+ products, 20+ rental items,
30+ question papers, 50+ notes, 20+ notifications, 15+ chats, 10+ reports.

Usage: python manage.py seed_demo_data
"""
import random
from datetime import timedelta

from django.core.files.base import ContentFile
from django.core.management.base import BaseCommand
from django.utils import timezone

from accounts.models import Department, Semester, Subject, User
from marketplace.models import Category, Product
from rental.models import RentalItem, RentalRequest
from community.models import SharedResource
from notifications.models import Notification
from chat.models import Message
from reports.models import Report

FAKE_FILE = ContentFile(b"Demo file content", name="demo.pdf")


def fake_image(name="demo.jpg"):
    return ContentFile(
        b"\x47\x49\x46\x38\x39\x61\x01\x00\x01\x00\x80\x00\x00\x00\x00\x00\xff\xff\xff!\xf9\x04\x01\x00\x00\x00\x00,"
        b"\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;",
        name=name,
    )


class Command(BaseCommand):
    help = "Seed Campus Companion with realistic demo data."

    def handle(self, *args, **options):
        self.stdout.write("Seeding demo data...")

        departments = {}
        for name in ["MCA", "BTech CSE", "MBA", "BCom"]:
            departments[name], _ = Department.objects.get_or_create(department_name=name)

        semesters = []
        for dep in departments.values():
            for i in range(1, 5):
                sem, _ = Semester.objects.get_or_create(department=dep, semester_name=f"Semester {i}")
                semesters.append(sem)

        subject_names = ["ADBMS", "Cryptography", "Machine Learning", "Operating Systems", "Computer Networks"]
        subjects = []
        for sem in semesters:
            for sname in random.sample(subject_names, 2):
                subj, _ = Subject.objects.get_or_create(semester=sem, subject_name=sname, subject_code=sname[:4].upper())
                subjects.append(subj)

        categories = {}
        for name in ["Books", "Electronics", "Calculator", "Laptop", "Furniture", "Lab Equipment"]:
            categories[name], _ = Category.objects.get_or_create(category_name=name)

        students = []
        for i in range(1, 31):
            adm = f"ADM{1000 + i}"
            if User.objects.filter(admission_number=adm).exists():
                students.append(User.objects.get(admission_number=adm))
                continue
            user = User.objects.create_user(
                username=adm,
                admission_number=adm,
                college_email=f"student{i}@campus.edu",
                full_name=f"Student {i}",
                phone_number=f"9{random.randint(100000000, 999999999)}",
                password="Password@123",
                department=random.choice(list(departments.values())),
                semester=random.choice(semesters),
                status=User.Status.APPROVED,
                is_active=True,
            )
            students.append(user)

        self.stdout.write(f"Created/loaded {len(students)} students.")

        # Products
        product_count = Product.objects.count()
        for i in range(max(0, 45 - product_count)):
            Product.objects.create(
                seller=random.choice(students),
                category=random.choice(list(categories.values())),
                product_name=f"Demo Product {i+1}",
                description="Good condition, barely used. Great for students.",
                price=random.randint(100, 5000),
                condition=random.choice(list(Product.Condition.values)),
                approval_status=random.choice(
                    [Product.ApprovalStatus.APPROVED] * 3 + [Product.ApprovalStatus.PENDING]
                ),
            )

        # Rental items
        for i in range(max(0, 22 - RentalItem.objects.count())):
            RentalItem.objects.create(
                owner=random.choice(students),
                category=random.choice(list(categories.values())),
                item_name=f"Rental Item {i+1}",
                description="Available for short-term rent.",
                rent_price=random.randint(50, 500),
                deposit=random.randint(100, 1000),
                available_from=timezone.now().date(),
                available_until=timezone.now().date() + timedelta(days=60),
                approval_status=RentalItem.ApprovalStatus.APPROVED,
            )

        # Question papers (30+) & notes (50+)
        exam_types = ["Mid Semester", "End Semester", "Internal Assessment"]
        qp_count = SharedResource.objects.filter(resource_type=SharedResource.ResourceType.QUESTION_PAPER).count()
        for i in range(max(0, 32 - qp_count)):
            subj = random.choice(subjects)
            SharedResource.objects.create(
                uploader=random.choice(students),
                department=subj.semester.department,
                semester=subj.semester,
                subject=subj,
                resource_type=SharedResource.ResourceType.QUESTION_PAPER,
                title=f"{subj.subject_name} Question Paper {i+1}",
                exam_type=random.choice(exam_types),
                exam_year=random.randint(2021, 2025),
                file_path=FAKE_FILE,
                approval_status=SharedResource.ApprovalStatus.APPROVED,
            )

        notes_count = SharedResource.objects.exclude(resource_type=SharedResource.ResourceType.QUESTION_PAPER).count()
        note_types = [SharedResource.ResourceType.PDF_NOTES, SharedResource.ResourceType.HANDWRITTEN_NOTES,
                      SharedResource.ResourceType.LAB_RECORD]
        for i in range(max(0, 55 - notes_count)):
            subj = random.choice(subjects)
            SharedResource.objects.create(
                uploader=random.choice(students),
                department=subj.semester.department,
                semester=subj.semester,
                subject=subj,
                resource_type=random.choice(note_types),
                title=f"{subj.subject_name} Notes {i+1}",
                file_path=FAKE_FILE,
                approval_status=SharedResource.ApprovalStatus.APPROVED,
            )

        # Notifications
        for i in range(max(0, 22 - Notification.objects.count())):
            Notification.objects.create(
                user=random.choice(students),
                title="Demo Notification",
                message="This is a sample notification for testing.",
                notification_type=random.choice(list(Notification.NotificationType.values)),
            )

        # Chats
        for i in range(max(0, 16 - Message.objects.count())):
            sender, receiver = random.sample(students, 2)
            Message.objects.create(sender=sender, receiver=receiver, message=f"Hi, is this still available? ({i+1})")

        # Reports
        approved_products = list(Product.objects.filter(approval_status=Product.ApprovalStatus.APPROVED))
        for i in range(max(0, 11 - Report.objects.count())):
            if not approved_products:
                break
            Report.objects.create(
                reporter=random.choice(students),
                product=random.choice(approved_products),
                reason=random.choice(list(Report.Reason.values)),
                details="Reported via demo seed script.",
            )

        # Admin superuser
        if not User.objects.filter(is_superuser=True).exists():
            User.objects.create_superuser(
                username="admin", admission_number="ADMIN001", college_email="admin@campus.edu",
                full_name="Campus Admin", phone_number="9000000000", password="Admin@12345",
                status=User.Status.APPROVED,
            )
            self.stdout.write(self.style.SUCCESS("Created superuser 'admin' / Admin@12345"))

        self.stdout.write(self.style.SUCCESS("Demo data seeding complete."))
