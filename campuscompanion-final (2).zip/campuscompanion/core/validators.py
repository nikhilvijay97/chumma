import os
from django.conf import settings
from django.core.exceptions import ValidationError


def validate_image_file(uploaded_file):
    ext = os.path.splitext(uploaded_file.name)[1].lower()
    if ext not in settings.ALLOWED_IMAGE_EXTENSIONS:
        raise ValidationError(f"Unsupported file type '{ext}'. Allowed: JPG, JPEG, PNG, WEBP.")
    max_bytes = settings.MAX_IMAGE_UPLOAD_SIZE_MB * 1024 * 1024
    if uploaded_file.size > max_bytes:
        raise ValidationError(f"File too large. Maximum size is {settings.MAX_IMAGE_UPLOAD_SIZE_MB} MB.")


def validate_resource_file(uploaded_file):
    ext = os.path.splitext(uploaded_file.name)[1].lower()
    if ext not in settings.ALLOWED_DOCUMENT_EXTENSIONS:
        raise ValidationError("Only PDF and image files (JPG, JPEG, PNG, WEBP) are allowed.")
    max_bytes = settings.MAX_RESOURCE_UPLOAD_SIZE_MB * 1024 * 1024
    if uploaded_file.size > max_bytes:
        raise ValidationError(f"File too large. Maximum size is {settings.MAX_RESOURCE_UPLOAD_SIZE_MB} MB.")


def validate_phone_number(value):
    import re
    if not re.match(r"^\+?\d{7,15}$", value):
        raise ValidationError("Enter a valid phone number.")
