from django.contrib.auth import authenticate
from rest_framework import serializers

from core.validators import validate_image_file
from .models import User, Department, Semester, Subject


class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ["id", "department_name"]


class SemesterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Semester
        fields = ["id", "department", "semester_name"]


class SubjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subject
        fields = ["id", "semester", "subject_name", "subject_code"]


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)
    student_id_card = serializers.ImageField(required=True)

    class Meta:
        model = User
        fields = [
            "full_name", "admission_number", "college_email", "phone_number",
            "password", "department", "semester", "profile_photo", "student_id_card",
        ]

    def validate_student_id_card(self, value):
        validate_image_file(value)
        return value

    def validate_admission_number(self, value):
        if User.objects.filter(admission_number__iexact=value).exists():
            raise serializers.ValidationError("This admission number is already registered.")
        return value

    def validate_college_email(self, value):
        if User.objects.filter(college_email__iexact=value).exists():
            raise serializers.ValidationError("This email is already registered.")
        return value

    def create(self, validated_data):
        password = validated_data.pop("password")
        # username is required by AbstractUser; derive it from admission_number.
        user = User(username=validated_data["admission_number"], **validated_data)
        user.set_password(password)
        user.status = User.Status.PENDING
        user.is_active = False  # cannot log in until admin approves
        user.save()
        return user


class LoginSerializer(serializers.Serializer):
    username = serializers.CharField(help_text="Admission Number or College Email")
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        user = authenticate(
            username=attrs["username"], password=attrs["password"]
        )
        if user is None:
            # Distinguish "wrong password" from "pending/rejected" without leaking
            # which admission numbers exist.
            candidate = User.objects.filter(
                admission_number__iexact=attrs["username"]
            ).first() or User.objects.filter(college_email__iexact=attrs["username"]).first()
            if candidate and candidate.check_password(attrs["password"]):
                if candidate.status == User.Status.PENDING:
                    raise serializers.ValidationError("Your account is awaiting verification.")
                if candidate.status == User.Status.REJECTED:
                    raise serializers.ValidationError(candidate.rejection_reason or "Your registration was rejected.")
            raise serializers.ValidationError("Invalid admission number/email or password.")
        attrs["user"] = user
        return attrs


class UserProfileSerializer(serializers.ModelSerializer):
    department_name = serializers.CharField(source="department.department_name", read_only=True)
    semester_name = serializers.CharField(source="semester.semester_name", read_only=True)
    products_listed = serializers.SerializerMethodField()
    products_sold = serializers.SerializerMethodField()
    resources_shared = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            "id", "full_name", "admission_number", "college_email", "phone_number",
            "department", "department_name", "semester", "semester_name",
            "profile_photo", "reward_points", "contributor_level", "status",
            "products_listed", "products_sold", "resources_shared",
        ]
        read_only_fields = ["admission_number", "college_email", "reward_points", "contributor_level", "status"]

    def get_products_listed(self, obj):
        return obj.products.filter(is_deleted=False).count()

    def get_products_sold(self, obj):
        return obj.products.filter(is_deleted=False, sold=True).count()

    def get_resources_shared(self, obj):
        return obj.shared_resources.filter(is_deleted=False, approval_status="APPROVED").count()
