from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin

from .models import User, Department, Semester, Subject


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    list_display = (
        "admission_number", "full_name", "college_email", "department",
        "semester", "status", "contributor_level", "reward_points", "is_active",
    )
    list_filter = ("status", "contributor_level", "department", "is_active")
    search_fields = ("admission_number", "college_email", "full_name")
    actions = ["approve_students", "reject_students", "suspend_students", "restore_students"]
    fieldsets = DjangoUserAdmin.fieldsets + (
        ("Student Info", {
            "fields": (
                "full_name", "admission_number", "college_email", "phone_number",
                "department", "semester", "profile_photo", "student_id_card",
                "reward_points", "contributor_level", "status", "rejection_reason",
            )
        }),
    )

    @admin.action(description="Approve selected students")
    def approve_students(self, request, queryset):
        queryset.update(status=User.Status.APPROVED, is_active=True)

    @admin.action(description="Reject selected students")
    def reject_students(self, request, queryset):
        queryset.update(status=User.Status.REJECTED)

    @admin.action(description="Suspend selected accounts (soft delete)")
    def suspend_students(self, request, queryset):
        for user in queryset:
            user.soft_delete()

    @admin.action(description="Restore selected accounts")
    def restore_students(self, request, queryset):
        for user in queryset:
            user.restore()


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ("department_name", "is_active")
    search_fields = ("department_name",)


@admin.register(Semester)
class SemesterAdmin(admin.ModelAdmin):
    list_display = ("department", "semester_name", "is_active")
    list_filter = ("department",)


@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ("subject_name", "subject_code", "semester", "is_active")
    search_fields = ("subject_name", "subject_code")
    list_filter = ("semester__department",)
