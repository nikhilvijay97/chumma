from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator
from django.db import models

from core.models import TimeStampedModel, SoftDeleteModel, profile_upload_to, student_id_upload_to


class Department(TimeStampedModel, SoftDeleteModel):
    department_name = models.CharField(max_length=100, unique=True, db_index=True)

    class Meta:
        ordering = ["department_name"]

    def __str__(self):
        return self.department_name


class Semester(TimeStampedModel, SoftDeleteModel):
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name="semesters", db_index=True)
    semester_name = models.CharField(max_length=50)

    class Meta:
        unique_together = ("department", "semester_name")
        ordering = ["department", "semester_name"]

    def __str__(self):
        return f"{self.department.department_name} - {self.semester_name}"


class Subject(TimeStampedModel, SoftDeleteModel):
    semester = models.ForeignKey(Semester, on_delete=models.CASCADE, related_name="subjects", db_index=True)
    subject_name = models.CharField(max_length=150, db_index=True)
    subject_code = models.CharField(max_length=30, blank=True)

    class Meta:
        unique_together = ("semester", "subject_name")
        ordering = ["subject_name"]

    def __str__(self):
        return self.subject_name


phone_validator = RegexValidator(
    regex=r"^\+?\d{7,15}$",
    message="Enter a valid phone number (7-15 digits, optional leading +).",
)


class User(AbstractUser, TimeStampedModel):
    """
    Verified student account. Extends Django's AbstractUser so we keep
    Django Authentication, password hashing, permissions, etc. for free.
    """

    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"

    class ContributorLevel(models.TextChoices):
        BRONZE = "BRONZE", "Bronze"
        SILVER = "SILVER", "Silver"
        GOLD = "GOLD", "Gold"
        PLATINUM = "PLATINUM", "Platinum"

    # username kept from AbstractUser but we primarily authenticate via
    # admission_number / college_email (see accounts.backends).
    full_name = models.CharField(max_length=150)
    admission_number = models.CharField(max_length=30, unique=True, db_index=True)
    college_email = models.EmailField(unique=True, db_index=True)
    phone_number = models.CharField(max_length=17, validators=[phone_validator])

    department = models.ForeignKey(
        Department, on_delete=models.PROTECT, related_name="users", null=True, blank=True
    )
    semester = models.ForeignKey(
        Semester, on_delete=models.PROTECT, related_name="users", null=True, blank=True
    )

    profile_photo = models.ImageField(upload_to=profile_upload_to, null=True, blank=True)
    student_id_card = models.ImageField(upload_to=student_id_upload_to, null=True, blank=True)

    reward_points = models.PositiveIntegerField(default=0)
    contributor_level = models.CharField(
        max_length=10, choices=ContributorLevel.choices, default=ContributorLevel.BRONZE
    )
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING, db_index=True)
    rejection_reason = models.CharField(max_length=255, blank=True)

    is_deleted = models.BooleanField(default=False)  # soft delete for students

    REQUIRED_FIELDS = ["full_name", "college_email", "admission_number", "phone_number"]

    class Meta:
        indexes = [
            models.Index(fields=["admission_number"]),
            models.Index(fields=["college_email"]),
        ]

    def __str__(self):
        return f"{self.full_name} ({self.admission_number})"

    def update_contributor_level(self, save=True):
        """Recalculate the contributor badge from reward_points."""
        points = self.reward_points
        if points >= 2000:
            level = self.ContributorLevel.PLATINUM
        elif points >= 1000:
            level = self.ContributorLevel.GOLD
        elif points >= 500:
            level = self.ContributorLevel.SILVER
        else:
            level = self.ContributorLevel.BRONZE
        if level != self.contributor_level:
            self.contributor_level = level
            if save:
                self.save(update_fields=["contributor_level"])
        return level

    def is_approved(self):
        return self.status == self.Status.APPROVED and self.is_active and not self.is_deleted
