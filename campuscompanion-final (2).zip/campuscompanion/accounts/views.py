from django.contrib.auth import login as django_login, logout as django_logout
from rest_framework import generics, permissions, status, viewsets
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.views import APIView

from core.models import AuditLog
from .models import Department, Semester, Subject, User
from .serializers import (
    DepartmentSerializer, SemesterSerializer, SubjectSerializer,
    RegisterSerializer, LoginSerializer, UserProfileSerializer,
)


class RegisterView(generics.CreateAPIView):
    """POST /api/register — student self-registration, status=Pending until admin approval."""
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]
    throttle_scope = "auth"

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        return Response(
            {"detail": "Registration submitted. Await admin verification before logging in.",
             "user_id": user.id},
            status=status.HTTP_201_CREATED,
        )


class LoginView(APIView):
    """POST /api/login — authenticate by Admission Number or College Email."""
    permission_classes = [permissions.AllowAny]
    throttle_scope = "auth"

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data["user"]
        django_login(request, user)
        token, _ = Token.objects.get_or_create(user=user)
        AuditLog.objects.create(actor=user, action="LOGIN", ip_address=request.META.get("REMOTE_ADDR"))
        return Response({
            "token": token.key,
            "user": UserProfileSerializer(user).data,
        })


class LogoutView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        AuditLog.objects.create(actor=request.user, action="LOGOUT", ip_address=request.META.get("REMOTE_ADDR"))
        request.user.auth_token.delete()
        django_logout(request)
        return Response({"detail": "Logged out."})


class ProfileView(generics.RetrieveUpdateAPIView):
    """GET/PATCH /api/profile — current student's profile."""
    serializer_class = UserProfileSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return self.request.user


class DepartmentViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Department.objects.filter(is_active=True)
    serializer_class = DepartmentSerializer
    permission_classes = [permissions.AllowAny]


class SemesterViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Semester.objects.filter(is_active=True)
    serializer_class = SemesterSerializer
    permission_classes = [permissions.AllowAny]
    filterset_fields = ["department"]


class SubjectViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Subject.objects.filter(is_active=True)
    serializer_class = SubjectSerializer
    permission_classes = [permissions.AllowAny]
    filterset_fields = ["semester"]
