from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import (
    RegisterView, LoginView, LogoutView, ProfileView,
    DepartmentViewSet, SemesterViewSet, SubjectViewSet,
)

router = DefaultRouter()
router.register("departments", DepartmentViewSet, basename="department")
router.register("semesters", SemesterViewSet, basename="semester")
router.register("subjects", SubjectViewSet, basename="subject")

urlpatterns = [
    path("register", RegisterView.as_view(), name="register"),
    path("login", LoginView.as_view(), name="login"),
    path("logout", LogoutView.as_view(), name="logout"),
    path("profile", ProfileView.as_view(), name="profile"),
] + router.urls
