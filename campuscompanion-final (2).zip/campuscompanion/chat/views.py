from django.db.models import Q
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.models import User
from notifications.models import Notification
from .models import Message
from .serializers import MessageSerializer


class MessageListCreateView(APIView):
    """
    GET /api/messages?with=<user_id> — conversation thread.
    POST /api/send-message — { receiver, message, image }
    Students cannot message Admin (CHAT RULES).
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        other_id = request.query_params.get("with")
        qs = Message.objects.filter(
            Q(sender=request.user) | Q(receiver=request.user)
        ).exclude(is_deleted_by_sender=True, sender=request.user)
        if other_id:
            qs = qs.filter(Q(sender_id=other_id) | Q(receiver_id=other_id))
        Message.objects.filter(receiver=request.user, is_read=False).update(is_read=True)
        return Response(MessageSerializer(qs.order_by("timestamp"), many=True).data)

    def post(self, request):
        receiver_id = request.data.get("receiver")
        receiver = User.objects.filter(pk=receiver_id).first()
        if not receiver:
            return Response({"detail": "Receiver not found."}, status=status.HTTP_404_NOT_FOUND)
        if receiver.is_staff or request.user.is_staff:
            return Response({"detail": "Students cannot message Admin."}, status=status.HTTP_403_FORBIDDEN)

        serializer = MessageSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        message = serializer.save()

        Notification.objects.create(
            user=receiver, title="New Chat",
            message=f"New message from {request.user.full_name}",
            notification_type=Notification.NotificationType.INFO,
        )
        return Response(MessageSerializer(message).data, status=status.HTTP_201_CREATED)


class DeleteMessageView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def delete(self, request, pk):
        msg = Message.objects.filter(pk=pk, sender=request.user).first()
        if not msg:
            return Response({"detail": "Message not found."}, status=404)
        msg.is_deleted_by_sender = True
        msg.save(update_fields=["is_deleted_by_sender"])
        return Response({"detail": "Message deleted."})
