from django.urls import path

from .views import MessageListCreateView, DeleteMessageView

urlpatterns = [
    path("messages", MessageListCreateView.as_view(), name="messages"),
    path("send-message", MessageListCreateView.as_view(), name="send-message"),
    path("messages/<int:pk>", DeleteMessageView.as_view(), name="delete-message"),
]
