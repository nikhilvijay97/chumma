from django.conf import settings
from django.db import models

from core.models import TimeStampedModel, chat_upload_to


class Message(TimeStampedModel):
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="sent_messages")
    receiver = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="received_messages")
    message = models.TextField(blank=True)
    image = models.ImageField(upload_to=chat_upload_to, null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)
    is_deleted_by_sender = models.BooleanField(default=False)

    class Meta:
        ordering = ["timestamp"]
        indexes = [models.Index(fields=["sender", "receiver"])]

    def __str__(self):
        return f"{self.sender} -> {self.receiver}: {self.message[:30]}"
