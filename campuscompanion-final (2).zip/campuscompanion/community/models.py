from django.conf import settings
from django.db import models

from accounts.models import Department, Semester, Subject
from core.models import TimeStampedModel, SoftDeleteModel, resources_upload_to


class SharedResource(TimeStampedModel, SoftDeleteModel):
    class ResourceType(models.TextChoices):
        QUESTION_PAPER = "QUESTION_PAPER", "Question Paper"
        PDF_NOTES = "PDF_NOTES", "PDF Notes"
        HANDWRITTEN_NOTES = "HANDWRITTEN_NOTES", "Handwritten Notes"
        LAB_RECORD = "LAB_RECORD", "Lab Record"

    class ApprovalStatus(models.TextChoices):
        PENDING = "PENDING", "Pending"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"

    uploader = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="shared_resources")
    department = models.ForeignKey(Department, on_delete=models.PROTECT, related_name="resources", db_index=True)
    semester = models.ForeignKey(Semester, on_delete=models.PROTECT, related_name="resources", db_index=True)
    subject = models.ForeignKey(Subject, on_delete=models.PROTECT, related_name="resources", db_index=True)
    resource_type = models.CharField(max_length=20, choices=ResourceType.choices, db_index=True)

    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    # exam_type / exam_year are only meaningful (and required) for Question Papers,
    # and are the basis of the duplicate-prevention check.
    exam_type = models.CharField(max_length=50, blank=True)
    exam_year = models.PositiveIntegerField(null=True, blank=True, db_index=True)

    file_path = models.FileField(upload_to=resources_upload_to)
    download_count = models.PositiveIntegerField(default=0)
    approval_status = models.CharField(
        max_length=10, choices=ApprovalStatus.choices, default=ApprovalStatus.PENDING, db_index=True
    )
    reward_points_awarded = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["department", "semester", "subject", "exam_type", "exam_year"]),
        ]

    def __str__(self):
        return self.title

    def is_duplicate_question_paper(self):
        """
        Duplicate check for Question Papers only, comparing DB fields
        (never filenames): Department + Semester + Subject + Exam Type + Exam Year.
        """
        if self.resource_type != self.ResourceType.QUESTION_PAPER:
            return False
        qs = SharedResource.objects.filter(
            resource_type=self.ResourceType.QUESTION_PAPER,
            department=self.department,
            semester=self.semester,
            subject=self.subject,
            exam_type=self.exam_type,
            exam_year=self.exam_year,
            approval_status=self.ApprovalStatus.APPROVED,
        ).exclude(pk=self.pk)
        return qs.exists()
