from django.contrib import admin
from .models import SharedResource


@admin.register(SharedResource)
class SharedResourceAdmin(admin.ModelAdmin):
    list_display = (
        "title", "uploader", "department", "semester", "subject",
        "resource_type", "exam_year", "approval_status", "download_count",
    )
    list_filter = ("resource_type", "approval_status", "department", "semester")
    search_fields = ("title",)
    actions = ["approve_resources", "reject_resources"]

    @admin.action(description="Approve selected resources (runs duplicate check + reward engine)")
    def approve_resources(self, request, queryset):
        from rewards.services import approve_shared_resource, DuplicateQuestionPaperError
        approved, rejected = 0, 0
        for resource in queryset:
            try:
                approve_shared_resource(resource, admin_user=request.user)
                approved += 1
            except DuplicateQuestionPaperError:
                rejected += 1
        self.message_user(request, f"Approved: {approved}, Rejected as duplicate: {rejected}")

    @admin.action(description="Reject selected resources")
    def reject_resources(self, request, queryset):
        queryset.update(approval_status=SharedResource.ApprovalStatus.REJECTED)
