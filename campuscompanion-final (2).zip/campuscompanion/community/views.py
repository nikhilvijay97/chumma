from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets, permissions, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView

from core.permissions import IsApprovedStudent
from .models import SharedResource
from .serializers import SharedResourceSerializer


class SharedResourceViewSet(viewsets.ModelViewSet):
    """GET /api/resources, POST /api/upload-resource (aliased below)."""
    serializer_class = SharedResourceSerializer
    permission_classes = [IsApprovedStudent]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ["department", "semester", "subject", "resource_type", "exam_year"]
    search_fields = ["title", "description"]

    def get_queryset(self):
        qs = SharedResource.objects.select_related("uploader", "department", "semester", "subject").filter(
            is_deleted=False
        )
        if self.request.user.is_staff:
            return qs
        from django.db.models import Q
        own_filter = Q()
        if self.request.user.is_authenticated:
            own_filter = Q(uploader=self.request.user)
        return qs.filter(Q(approval_status=SharedResource.ApprovalStatus.APPROVED) | own_filter)

    def perform_create(self, serializer):
        instance = serializer.save()
        # Pre-flight duplicate check at upload time (final authoritative check
        # happens again at admin-approval time via rewards.services).
        if instance.is_duplicate_question_paper():
            instance.approval_status = SharedResource.ApprovalStatus.REJECTED
            instance.save(update_fields=["approval_status"])

    def perform_destroy(self, instance):
        instance.soft_delete()

    @action(detail=True, methods=["post"])
    def download(self, request, pk=None):
        resource = self.get_object()
        resource.download_count += 1
        resource.save(update_fields=["download_count"])
        return Response({"file_path": resource.file_path.url if resource.file_path else None})


class DuplicateCheckView(APIView):
    """
    POST /api/resources/duplicate-check
    Body: department, semester, subject, exam_type, exam_year
    Question Papers only. Returns 409 Conflict if a match already exists.
    """
    permission_classes = [IsApprovedStudent]

    def post(self, request):
        required = ["department", "semester", "subject", "exam_type", "exam_year"]
        missing = [f for f in required if not request.data.get(f)]
        if missing:
            return Response({"detail": f"Missing fields: {', '.join(missing)}"}, status=400)

        exists = SharedResource.objects.filter(
            resource_type=SharedResource.ResourceType.QUESTION_PAPER,
            department_id=request.data["department"],
            semester_id=request.data["semester"],
            subject_id=request.data["subject"],
            exam_type=request.data["exam_type"],
            exam_year=request.data["exam_year"],
            approval_status=SharedResource.ApprovalStatus.APPROVED,
        ).exists()

        if exists:
            return Response(
                {"detail": "Question paper already exists.", "message": "This question paper is already available."},
                status=status.HTTP_409_CONFLICT,
            )
        return Response({"detail": "No duplicate found."}, status=200)
