from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import SharedResourceViewSet, DuplicateCheckView

router = DefaultRouter()
router.register("resources", SharedResourceViewSet, basename="resource")

urlpatterns = [
    path("upload-resource", SharedResourceViewSet.as_view({"post": "create"}), name="upload-resource"),
    path("resources/duplicate-check", DuplicateCheckView.as_view(), name="duplicate-check"),
] + router.urls
