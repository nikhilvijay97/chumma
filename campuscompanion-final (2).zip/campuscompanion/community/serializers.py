from rest_framework import serializers

from core.validators import validate_resource_file
from .models import SharedResource


class SharedResourceSerializer(serializers.ModelSerializer):
    uploader_name = serializers.CharField(source="uploader.full_name", read_only=True)
    subject_name = serializers.CharField(source="subject.subject_name", read_only=True)

    class Meta:
        model = SharedResource
        fields = [
            "id", "uploader", "uploader_name", "department", "semester", "subject",
            "subject_name", "resource_type", "title", "description", "exam_type",
            "exam_year", "file_path", "download_count", "approval_status",
            "reward_points_awarded", "created_at",
        ]
        read_only_fields = ["uploader", "download_count", "approval_status", "reward_points_awarded", "created_at"]

    def validate_file_path(self, value):
        validate_resource_file(value)
        return value

    def validate(self, attrs):
        resource_type = attrs.get("resource_type")
        if resource_type == SharedResource.ResourceType.QUESTION_PAPER:
            if not attrs.get("exam_type") or not attrs.get("exam_year"):
                raise serializers.ValidationError(
                    "exam_type and exam_year are required for Question Papers."
                )
        return attrs

    def create(self, validated_data):
        validated_data["uploader"] = self.context["request"].user
        return super().create(validated_data)
