# pages renders templates only
