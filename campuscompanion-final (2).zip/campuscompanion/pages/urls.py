"""
Frontend page routes.
Every page renders a Django template; data is loaded dynamically from the
existing REST API endpoints by the static JavaScript files.
"""
from django.urls import path
from django.contrib.auth import views as auth_views

from . import views

urlpatterns = [
    # Public
    path("", views.landing, name="landing"),
    path("login/", views.login_page, name="login_page"),
    path("register/", views.register_page, name="register_page"),
    path("forgot-password/", views.forgot_password_page, name="forgot_password_page"),
    path("reset-password/<str:token>/", views.reset_password_page, name="reset_password_page"),

    # Marketplace (public catalogue + details)
    path("marketplace/", views.marketplace_page, name="marketplace_page"),
    path("marketplace/category/<int:category_id>/", views.category_page, name="category_page"),
    path("marketplace/product/<int:product_id>/", views.product_detail_page, name="product_detail_page"),

    # Rental
    path("rentals/", views.rentals_page, name="rentals_page"),
    path("rentals/<int:rental_id>/", views.rental_detail_page, name="rental_detail_page"),

    # Community / Resources
    path("community/", views.community_page, name="community_page"),

    # Rewards
    path("rewards/", views.rewards_page, name="rewards_page"),

    # Authenticated / dashboard area
    path("dashboard/", views.dashboard_page, name="dashboard_page"),
    path("profile/", views.profile_page, name="profile_page"),
    path("upload-product/", views.upload_product_page, name="upload_product_page"),
    path("upload-rental/", views.upload_rental_page, name="upload_rental_page"),
    path("upload-resource/", views.upload_resource_page, name="upload_resource_page"),

    path("wishlist/", views.wishlist_page, name="wishlist_page"),
    path("notifications/", views.notifications_page, name="notifications_page"),
    path("chat/", views.chat_inbox_page, name="chat_inbox_page"),
    path("chat/<int:user_id>/", views.chat_room_page, name="chat_room_page"),
    path("reports/", views.reports_page, name="reports_page"),

    # Admin area
    path("admin-area/", views.admin_dashboard_page, name="admin_dashboard_page"),
    path("admin-area/students/", views.admin_students_page, name="admin_students_page"),
    path("admin-area/products/", views.admin_products_page, name="admin_products_page"),
    path("admin-area/resources/", views.admin_resources_page, name="admin_resources_page"),
    path("admin-area/rewards/", views.admin_rewards_page, name="admin_rewards_page"),
    path("admin-area/reports/", views.admin_reports_page, name="admin_reports_page"),
]
