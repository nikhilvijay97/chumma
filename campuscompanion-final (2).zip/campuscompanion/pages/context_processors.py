"""Inject site-wide values into every template render."""
from django.conf import settings


def site_globals(request):
    return {
        "SITE_NAME": "Campus Companion",
        "SITE_TAGLINE": "Where Students Connect",
        "DEBUG_MODE": settings.DEBUG,
        "MEDIA_URL": settings.MEDIA_URL,
        "STATIC_URL": settings.STATIC_URL,
    }
