"""
Frontend page views -- render Django templates. The actual data is fetched
asynchronously via the existing REST API by the static JS files.
"""
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods


def _base_context(request, extra=None):
    ctx = {
        "user": request.user,
        "is_authenticated": request.user.is_authenticated,
        "is_staff": request.user.is_authenticated and request.user.is_staff,
    }
    if extra:
        ctx.update(extra)
    return ctx


def landing(request):
    if request.user.is_authenticated:
        if request.user.is_staff:
            return redirect("admin_dashboard_page")
        return redirect("dashboard_page")
    return render(request, "pages/landing.html", _base_context(request))


@require_http_methods(["GET", "POST"])
def login_page(request):
    if request.user.is_authenticated:
        return redirect("dashboard_page")
    return render(request, "pages/login.html", _base_context(request))


@require_http_methods(["GET", "POST"])
def register_page(request):
    if request.user.is_authenticated:
        return redirect("dashboard_page")
    return render(request, "pages/register.html", _base_context(request))


def forgot_password_page(request):
    return render(request, "pages/forgot_password.html", _base_context(request))


def reset_password_page(request, token):
    return render(request, "pages/reset_password.html", _base_context(request, {"token": token}))


@login_required
def dashboard_page(request):
    return render(request, "pages/dashboard.html", _base_context(request))


@login_required
def profile_page(request):
    return render(request, "pages/profile.html", _base_context(request))


@login_required
def upload_product_page(request):
    return render(request, "pages/upload_product.html", _base_context(request))


@login_required
def upload_rental_page(request):
    return render(request, "pages/upload_rental.html", _base_context(request))


@login_required
def upload_resource_page(request):
    return render(request, "pages/upload_resource.html", _base_context(request))


def marketplace_page(request):
    return render(request, "pages/marketplace.html", _base_context(request))


def category_page(request, category_id):
    return render(request, "pages/category.html", _base_context(request, {"category_id": category_id}))


def product_detail_page(request, product_id):
    return render(request, "pages/product_detail.html", _base_context(request, {"product_id": product_id}))


def rentals_page(request):
    return render(request, "pages/rentals.html", _base_context(request))


def rental_detail_page(request, rental_id):
    return render(request, "pages/rental_detail.html", _base_context(request, {"rental_id": rental_id}))


def community_page(request):
    return render(request, "pages/community.html", _base_context(request))


def rewards_page(request):
    return render(request, "pages/rewards.html", _base_context(request))


@login_required
def wishlist_page(request):
    return render(request, "pages/wishlist.html", _base_context(request))


@login_required
def notifications_page(request):
    return render(request, "pages/notifications.html", _base_context(request))


@login_required
def chat_inbox_page(request):
    return render(request, "pages/chat_inbox.html", _base_context(request))


@login_required
def chat_room_page(request, user_id):
    return render(request, "pages/chat_room.html", _base_context(request, {"other_user_id": user_id}))


@login_required
def reports_page(request):
    return render(request, "pages/reports.html", _base_context(request))


def _admin_only(request):
    return request.user.is_authenticated and request.user.is_staff


def admin_dashboard_page(request):
    if not _admin_only(request):
        return redirect("login_page")
    return render(request, "pages/admin/dashboard.html", _base_context(request))


def admin_students_page(request):
    if not _admin_only(request):
        return redirect("login_page")
    return render(request, "pages/admin/students.html", _base_context(request))


def admin_products_page(request):
    if not _admin_only(request):
        return redirect("login_page")
    return render(request, "pages/admin/products.html", _base_context(request))


def admin_resources_page(request):
    if not _admin_only(request):
        return redirect("login_page")
    return render(request, "pages/admin/resources.html", _base_context(request))


def admin_rewards_page(request):
    if not _admin_only(request):
        return redirect("login_page")
    return render(request, "pages/admin/rewards.html", _base_context(request))


def admin_reports_page(request):
    if not _admin_only(request):
        return redirect("login_page")
    return render(request, "pages/admin/reports.html", _base_context(request))
