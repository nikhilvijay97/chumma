from rest_framework import serializers

from .models import RentalItem, RentalItemImage, RentalRequest


class RentalItemImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = RentalItemImage
        fields = ["id", "image", "order"]


class RentalItemSerializer(serializers.ModelSerializer):
    images = RentalItemImageSerializer(many=True, read_only=True)
    owner_name = serializers.CharField(source="owner.full_name", read_only=True)

    class Meta:
        model = RentalItem
        fields = [
            "id", "owner", "owner_name", "category", "item_name", "description",
            "rent_price", "deposit", "available_from", "available_until",
            "images", "approval_status", "created_at",
        ]
        read_only_fields = ["owner", "approval_status", "created_at"]

    def validate_rent_price(self, value):
        if value <= 0:
            raise serializers.ValidationError("Rent price must be greater than 0.")
        return value

    def validate_deposit(self, value):
        if value < 0:
            raise serializers.ValidationError("Deposit cannot be negative.")
        return value

    def validate(self, attrs):
        start = attrs.get("available_from", getattr(self.instance, "available_from", None))
        end = attrs.get("available_until", getattr(self.instance, "available_until", None))
        if start and end and end <= start:
            raise serializers.ValidationError("available_until must be after available_from.")
        return attrs

    def create(self, validated_data):
        validated_data["owner"] = self.context["request"].user
        return super().create(validated_data)


class RentalRequestSerializer(serializers.ModelSerializer):
    requester_name = serializers.CharField(source="requester.full_name", read_only=True)

    class Meta:
        model = RentalRequest
        fields = [
            "id", "rental_item", "requester", "requester_name", "request_date",
            "rental_start", "rental_end", "status",
        ]
        read_only_fields = ["requester", "request_date", "status"]

    def validate(self, attrs):
        if attrs["rental_end"] <= attrs["rental_start"]:
            raise serializers.ValidationError("rental_end must be after rental_start.")
        overlapping = RentalRequest.objects.filter(
            rental_item=attrs["rental_item"],
            status=RentalRequest.Status.ACCEPTED,
            rental_start__lt=attrs["rental_end"],
            rental_end__gt=attrs["rental_start"],
        )
        if overlapping.exists():
            raise serializers.ValidationError("This item is already booked for overlapping dates.")
        return attrs

    def create(self, validated_data):
        validated_data["requester"] = self.context["request"].user
        return super().create(validated_data)
