from django.conf import settings
from django.core.exceptions import ValidationError
from decimal import Decimal
from django.core.validators import MinValueValidator
from django.db import models

from core.models import TimeStampedModel, SoftDeleteModel
from marketplace.models import Category


def rental_image_upload_to(instance, filename):
    import os, uuid
    ext = filename.split(".")[-1]
    return os.path.join("rentals", f"{uuid.uuid4().hex}.{ext}")


class RentalItem(TimeStampedModel, SoftDeleteModel):
    class ApprovalStatus(models.TextChoices):
        PENDING = "PENDING", "Pending"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"

    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="rental_items")
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="rental_items", db_index=True)
    item_name = models.CharField(max_length=150, db_index=True)
    description = models.TextField()
    rent_price = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    deposit = models.DecimalField(max_digits=10, decimal_places=2, default=0, validators=[MinValueValidator(Decimal('0'))])
    available_from = models.DateField()
    available_until = models.DateField()
    approval_status = models.CharField(
        max_length=10, choices=ApprovalStatus.choices, default=ApprovalStatus.PENDING, db_index=True
    )

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.item_name

    def clean(self):
        if self.available_until and self.available_from and self.available_until <= self.available_from:
            raise ValidationError("available_until must be after available_from.")


class RentalItemImage(TimeStampedModel):
    rental_item = models.ForeignKey(RentalItem, on_delete=models.CASCADE, related_name="images")
    image = models.ImageField(upload_to=rental_image_upload_to)
    order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ["order", "created_at"]


class RentalRequest(TimeStampedModel):
    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        ACCEPTED = "ACCEPTED", "Accepted"
        REJECTED = "REJECTED", "Rejected"
        COMPLETED = "COMPLETED", "Completed"

    rental_item = models.ForeignKey(RentalItem, on_delete=models.CASCADE, related_name="requests")
    requester = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="rental_requests")
    request_date = models.DateTimeField(auto_now_add=True)
    rental_start = models.DateField()
    rental_end = models.DateField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING, db_index=True)

    class Meta:
        ordering = ["-request_date"]

    def clean(self):
        if self.rental_end and self.rental_start and self.rental_end <= self.rental_start:
            raise ValidationError("rental_end must be after rental_start.")
        # Prevent overlapping accepted rentals for the same item.
        if self.rental_item_id:
            overlapping = RentalRequest.objects.filter(
                rental_item=self.rental_item,
                status__in=[self.Status.ACCEPTED],
                rental_start__lt=self.rental_end,
                rental_end__gt=self.rental_start,
            ).exclude(pk=self.pk)
            if overlapping.exists():
                raise ValidationError("This item is already booked for overlapping dates.")

    def __str__(self):
        return f"Request #{self.pk} for {self.rental_item}"
