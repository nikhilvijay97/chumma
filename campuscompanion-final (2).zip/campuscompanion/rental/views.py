from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets, permissions, filters
from rest_framework.decorators import action
from rest_framework.response import Response

from core.permissions import IsApprovedStudent, IsOwnerOrReadOnly
from notifications.models import Notification
from .models import RentalItem, RentalRequest
from .serializers import RentalItemSerializer, RentalRequestSerializer


class RentalItemViewSet(viewsets.ModelViewSet):
    """GET/POST /api/rentals, PUT/DELETE /api/rentals/{id}"""
    serializer_class = RentalItemSerializer
    permission_classes = [IsApprovedStudent, IsOwnerOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ["category", "owner"]
    search_fields = ["item_name", "description"]

    def get_queryset(self):
        qs = RentalItem.objects.select_related("owner", "category").filter(is_deleted=False)
        if self.request.user.is_staff:
            return qs
        from django.db.models import Q
        own_filter = Q()
        if self.request.user.is_authenticated:
            own_filter = Q(owner=self.request.user)
        return qs.filter(Q(approval_status=RentalItem.ApprovalStatus.APPROVED) | own_filter)

    def perform_destroy(self, instance):
        instance.soft_delete()


class RentalRequestViewSet(viewsets.ModelViewSet):
    """POST /api/rental-request, plus list/accept/reject/complete."""
    serializer_class = RentalRequestSerializer
    permission_classes = [IsApprovedStudent]

    def get_queryset(self):
        user = self.request.user
        from django.db.models import Q
        if user.is_authenticated:
            return RentalRequest.objects.filter(
                Q(requester=user) | Q(rental_item__owner=user)
            ).select_related("rental_item", "requester")
        return RentalRequest.objects.none()

    @action(detail=True, methods=["post"])
    def accept(self, request, pk=None):
        req = self.get_object()
        if req.rental_item.owner != request.user:
            return Response({"detail": "Only the owner can accept."}, status=403)
        req.status = RentalRequest.Status.ACCEPTED
        req.save(update_fields=["status"])
        Notification.objects.create(
            user=req.requester, title="Rental Accepted",
            message=f"Your rental request for {req.rental_item.item_name} was accepted.",
            notification_type=Notification.NotificationType.SUCCESS,
        )
        return Response({"detail": "Rental request accepted."})

    @action(detail=True, methods=["post"])
    def reject(self, request, pk=None):
        req = self.get_object()
        if req.rental_item.owner != request.user:
            return Response({"detail": "Only the owner can reject."}, status=403)
        req.status = RentalRequest.Status.REJECTED
        req.save(update_fields=["status"])
        return Response({"detail": "Rental request rejected."})

    @action(detail=True, methods=["post"])
    def complete(self, request, pk=None):
        req = self.get_object()
        if req.rental_item.owner != request.user:
            return Response({"detail": "Only the owner can complete."}, status=403)
        req.status = RentalRequest.Status.COMPLETED
        req.save(update_fields=["status"])
        Notification.objects.create(
            user=req.requester, title="Rental Completed",
            message=f"Your rental of {req.rental_item.item_name} is complete.",
            notification_type=Notification.NotificationType.INFO,
        )
        return Response({"detail": "Rental marked completed."})
