from rest_framework.routers import DefaultRouter

from .views import RentalItemViewSet, RentalRequestViewSet

router = DefaultRouter()
router.register("rentals", RentalItemViewSet, basename="rental-item")
router.register("rental-request", RentalRequestViewSet, basename="rental-request")

urlpatterns = router.urls
