from django.conf import settings
from django.db import models

from marketplace.models import Product


class Report(models.Model):
    class Reason(models.TextChoices):
        FAKE_PRODUCT = "FAKE_PRODUCT", "Fake Product"
        SPAM = "SPAM", "Spam"
        WRONG_CATEGORY = "WRONG_CATEGORY", "Wrong Category"
        INAPPROPRIATE_NOTES = "INAPPROPRIATE_NOTES", "Inappropriate Notes"
        DUPLICATE_CONTENT = "DUPLICATE_CONTENT", "Duplicate Content"

    class Status(models.TextChoices):
        OPEN = "OPEN", "Open"
        DISMISSED = "DISMISSED", "Dismissed"
        DELETED = "DELETED", "Content Deleted"
        USER_SUSPENDED = "USER_SUSPENDED", "User Suspended"

    reporter = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="reports_filed")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="reports", null=True, blank=True)
    reason = models.CharField(max_length=30, choices=Reason.choices)
    details = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.OPEN, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Report #{self.pk} on {self.product} ({self.status})"
