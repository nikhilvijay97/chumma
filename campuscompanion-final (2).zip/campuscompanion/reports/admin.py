from django.contrib import admin
from .models import Report


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ("reporter", "product", "reason", "status", "created_at")
    list_filter = ("reason", "status")
    actions = ["dismiss_reports", "delete_content", "suspend_user"]

    @admin.action(description="Dismiss selected reports")
    def dismiss_reports(self, request, queryset):
        queryset.update(status=Report.Status.DISMISSED)

    @admin.action(description="Delete reported content (soft delete)")
    def delete_content(self, request, queryset):
        for report in queryset:
            if report.product:
                report.product.soft_delete()
            report.status = Report.Status.DELETED
            report.save(update_fields=["status"])

    @admin.action(description="Suspend reported user")
    def suspend_user(self, request, queryset):
        for report in queryset:
            if report.product:
                report.product.seller.soft_delete()
            report.status = Report.Status.USER_SUSPENDED
            report.save(update_fields=["status"])
