from django.test import TestCase
from django.urls import reverse

from accounts.models import User


class ReportAccessTests(TestCase):
    def setUp(self):
        self.staff = User.objects.create_user(username='staffer', password='pass12345', is_staff=True)
        self.client.login(username='staffer', password='pass12345')

    def test_user_report(self):
        self.assertEqual(self.client.get(reverse('reports:user_report')).status_code, 200)

    def test_product_report(self):
        self.assertEqual(self.client.get(reverse('reports:product_report')).status_code, 200)

    def test_store_report(self):
        self.assertEqual(self.client.get(reverse('reports:store_report')).status_code, 200)

    def test_price_report(self):
        self.assertEqual(self.client.get(reverse('reports:price_report')).status_code, 200)

    def test_my_savings_requires_login(self):
        self.client.logout()
        response = self.client.get(reverse('reports:my_savings'))
        self.assertEqual(response.status_code, 302)
