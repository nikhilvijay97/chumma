from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.db.models import Avg, Count, Min
from django.shortcuts import render

from accounts.models import User
from products.models import Product, ProductPrice
from stores.models import Store
from wishlist.models import Wishlist


@staff_member_required
def user_report(request):
    users = User.objects.annotate(
        wishlist_count=Count('wishlist_items', distinct=True),
        review_count=Count('search_history', distinct=True),
    ).order_by('-date_joined')
    context = {
        'users': users,
        'total_users': users.count(),
        'active_users': users.filter(is_active=True).count(),
        'staff_users': users.filter(is_staff=True).count(),
    }
    return render(request, 'reports/user_report.html', context)


@staff_member_required
def product_report(request):
    products = Product.objects.select_related('category', 'brand').annotate(
        min_price=Min('prices__price'),
        listing_count=Count('prices', distinct=True),
        wishlist_count=Count('wishlisted_by', distinct=True),
    ).order_by('-wishlist_count')
    context = {
        'products': products,
        'total_products': products.count(),
        'active_products': products.filter(is_active=True).count(),
        'featured_products': products.filter(is_featured=True).count(),
    }
    return render(request, 'reports/product_report.html', context)


@staff_member_required
def store_report(request):
    stores = Store.objects.annotate(
        listing_count=Count('product_prices', distinct=True),
        avg_price=Avg('product_prices__price'),
    ).order_by('-listing_count')
    context = {'stores': stores, 'total_stores': stores.count()}
    return render(request, 'reports/store_report.html', context)


@staff_member_required
def price_report(request):
    prices = ProductPrice.objects.select_related('product', 'store').order_by('-updated_at')[:200]
    context = {
        'prices': prices,
        'total_price_records': ProductPrice.objects.count(),
        'avg_price': ProductPrice.objects.aggregate(avg=Avg('price'))['avg'],
        'out_of_stock_count': ProductPrice.objects.filter(in_stock=False).count(),
    }
    return render(request, 'reports/price_report.html', context)


@login_required
def my_savings_report(request):
    items = Wishlist.objects.filter(user=request.user).select_related('product').prefetch_related('product__prices')
    rows = []
    total_savings = 0
    for item in items:
        cheapest = item.product.lowest_price
        priciest = item.product.highest_price
        savings = item.product.max_savings
        total_savings += savings
        rows.append({'product': item.product, 'cheapest': cheapest, 'priciest': priciest, 'savings': savings})
    return render(request, 'reports/my_savings.html', {'rows': rows, 'total_savings': total_savings})
