from django.urls import path

from . import views

app_name = 'reports'

urlpatterns = [
    path('users/', views.user_report, name='user_report'),
    path('products/', views.product_report, name='product_report'),
    path('stores/', views.store_report, name='store_report'),
    path('prices/', views.price_report, name='price_report'),
    path('my-savings/', views.my_savings_report, name='my_savings'),
]
