# The reports app has no models of its own — it aggregates data from
# accounts, products, stores and wishlist for the staff report pages.
