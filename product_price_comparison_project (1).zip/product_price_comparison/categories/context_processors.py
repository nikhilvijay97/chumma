from .models import Category


def categories_processor(request):
    """Injects the active category list into every template's context
    (nav bar dropdown, home page popular-categories section, filters)."""
    return {'nav_categories': Category.objects.filter(is_active=True).order_by('name')}
