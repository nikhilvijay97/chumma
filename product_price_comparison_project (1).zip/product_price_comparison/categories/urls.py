from django.urls import path

from . import views

app_name = 'categories'

urlpatterns = [
    path('', views.category_list_public, name='category_list'),
    path('manage/', views.admin_category_list, name='admin_category_list'),
    path('manage/add/', views.admin_category_create, name='admin_category_create'),
    path('manage/<int:pk>/edit/', views.admin_category_update, name='admin_category_update'),
    path('manage/<int:pk>/delete/', views.admin_category_delete, name='admin_category_delete'),
]
