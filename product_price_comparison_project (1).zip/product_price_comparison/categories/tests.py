from django.test import TestCase
from django.urls import reverse

from accounts.models import User

from .models import Category


class CategoryCrudTests(TestCase):
    def setUp(self):
        self.staff = User.objects.create_user(username='staffer', password='pass12345', is_staff=True)
        self.category = Category.objects.create(name='Electronics')

    def test_public_category_list(self):
        response = self.client.get(reverse('categories:category_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Electronics')

    def test_admin_list_requires_staff(self):
        response = self.client.get(reverse('categories:admin_category_list'))
        self.assertNotEqual(response.status_code, 200)

    def test_admin_can_create_category(self):
        self.client.login(username='staffer', password='pass12345')
        response = self.client.post(reverse('categories:admin_category_create'), {
            'name': 'New Category', 'description': '', 'icon': 'bi-tag', 'is_active': True,
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Category.objects.filter(name='New Category').exists())

    def test_admin_can_delete_category(self):
        self.client.login(username='staffer', password='pass12345')
        response = self.client.post(reverse('categories:admin_category_delete', args=[self.category.pk]))
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Category.objects.filter(pk=self.category.pk).exists())
