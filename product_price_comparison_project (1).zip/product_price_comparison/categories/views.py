from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render

from dashboard.utils import log_admin_action

from .forms import CategoryForm
from .models import Category


def category_list_public(request):
    categories = Category.objects.filter(is_active=True).order_by('name')
    return render(request, 'categories/category_list.html', {'categories': categories})


# ------------------------- Staff CRUD -------------------------

@staff_member_required
def admin_category_list(request):
    categories = Category.objects.all().order_by('name')
    paginator = Paginator(categories, 10)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'categories/admin_category_list.html', {'page_obj': page_obj, 'categories': page_obj.object_list})


@staff_member_required
def admin_category_create(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST, request.FILES)
        if form.is_valid():
            category = form.save()
            log_admin_action(request.user, 'CREATE', 'Category', str(category))
            messages.success(request, f'Category "{category.name}" created successfully.')
            return redirect('categories:admin_category_list')
    else:
        form = CategoryForm()
    return render(request, 'categories/admin_category_form.html', {'form': form, 'title': 'Add Category'})


@staff_member_required
def admin_category_update(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        form = CategoryForm(request.POST, request.FILES, instance=category)
        if form.is_valid():
            form.save()
            log_admin_action(request.user, 'UPDATE', 'Category', str(category))
            messages.success(request, f'Category "{category.name}" updated successfully.')
            return redirect('categories:admin_category_list')
    else:
        form = CategoryForm(instance=category)
    return render(request, 'categories/admin_category_form.html', {'form': form, 'title': 'Edit Category'})


@staff_member_required
def admin_category_delete(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        name = str(category)
        category.delete()
        log_admin_action(request.user, 'DELETE', 'Category', name)
        messages.success(request, f'Category "{name}" deleted.')
        return redirect('categories:admin_category_list')
    return render(request, 'categories/admin_category_confirm_delete.html', {'category': category})
