/* Product Price Comparison — main.js */
$(function () {

    // -----------------------------------------------------------------
    // Dark / Light theme toggle (persisted in localStorage)
    // -----------------------------------------------------------------
    const root = document.documentElement;
    const savedTheme = localStorage.getItem('ppc-theme') || 'light';
    root.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);

    $('#themeToggleBtn').on('click', function () {
        const current = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        root.setAttribute('data-theme', current);
        localStorage.setItem('ppc-theme', current);
        updateThemeIcon(current);
    });

    function updateThemeIcon(theme) {
        const $icon = $('#themeToggleBtn i');
        if (!$icon.length) return;
        $icon.attr('class', theme === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill');
    }

    // -----------------------------------------------------------------
    // Sidebar toggle (mobile dashboard)
    // -----------------------------------------------------------------
    $('#sidebarToggleBtn').on('click', function () {
        $('.dash-sidebar').toggleClass('show');
    });

    // -----------------------------------------------------------------
    // Wishlist toggle (AJAX heart button)
    // -----------------------------------------------------------------
    $(document).on('click', '.wishlist-btn', function (e) {
        e.preventDefault();
        const $btn = $(this);
        const url = $btn.data('url');

        $.ajax({
            url: url,
            type: 'POST',
            headers: { 'X-CSRFToken': CSRF_TOKEN },
            success: function (data) {
                $btn.toggleClass('active', data.added);
                $btn.find('i').toggleClass('bi-heart bi-heart-fill');
                $('#wishlistCount').text(data.wishlist_count > 0 ? data.wishlist_count : '');
            },
            error: function (xhr) {
                if (xhr.status === 403 || xhr.status === 401) {
                    window.location.href = '/accounts/login/';
                }
            }
        });
    });

    // -----------------------------------------------------------------
    // Category pill quick filter
    // -----------------------------------------------------------------
    $('.category-pill').on('click', function (e) {
        e.preventDefault();
        const category = $(this).data('category') || '';
        const params = new URLSearchParams(window.location.search);
        if (category) { params.set('category', category); } else { params.delete('category'); }
        window.location.search = params.toString();
    });

    // -----------------------------------------------------------------
    // Live client-side filtering of visible product cards
    // -----------------------------------------------------------------
    let searchTimer;
    $('#liveSearchInput').on('keyup', function () {
        clearTimeout(searchTimer);
        const value = $(this).val().toLowerCase();
        searchTimer = setTimeout(function () {
            $('.product-card').each(function () {
                const name = ($(this).data('name') || '').toString().toLowerCase();
                $(this).closest('.product-col').toggle(name.indexOf(value) > -1);
            });
        }, 200);
    });

    // -----------------------------------------------------------------
    // Compare checkbox selector
    // -----------------------------------------------------------------
    function updateCompareLink() {
        const ids = [];
        $('.compare-checkbox:checked').each(function () { ids.push($(this).val()); });
        const $bar = $('#compareBar');
        if (ids.length >= 2) {
            $bar.removeClass('d-none');
            $('#compareLink').attr('href', '/compare/?ids=' + ids.join(','));
            $('#compareCount').text(ids.length);
        } else {
            $bar.addClass('d-none');
        }
    }
    $(document).on('change', '.compare-checkbox', function () {
        if ($('.compare-checkbox:checked').length > 4) {
            $(this).prop('checked', false);
            alert('You can compare up to 4 products at a time.');
        }
        updateCompareLink();
    });

    // -----------------------------------------------------------------
    // Newsletter AJAX subscribe
    // -----------------------------------------------------------------
    $('#newsletterForm').on('submit', function (e) {
        e.preventDefault();
        const $form = $(this);
        $.ajax({
            url: $form.attr('action'),
            type: 'POST',
            data: $form.serialize(),
            headers: { 'X-CSRFToken': CSRF_TOKEN },
            success: function (data) {
                $('#newsletterMsg').text(data.message).removeClass('text-danger').addClass('text-success');
                if (data.success) { $form.trigger('reset'); }
            },
            error: function () {
                $('#newsletterMsg').text('Something went wrong. Please try again.').addClass('text-danger');
            }
        });
    });

    // -----------------------------------------------------------------
    // Bootstrap tooltips
    // -----------------------------------------------------------------
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    [...tooltipTriggerList].map(el => new bootstrap.Tooltip(el));
});
