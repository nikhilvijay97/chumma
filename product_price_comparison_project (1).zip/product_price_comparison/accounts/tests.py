from django.test import TestCase
from django.urls import reverse

from .models import User


class RegistrationTests(TestCase):
    def test_register_creates_user_and_logs_in(self):
        response = self.client.post(reverse('accounts:register'), {
            'username': 'newuser', 'first_name': 'New', 'last_name': 'User',
            'email': 'newuser@example.com', 'phone': '9999999999',
            'password1': 'ComplexPass123', 'password2': 'ComplexPass123',
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(User.objects.filter(username='newuser').exists())

    def test_duplicate_email_rejected(self):
        User.objects.create_user(username='existing', email='dupe@example.com', password='pass12345')
        response = self.client.post(reverse('accounts:register'), {
            'username': 'anotheruser', 'first_name': 'A', 'last_name': 'B', 'email': 'dupe@example.com',
            'password1': 'ComplexPass123', 'password2': 'ComplexPass123',
        })
        self.assertEqual(response.status_code, 200)
        self.assertFalse(User.objects.filter(username='anotheruser').exists())


class LoginLogoutTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='loginuser', password='pass12345')

    def test_login_success(self):
        response = self.client.post(reverse('accounts:login'), {'username': 'loginuser', 'password': 'pass12345'})
        self.assertEqual(response.status_code, 302)

    def test_profile_requires_login(self):
        response = self.client.get(reverse('accounts:profile'))
        self.assertEqual(response.status_code, 302)

    def test_profile_accessible_when_logged_in(self):
        self.client.login(username='loginuser', password='pass12345')
        response = self.client.get(reverse('accounts:profile'))
        self.assertEqual(response.status_code, 200)


class PasswordResetFlowTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='reset_me', email='reset@example.com', password='OldPass123')

    def test_password_reset_request_sends_email(self):
        response = self.client.post(reverse('accounts:password_reset'), {'email': 'reset@example.com'})
        self.assertEqual(response.status_code, 302)

    def test_password_reset_page_renders(self):
        response = self.client.get(reverse('accounts:password_reset'))
        self.assertEqual(response.status_code, 200)
