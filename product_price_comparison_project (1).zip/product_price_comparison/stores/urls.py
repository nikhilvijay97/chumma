from django.urls import path

from . import views

app_name = 'stores'

urlpatterns = [
    path('', views.store_list_public, name='store_list'),
    path('manage/', views.admin_store_list, name='admin_store_list'),
    path('manage/add/', views.admin_store_create, name='admin_store_create'),
    path('manage/<int:pk>/edit/', views.admin_store_update, name='admin_store_update'),
    path('manage/<int:pk>/delete/', views.admin_store_delete, name='admin_store_delete'),
]
