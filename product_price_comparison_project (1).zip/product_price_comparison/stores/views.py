from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render

from dashboard.utils import log_admin_action

from .forms import StoreForm
from .models import Store


def store_list_public(request):
    stores = Store.objects.filter(is_active=True).order_by('name')
    return render(request, 'stores/store_list.html', {'stores': stores})


@staff_member_required
def admin_store_list(request):
    stores = Store.objects.all().order_by('name')
    paginator = Paginator(stores, 10)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'stores/admin_store_list.html', {'page_obj': page_obj, 'stores': page_obj.object_list})


@staff_member_required
def admin_store_create(request):
    if request.method == 'POST':
        form = StoreForm(request.POST, request.FILES)
        if form.is_valid():
            store = form.save()
            log_admin_action(request.user, 'CREATE', 'Store', str(store))
            messages.success(request, f'Store "{store.name}" created successfully.')
            return redirect('stores:admin_store_list')
    else:
        form = StoreForm()
    return render(request, 'stores/admin_store_form.html', {'form': form, 'title': 'Add Store'})


@staff_member_required
def admin_store_update(request, pk):
    store = get_object_or_404(Store, pk=pk)
    if request.method == 'POST':
        form = StoreForm(request.POST, request.FILES, instance=store)
        if form.is_valid():
            form.save()
            log_admin_action(request.user, 'UPDATE', 'Store', str(store))
            messages.success(request, f'Store "{store.name}" updated successfully.')
            return redirect('stores:admin_store_list')
    else:
        form = StoreForm(instance=store)
    return render(request, 'stores/admin_store_form.html', {'form': form, 'title': 'Edit Store'})


@staff_member_required
def admin_store_delete(request, pk):
    store = get_object_or_404(Store, pk=pk)
    if request.method == 'POST':
        name = str(store)
        store.delete()
        log_admin_action(request.user, 'DELETE', 'Store', name)
        messages.success(request, f'Store "{name}" deleted.')
        return redirect('stores:admin_store_list')
    return render(request, 'stores/admin_store_confirm_delete.html', {'store': store})
