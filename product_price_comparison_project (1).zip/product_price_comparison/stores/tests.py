from django.test import TestCase
from django.urls import reverse

from accounts.models import User

from .models import Store


class StoreCrudTests(TestCase):
    def setUp(self):
        self.staff = User.objects.create_user(username='staffer', password='pass12345', is_staff=True)
        self.store = Store.objects.create(name='Amazon.in')

    def test_public_store_list(self):
        response = self.client.get(reverse('stores:store_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Amazon.in')

    def test_admin_can_create_store(self):
        self.client.login(username='staffer', password='pass12345')
        response = self.client.post(reverse('stores:admin_store_create'), {
            'name': 'Flipkart', 'website_url': 'https://www.flipkart.com', 'address': '', 'is_active': True,
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Store.objects.filter(name='Flipkart').exists())
