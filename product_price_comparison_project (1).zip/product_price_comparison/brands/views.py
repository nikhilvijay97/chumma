from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render

from dashboard.utils import log_admin_action

from .forms import BrandForm
from .models import Brand


def brand_list_public(request):
    brands = Brand.objects.filter(is_active=True).order_by('name')
    return render(request, 'brands/brand_list.html', {'brands': brands})


@staff_member_required
def admin_brand_list(request):
    brands = Brand.objects.all().order_by('name')
    paginator = Paginator(brands, 10)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'brands/admin_brand_list.html', {'page_obj': page_obj, 'brands': page_obj.object_list})


@staff_member_required
def admin_brand_create(request):
    if request.method == 'POST':
        form = BrandForm(request.POST, request.FILES)
        if form.is_valid():
            brand = form.save()
            log_admin_action(request.user, 'CREATE', 'Brand', str(brand))
            messages.success(request, f'Brand "{brand.name}" created successfully.')
            return redirect('brands:admin_brand_list')
    else:
        form = BrandForm()
    return render(request, 'brands/admin_brand_form.html', {'form': form, 'title': 'Add Brand'})


@staff_member_required
def admin_brand_update(request, pk):
    brand = get_object_or_404(Brand, pk=pk)
    if request.method == 'POST':
        form = BrandForm(request.POST, request.FILES, instance=brand)
        if form.is_valid():
            form.save()
            log_admin_action(request.user, 'UPDATE', 'Brand', str(brand))
            messages.success(request, f'Brand "{brand.name}" updated successfully.')
            return redirect('brands:admin_brand_list')
    else:
        form = BrandForm(instance=brand)
    return render(request, 'brands/admin_brand_form.html', {'form': form, 'title': 'Edit Brand'})


@staff_member_required
def admin_brand_delete(request, pk):
    brand = get_object_or_404(Brand, pk=pk)
    if request.method == 'POST':
        name = str(brand)
        brand.delete()
        log_admin_action(request.user, 'DELETE', 'Brand', name)
        messages.success(request, f'Brand "{name}" deleted.')
        return redirect('brands:admin_brand_list')
    return render(request, 'brands/admin_brand_confirm_delete.html', {'brand': brand})
