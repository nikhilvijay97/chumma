from django.test import TestCase
from django.urls import reverse

from accounts.models import User

from .models import Brand


class BrandCrudTests(TestCase):
    def setUp(self):
        self.staff = User.objects.create_user(username='staffer', password='pass12345', is_staff=True)
        self.brand = Brand.objects.create(name='Nova')

    def test_public_brand_list(self):
        response = self.client.get(reverse('brands:brand_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Nova')

    def test_admin_can_create_brand(self):
        self.client.login(username='staffer', password='pass12345')
        response = self.client.post(reverse('brands:admin_brand_create'), {
            'name': 'Skyline', 'description': '', 'is_active': True,
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Brand.objects.filter(name='Skyline').exists())
