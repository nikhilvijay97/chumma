from django.urls import path

from . import views

app_name = 'brands'

urlpatterns = [
    path('', views.brand_list_public, name='brand_list'),
    path('manage/', views.admin_brand_list, name='admin_brand_list'),
    path('manage/add/', views.admin_brand_create, name='admin_brand_create'),
    path('manage/<int:pk>/edit/', views.admin_brand_update, name='admin_brand_update'),
    path('manage/<int:pk>/delete/', views.admin_brand_delete, name='admin_brand_delete'),
]
