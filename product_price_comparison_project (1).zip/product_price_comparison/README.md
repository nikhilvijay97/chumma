# Product Price Comparison System

**MCA Final-Year Project** — A complete, production-ready **Django 5.x** web
application that lets shoppers search for a product and instantly compare its
price across multiple online stores, while giving administrators a full
custom back-office to manage the catalog, users, and view analytical reports.

Built with: **Python 3.12+ · Django 5.x · MySQL (XAMPP / phpMyAdmin) ·
Bootstrap 5 · HTML5 · CSS3 · JavaScript (jQuery) · Chart.js · Django ORM ·
Django Authentication**

---

## 1. Highlights

- **9 Django apps**, each with a single clear responsibility: `accounts`,
  `dashboard`, `products`, `categories`, `brands`, `stores`, `wishlist`,
  `contact`, `reports`.
- **Custom staff dashboard** (not just the default Django admin) — sidebar +
  topbar layout, dark/light theme toggle, stat cards, 4 live Chart.js
  visualizations, recent-activity feed.
- **Full price comparison engine** — every product can be listed at several
  stores; the storefront highlights the cheapest offer, shows the price
  difference/savings, and plots a price-history trend chart.
- **Complete CRUD** for Users, Categories, Brands, Stores, and Products
  (with image gallery + multi-store price inline formsets) from the custom
  dashboard — independent of the Django admin.
- **User activate/deactivate**, role-based access (`is_staff` vs regular
  customer), full authentication (register/login/logout/forgot
  password/change password/profile).
- **Search & filter** by product name, brand, category, price range, and
  store; sort by price or newest.
- **Wishlist**, **recently viewed products**, **featured / trending / latest
  / popular categories** sections, **search history** logging, **admin
  activity log** (`admin_logs`).
- **Contact form, feedback form, and newsletter signup**, each with a
  dedicated staff-only management view.
- **4 report pages** (User, Product, Store, Price) plus a personal "My
  Savings" report for shoppers.
- Sample data generator (`seed_data`) and an equivalent MySQL dump for
  phpMyAdmin import.

---

## 2. Project Structure

```
product_price_comparison/
├── manage.py
├── requirements.txt
├── .env.example
├── README.md
├── product_price_comparison/     # Project settings/urls/wsgi/asgi
├── accounts/                     # Custom User model, auth, profile
├── dashboard/                    # Custom staff dashboard, AdminLog, user mgmt
├── categories/                   # Category model + CRUD
├── brands/                       # Brand model + CRUD
├── stores/                       # Store model + CRUD
├── products/                     # Product, ProductImage, ProductPrice,
│                                  # PriceHistory, SearchHistory, RecentlyViewed
├── wishlist/                     # Wishlist app
├── contact/                      # ContactMessage, Feedback, Newsletter
├── reports/                      # User/Product/Store/Price reports
├── templates/                    # Global templates (base.html)
├── static/                       # Global CSS/JS
├── media/                        # Uploaded images
├── docs/                         # SRS, DFD, ER, UML, Testing, etc.
└── sql/                          # MySQL dump for phpMyAdmin import
```

Each app follows the same internal layout: `models.py`, `forms.py`,
`views.py`, `urls.py`, `admin.py`, `migrations/`, `templates/<app>/`.

---

## 3. Database Design

Database name: **`pricecomparison_db`**

| Table | App | Purpose |
|---|---|---|
| `users` | accounts | Custom user model (extends AbstractUser) |
| `categories` | categories | Product categories |
| `brands` | brands | Product brands |
| `stores` | stores | Partner stores |
| `products` | products | Product catalog |
| `product_images` | products | Product image gallery |
| `product_prices` | products | Price of a product at a store |
| `price_history` | products | Historical price snapshots |
| `search_history` | products | Logged search queries |
| `recently_viewed` | products | Per-user recently viewed products |
| `wishlist` | wishlist | User wishlist entries |
| `feedback` | contact | User feedback/ratings |
| `contact_messages` | contact | Contact-us submissions |
| `newsletter_subscribers` | contact | Newsletter signups |
| `admin_logs` | dashboard | Audit trail of admin CRUD actions |

Full ER diagram, schema notes, and relationship cardinalities are in
`docs/ER.md`. The Django `models.py` files are the source of truth; the
SQL dump in `sql/pricecomparison_db.sql` mirrors them exactly.

---

## 4. Prerequisites

- Python 3.12 or newer
- MySQL server via **XAMPP** (or standalone MySQL/MariaDB) with phpMyAdmin
- `pip` and (recommended) a virtual environment

---

## 5. Installation Guide

### Step 1 — Create a virtual environment

```bash
cd product_price_comparison
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS / Linux:
source venv/bin/activate
```

### Step 2 — Install dependencies

```bash
pip install -r requirements.txt
```

> **Windows note:** if `mysqlclient` fails to build, install a matching
> pre-compiled wheel from
> https://www.lfd.uci.edu/~gohlke/pythonlibs/#mysqlclient, or run
> `pip install mysqlclient --only-binary :all:`.

### Step 3 — Start MySQL via XAMPP and create the database

1. Open the **XAMPP Control Panel** and start **Apache** and **MySQL**.
2. Open **phpMyAdmin** at `http://localhost/phpmyadmin`.
3. Click **New**, name the database `pricecomparison_db`, choose collation
   `utf8mb4_unicode_ci`, and click **Create**.
   - *Alternatively*, import the ready-made dump in `sql/` (see §8), which
     creates the database, full schema, **and** sample data in one step.

### Step 4 — Configure environment variables

```bash
cp .env.example .env        # macOS/Linux
copy .env.example .env      # Windows
```

Edit `.env` if your MySQL credentials differ from the XAMPP defaults
(`root` user, empty password, host `127.0.0.1`, port `3306`).

### Step 5 — Run migrations

*(Skip if you imported the SQL dump from `sql/` instead — see §8.)*

```bash
python manage.py makemigrations
python manage.py migrate
```

### Step 6 — Create an admin superuser

```bash
python manage.py createsuperuser
```

### Step 7 — Load sample data (optional but recommended)

```bash
python manage.py seed_data
```

Creates sample categories, brands, stores, products (with specs & price
history), 3 demo customer accounts (`john_doe`, `priya_sharma`,
`amit_kumar` — password `Password@123`), a default admin
(`admin` / `Admin@12345` if one doesn't already exist), plus sample contact
messages, feedback, and newsletter subscribers.

### Step 8 — Collect static files (for production-style serving)

```bash
python manage.py collectstatic --noinput
```

### Step 9 — Run the development server

```bash
python manage.py runserver
```

Visit:
- Storefront: http://127.0.0.1:8000/
- Custom staff dashboard: http://127.0.0.1:8000/dashboard/
- Django admin: http://127.0.0.1:8000/django-admin/

---

## 6. Quick Start with SQLite (no MySQL required)

For a fast local trial without setting up MySQL, set `USE_SQLITE=True` in
`.env`, then run steps 5–9 above. Switch back to `USE_SQLITE=False` (and
configure MySQL) before final submission/deployment.

---

## 7. Running Tests

```bash
python manage.py test
```

Every app (`accounts`, `categories`, `brands`, `stores`, `products`,
`wishlist`, `contact`, `dashboard`, `reports`) ships with its own
`tests.py` covering models, views, and access control. See
`docs/TESTING.md` for the full test plan.

---

## 8. Importing the MySQL Dump via phpMyAdmin

1. Unzip the SQL dump archive to get `pricecomparison_db.sql`.
2. In phpMyAdmin, create an empty database named `pricecomparison_db`
   (utf8mb4_unicode_ci), or let the script create it — the dump begins with
   `CREATE DATABASE IF NOT EXISTS`.
3. Select the database → **Import** tab → choose the `.sql` file → **Go**.
4. The dump creates every table (matching Django's migrations exactly) and
   inserts sample categories, brands, stores, products, prices, price
   history, users, wishlist rows, feedback, and contact messages.
5. The dump already contains the **complete schema** (Django core tables +
   every app table) — it is a full replacement for `python manage.py
   migrate`. **Do not run `migrate` afterwards** on the same database;
   either import the dump *or* run `migrate` + `seed_data` on a fresh empty
   database, not both.
6. The password hashes in the dump are illustrative placeholders. After
   importing, run `python manage.py changepassword admin` to set a real
   password, or use `seed_data` on a freshly migrated database instead
   (which sets real, working password hashes).

---

## 9. Key URLs

| URL | Description |
|---|---|
| `/` | Home page (featured/trending/latest products, categories) |
| `/products/` | All products — search, filter, sort |
| `/product/<slug>/` | Product detail — price comparison, specs, chart |
| `/category/<slug>/`, `/brand/<slug>/` | Filtered product listings |
| `/compare/?ids=1,2,3` | Side-by-side product comparison |
| `/stores/` | Partner store directory |
| `/wishlist/` | Logged-in user's wishlist |
| `/accounts/login/`, `/register/`, `/profile/`, `/change-password/`, `/password-reset/` | Auth |
| `/contact/`, `/contact/feedback/` | Contact & feedback forms |
| `/dashboard/` | Custom staff dashboard home |
| `/dashboard/users/` | Manage users (add/edit/delete/activate/deactivate) |
| `/categories/manage/`, `/brands/manage/`, `/stores/manage/`, `/products/manage/products/` | Staff CRUD |
| `/reports/users/`, `/products/`, `/stores/`, `/prices/` | Staff reports |
| `/reports/my-savings/` | Personal savings report |
| `/django-admin/` | Default Django admin |

---

## 10. Documentation

Full project documentation is in the `docs/` folder:

- `ABSTRACT.md` — Project abstract
- `PROBLEM_STATEMENT.md` — Problem statement & objectives
- `SRS.md` — Software Requirements Specification
- `DFD.md` — Data Flow Diagrams (Level 0 & Level 1)
- `ER.md` — Entity-Relationship diagram & schema notes
- `UML.md` — Use case, class, and sequence diagrams
- `TESTING.md` — Test plan and test cases
- `FUTURE_SCOPE.md` — Future enhancements & conclusion

---

## 11. Default Credentials (sample data only — change before submission/demo)

| Role | Username | Password |
|---|---|---|
| Admin (staff) | `admin` | `Admin@12345` |
| Customer | `john_doe` | `Password@123` |
| Customer | `priya_sharma` | `Password@123` |
| Customer | `amit_kumar` | `Password@123` |

---

## 12. License

Provided as-is for academic (MCA final-year project) and evaluation
purposes.
