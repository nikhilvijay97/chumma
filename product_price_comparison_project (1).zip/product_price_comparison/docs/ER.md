# Entity-Relationship Diagram (ER)
## Product Price Comparison System — Database: pricecomparison_db

---

## ER Diagram

```mermaid
erDiagram
    USER ||--o{ WISHLIST : "adds"
    USER ||--o{ FEEDBACK : "submits"
    USER ||--o{ SEARCH_HISTORY : "performs"
    USER ||--o{ RECENTLY_VIEWED : "views"
    USER ||--o{ ADMIN_LOG : "performs (if staff)"

    CATEGORY ||--o{ PRODUCT : "classifies"
    BRAND ||--o{ PRODUCT : "manufactures"
    PRODUCT ||--o{ PRODUCT_IMAGE : "has"
    PRODUCT ||--o{ PRODUCT_PRICE : "listed as"
    PRODUCT ||--o{ WISHLIST : "saved in"
    PRODUCT ||--o{ RECENTLY_VIEWED : "appears in"

    STORE ||--o{ PRODUCT_PRICE : "offers"
    PRODUCT_PRICE ||--o{ PRICE_HISTORY : "tracked by"

    USER {
        bigint id PK
        varchar username UK
        varchar email
        varchar password
        varchar phone
        varchar city
        text address
        varchar avatar
        boolean is_verified
        boolean is_staff
        boolean is_active
        datetime date_joined
    }

    CATEGORY {
        bigint id PK
        varchar name UK
        varchar slug UK
        text description
        varchar icon
        varchar image
        boolean is_active
    }

    BRAND {
        bigint id PK
        varchar name UK
        varchar slug UK
        varchar logo
        text description
        boolean is_active
    }

    STORE {
        bigint id PK
        varchar name UK
        varchar slug UK
        varchar logo
        varchar website_url
        text address
        boolean is_active
    }

    PRODUCT {
        bigint id PK
        varchar name
        varchar slug UK
        bigint category_id FK
        bigint brand_id FK
        text description
        text specifications
        boolean is_featured
        boolean is_trending
        boolean is_active
        datetime created_at
    }

    PRODUCT_IMAGE {
        bigint id PK
        bigint product_id FK
        varchar image
        varchar alt_text
        boolean is_primary
    }

    PRODUCT_PRICE {
        bigint id PK
        bigint product_id FK
        bigint store_id FK
        decimal price
        decimal old_price
        varchar product_url
        boolean in_stock
        datetime updated_at
    }

    PRICE_HISTORY {
        bigint id PK
        bigint product_price_id FK
        decimal price
        datetime recorded_at
    }

    SEARCH_HISTORY {
        bigint id PK
        bigint user_id FK "nullable"
        varchar query
        int results_count
        datetime created_at
    }

    RECENTLY_VIEWED {
        bigint id PK
        bigint user_id FK
        bigint product_id FK
        datetime viewed_at
    }

    WISHLIST {
        bigint id PK
        bigint user_id FK
        bigint product_id FK
        decimal target_price
        datetime added_at
    }

    FEEDBACK {
        bigint id PK
        bigint user_id FK "nullable"
        varchar name
        varchar email
        smallint rating
        text message
        datetime created_at
    }

    CONTACT_MESSAGE {
        bigint id PK
        varchar name
        varchar email
        varchar subject
        text message
        boolean is_read
        datetime created_at
    }

    ADMIN_LOG {
        bigint id PK
        bigint user_id FK "nullable"
        varchar action
        varchar model_name
        varchar object_repr
        datetime timestamp
    }
```

---

## Relationship Summary

| Relationship | Cardinality | Notes |
|---|---|---|
| Category → Product | 1 : N | A category has many products; a product belongs to exactly one category. |
| Brand → Product | 1 : N | A brand has many products; `brand_id` is nullable (SET_NULL on delete). |
| Product → ProductImage | 1 : N | Multiple images per product; one flagged `is_primary`. |
| Store → ProductPrice | 1 : N | A store lists many product prices. |
| Product → ProductPrice | 1 : N | `(product, store)` is unique — one price row per store per product. |
| ProductPrice → PriceHistory | 1 : N | Every price change is snapshotted. |
| User → Wishlist | 1 : N | `(user, product)` unique — no duplicate wishlist entries. |
| Product → Wishlist | 1 : N | A product can be wishlisted by many users. |
| User → RecentlyViewed | 1 : N | `(user, product)` unique, `viewed_at` updated on re-view. |
| User → SearchHistory | 1 : N | `user_id` nullable — guests can also search. |
| User → Feedback | 1 : N | `user_id` nullable — feedback can be submitted anonymously by name/email. |
| User → AdminLog | 1 : N | `user_id` nullable (SET_NULL) so logs survive user deletion. |

---

## Key Constraints & Indexes

- `Product.slug`, `Category.slug`, `Brand.slug`, `Store.slug` — unique,
  auto-generated via `slugify()` on save, with collision suffixing for
  products.
- `ProductPrice` — `unique_together = (product, store)`.
- `Wishlist` — `unique_together = (user, product)`.
- `RecentlyViewed` — `unique_together = (user, product)`.
- `Product` has DB indexes on `name`, `category_id`, and `brand_id` to
  speed up search and filtering.
- `AdminLog.user` uses `on_delete=SET_NULL` so the audit trail is
  preserved even if the acting user account is later deleted.

## Normalization Notes

The schema is normalized to 3NF:
- Store/price data is factored out of `Product` into `ProductPrice`
  (resolves the Product ↔ Store many-to-many with attributes: price,
  old_price, stock, URL).
- Historical prices are factored out of `ProductPrice` into `PriceHistory`
  so trend data doesn't bloat or overwrite the "current price" row.
- Product images are factored into their own table (`ProductImage`) to
  support an unbounded gallery per product instead of a single image
  column.
- User profile fields live directly on the custom `User` model (1:1,
  no optional/pluggable profile types required).
