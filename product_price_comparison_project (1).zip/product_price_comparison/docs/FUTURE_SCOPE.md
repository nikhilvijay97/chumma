# Future Scope & Conclusion

## Future Scope

1. **Live price scraping / store API integration** — replace manually
   entered `ProductPrice` rows with a scheduled scraper or partner API
   feed so prices stay current automatically.
2. **Price-drop email/SMS alerts** — use the existing `Wishlist.target_price`
   field to trigger notifications (via Celery + Django email/SMS gateway)
   when a tracked product drops to or below the target price.
3. **REST API (Django REST Framework)** — expose the catalog, prices, and
   wishlist as a JSON API to support a future mobile app.
4. **Payment/affiliate integration** — turn store "Buy Now" links into
   trackable affiliate links to monetize the platform.
5. **User reviews with verified-purchase badges** — extend `Feedback` into
   a full per-product review system with moderation.
6. **Multi-currency & multi-region support** — store prices in their
   original currency and convert for display based on user locale.
7. **Elasticsearch-backed search** — replace basic `icontains` queries
   with a dedicated search index for typo-tolerance and relevance ranking.
8. **Advanced analytics** — cohort analysis, conversion funnels, and
   export-to-Excel/PDF for the existing report pages.
9. **Two-factor authentication** for staff accounts to harden the admin
   dashboard.
10. **Automated CI/CD pipeline** — GitHub Actions running `manage.py test`
    and deploying to a staging server on every push.

## Conclusion

The Product Price Comparison System successfully demonstrates a complete,
production-structured Django application built around a real consumer
problem: price fragmentation across online stores. By combining a clean,
normalized MySQL schema, Django's built-in authentication and ORM, a
responsive Bootstrap 5 interface, and jQuery/Chart.js-driven interactivity,
the project delivers both a genuinely useful shopper-facing tool and a
full-featured administrative back office — including a purpose-built
dashboard distinct from the default Django admin, complete CRUD workflows,
an audit trail, and analytical reporting.

The modular app structure (`accounts`, `dashboard`, `products`,
`categories`, `brands`, `stores`, `wishlist`, `contact`, `reports`) keeps
each concern isolated and independently testable, while shared context
processors and a consistent template inheritance hierarchy keep the UI
coherent across nearly 60 templates. The accompanying documentation set —
SRS, DFD, ER, UML, and a test plan — reflects the system exactly as
implemented, making the project suitable both for academic evaluation and
as a solid foundation for further real-world development.
