# Data Flow Diagrams (DFD)
## Product Price Comparison System

---

## Level 0 — Context Diagram

```mermaid
flowchart LR
    Guest[Guest / Shopper]
    Customer[Registered Customer]
    Admin[Admin / Staff]

    System((Product Price\nComparison System))

    Guest -- Browse / Search / Compare --> System
    System -- Product & Price Data --> Guest

    Customer -- Login, Wishlist, Feedback --> System
    System -- Personalized Views, Savings Report --> Customer

    Admin -- Manage Catalog, Users, Prices --> System
    System -- Dashboard, Charts, Reports --> Admin

    System <-- Read/Write --> DB[(MySQL: pricecomparison_db)]
```

---

## Level 1 — Major Process Decomposition

```mermaid
flowchart TB
    subgraph Users
        G[Guest]
        C[Customer]
        A[Admin]
    end

    P1([1.0 Authentication\nRegister / Login / Forgot Password / Profile])
    P2([2.0 Catalog Browsing\nSearch / Filter / Sort])
    P3([3.0 Price Comparison\nDetail View / Compare / Price History])
    P4([4.0 Wishlist Management])
    P5([5.0 Contact & Feedback])
    P6([6.0 Custom Admin Dashboard\nCRUD: Category/Brand/Store/Product/User])
    P7([7.0 Reports & Analytics])

    D1[(users)]
    D2[(categories)]
    D3[(brands)]
    D4[(stores)]
    D5[(products)]
    D6[(product_images)]
    D7[(product_prices)]
    D8[(price_history)]
    D9[(wishlist)]
    D10[(feedback / contact_messages)]
    D11[(admin_logs)]
    D12[(search_history / recently_viewed)]

    G --> P2
    C --> P1
    C --> P4
    C --> P5
    C --> P7
    A --> P6
    A --> P7

    P1 <--> D1
    P2 --> D2
    P2 --> D3
    P2 --> D5
    P2 --> D7
    P2 --> D12
    P3 --> D5
    P3 --> D7
    P3 --> D8
    P4 <--> D9
    P4 --> D5
    P5 <--> D10
    P6 <--> D1
    P6 <--> D2
    P6 <--> D3
    P6 <--> D4
    P6 <--> D5
    P6 <--> D6
    P6 <--> D7
    P6 --> D8
    P6 --> D11
    P7 --> D1
    P7 --> D5
    P7 --> D4
    P7 --> D7
    P7 --> D9
```

---

## Level 2 — Process 3.0 "Price Comparison" (Detail)

```mermaid
flowchart LR
    U[User] -->|GET /product/<slug>/| V[product_detail_view]
    V -->|Query| DB5[(products)]
    V -->|Query| DB7[(product_prices + store)]
    V -->|Compute min/max/avg/savings| Calc[Price Aggregation Logic]
    Calc --> V
    V -->|Render| T[product_detail.html]
    T -->|AJAX GET /api/price-history/id/id/| API[price_history_json view]
    API -->|Query| DB8[(price_history)]
    API -->|JSON| Chart[Chart.js Line Chart]
```

---

## Level 2 — Process 6.0 "Custom Admin Dashboard — Product CRUD" (Detail)

```mermaid
flowchart LR
    Admin[Staff User] -->|GET/POST /products/manage/products/add/| V[admin_product_create]
    V -->|ProductForm| F1[Product fields]
    V -->|ProductImageFormSet| F2[Multiple images]
    V -->|ProductPriceFormSet| F3[Multiple store prices]
    F1 & F2 & F3 -->|is_valid + save| DB[(products, product_images, product_prices)]
    V -->|log_admin_action| Log[(admin_logs)]
    V -->|redirect| List[admin_product_list.html]
```

---

## Level 2 — Process 4.0 "Wishlist Management" (Detail)

```mermaid
flowchart LR
    U[Logged-in User] -->|Click heart icon| JS[jQuery AJAX POST\n/wishlist/toggle/id/]
    JS --> V[toggle_wishlist view]
    V -->|get_or_create / delete| DB9[(wishlist table)]
    V -->|JSON response added, count| JS
    JS -->|Update icon + navbar badge| UI[Product Card / Navbar]
```
