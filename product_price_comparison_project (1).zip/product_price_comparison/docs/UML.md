# UML Diagrams
## Product Price Comparison System

---

## 1. Use Case Diagram

```mermaid
flowchart LR
    Guest((Guest))
    Customer((Registered\nCustomer))
    Admin((Admin / Staff))

    subgraph "Product Price Comparison System"
        UC1(Browse / Search Products)
        UC2(View Price Comparison)
        UC3(Compare Multiple Products)
        UC4(Register / Login / Forgot Password)
        UC5(Manage Profile / Change Password)
        UC6(Add/Remove Wishlist Item)
        UC7(View Wishlist / My Savings)
        UC8(Submit Contact Message / Feedback)
        UC9(Subscribe to Newsletter)
        UC10(Manage Categories/Brands/Stores)
        UC11(Manage Products & Prices)
        UC12(Manage Users)
        UC13(View Dashboard & Charts)
        UC14(View Reports)
    end

    Guest --> UC1
    Guest --> UC2
    Guest --> UC3
    Guest --> UC4
    Guest --> UC8
    Guest --> UC9

    Customer --> UC1
    Customer --> UC2
    Customer --> UC3
    Customer --> UC5
    Customer --> UC6
    Customer --> UC7
    Customer --> UC8

    Admin --> UC10
    Admin --> UC11
    Admin --> UC12
    Admin --> UC13
    Admin --> UC14
```

---

## 2. Class Diagram (Domain Model)

```mermaid
classDiagram
    class User {
        +bigint id
        +string username
        +string email
        +string phone
        +string city
        +string address
        +bool is_staff
        +bool is_verified
        +full_name()
    }

    class Category {
        +bigint id
        +string name
        +string slug
        +string icon
        +product_count()
    }

    class Brand {
        +bigint id
        +string name
        +string slug
        +product_count()
    }

    class Store {
        +bigint id
        +string name
        +string slug
        +string website_url
        +listing_count()
    }

    class Product {
        +bigint id
        +string name
        +string slug
        +text description
        +text specifications
        +bool is_featured
        +bool is_trending
        +lowest_price()
        +highest_price()
        +average_price()
        +max_savings()
        +specifications_list()
        +primary_image()
    }

    class ProductImage {
        +bigint id
        +ImageField image
        +bool is_primary
    }

    class ProductPrice {
        +bigint id
        +decimal price
        +decimal old_price
        +bool in_stock
        +discount_percent()
    }

    class PriceHistory {
        +bigint id
        +decimal price
        +datetime recorded_at
    }

    class Wishlist {
        +bigint id
        +decimal target_price
        +datetime added_at
    }

    class Feedback {
        +bigint id
        +smallint rating
        +text message
    }

    class ContactMessage {
        +bigint id
        +string subject
        +text message
        +bool is_read
    }

    class AdminLog {
        +bigint id
        +string action
        +string model_name
        +string object_repr
    }

    Category "1" --> "many" Product : classifies
    Brand "1" --> "many" Product : manufactures
    Product "1" --> "many" ProductImage : has
    Product "1" --> "many" ProductPrice : listed_as
    Store "1" --> "many" ProductPrice : offers
    ProductPrice "1" --> "many" PriceHistory : tracked_by
    User "1" --> "many" Wishlist : owns
    Product "1" --> "many" Wishlist : saved_in
    User "1" --> "many" Feedback : writes
    User "1" --> "many" AdminLog : performs
```

---

## 3. Sequence Diagram — View Product & Compare Prices

```mermaid
sequenceDiagram
    actor U as User (Browser)
    participant V as product_detail_view
    participant M as Product / ProductPrice (ORM)
    participant DB as MySQL

    U->>V: GET /product/<slug>/
    V->>M: Product.objects.select_related(category, brand).prefetch_related(prices__store, images)
    M->>DB: SELECT ... JOIN ...
    DB-->>M: rows
    M-->>V: Product + related querysets
    V->>V: compute cheapest, avg, savings
    V-->>U: render product_detail.html (comparison table + chart canvas)
    U->>V: AJAX GET /api/price-history/<pid>/<sid>/
    V->>M: PriceHistory.objects.filter(...).order_by(recorded_at)
    M->>DB: SELECT ...
    DB-->>M: rows
    M-->>V: history queryset
    V-->>U: JSON {labels, prices}
    U->>U: Chart.js renders line chart
```

---

## 4. Sequence Diagram — Admin Creates a Product with Prices

```mermaid
sequenceDiagram
    actor A as Admin (Browser)
    participant V as admin_product_create view
    participant PF as ProductForm
    participant IF as ProductImageFormSet
    participant PPF as ProductPriceFormSet
    participant DB as MySQL
    participant Log as AdminLog

    A->>V: POST /products/manage/products/add/ (name, category, images[], prices[])
    V->>PF: validate product fields
    PF-->>V: valid
    V->>DB: save Product
    V->>IF: bind to saved Product, validate images
    IF-->>V: valid
    V->>DB: save ProductImage rows
    V->>PPF: bind to saved Product, validate prices
    PPF-->>V: valid
    V->>DB: save ProductPrice rows
    V->>Log: log_admin_action(user, CREATE, Product, name)
    Log->>DB: INSERT admin_logs row
    V-->>A: redirect to admin_product_list with success message
```

---

## 5. Sequence Diagram — AJAX Wishlist Toggle

```mermaid
sequenceDiagram
    actor U as User (Browser)
    participant JS as main.js (jQuery)
    participant V as toggle_wishlist view
    participant M as Wishlist (ORM)
    participant DB as MySQL

    U->>JS: Click heart icon on product card
    JS->>V: POST /wishlist/toggle/<product_id>/ (X-CSRFToken header)
    V->>M: Wishlist.objects.get_or_create(user, product)
    M->>DB: SELECT / INSERT or DELETE
    DB-->>M: result
    M-->>V: (item, created)
    V-->>JS: JSON {added, wishlist_count}
    JS->>JS: toggle icon class, update navbar badge
```

---

## 6. Activity Diagram — Registration, Search & Wishlist

```mermaid
flowchart TD
    Start([Start]) --> A[Visit /accounts/register/]
    A --> B{Form valid?}
    B -- No --> A
    B -- Yes --> C[Create User, hash password]
    C --> D[Auto-login]
    D --> E[Redirect to Home]
    E --> F[Search / Filter Products]
    F --> G[View Product Detail]
    G --> H{Click wishlist heart?}
    H -- No --> F
    H -- Yes --> I[AJAX POST toggle wishlist]
    I --> J[Wishlist row created]
    J --> K[Heart icon turns red / badge updates]
    K --> End([End])
```
