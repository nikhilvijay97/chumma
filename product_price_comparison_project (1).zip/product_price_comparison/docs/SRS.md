# Software Requirements Specification (SRS)
## Product Price Comparison System

**Version:** 1.0 | **Prepared for:** MCA Final-Year Project

---

## 1. Introduction

### 1.1 Purpose
This document specifies the functional and non-functional requirements of
the Product Price Comparison System, a web application that lets shoppers
compare product prices across multiple partner stores, manage a wishlist,
submit feedback, and lets administrators manage the catalog through a
custom staff dashboard.

### 1.2 Scope
The system will:
- Present a searchable catalog of products organized by category and brand.
- Show the price of each product at multiple partner stores, highlight the
  cheapest, and show potential savings.
- Track historical price changes and visualize trends.
- Let registered users maintain a wishlist and view a personal savings report.
- Let registered users submit contact messages and feedback.
- Give administrators a dedicated dashboard for full CRUD management of
  categories, brands, stores, products, and users, plus analytical reports.

### 1.3 Intended Audience
End users (shoppers), administrators/staff, and evaluators/developers.

### 1.4 Definitions & Abbreviations
| Term | Meaning |
|---|---|
| SRS | Software Requirements Specification |
| CRUD | Create, Read, Update, Delete |
| ORM | Object-Relational Mapping |
| AJAX | Asynchronous JavaScript and XML |
| DFD | Data Flow Diagram |
| ERD | Entity Relationship Diagram |

---

## 2. Overall Description

### 2.1 User Classes
| Class | Description |
|---|---|
| Guest | Unauthenticated visitor; can browse, search, and compare products |
| Registered Customer | Can additionally maintain a wishlist, submit feedback/contact messages, view a personal savings report |
| Staff/Admin | Can manage categories, stores, brands, products, prices, and users via the custom dashboard; can view reports |

### 2.2 Operating Environment
- Server: Python 3.12+, Django 5.x, MySQL 8 (via XAMPP for local development).
- Client: Any modern desktop or mobile browser (Bootstrap 5 responsive layout).

### 2.3 Assumptions & Dependencies
- MySQL server is reachable using the credentials configured in `.env`.
- Bootstrap, jQuery, Bootstrap Icons, and Chart.js are loaded via CDN in
  development (can be vendored locally for offline/production use).

---

## 3. Functional Requirements

### FR-1 Authentication & Accounts
- FR-1.1 Register with username, name, email, phone, password (validated, hashed).
- FR-1.2 Login / Logout.
- FR-1.3 Forgot Password — email-based reset link (token-based, single use).
- FR-1.4 Change Password while logged in.
- FR-1.5 View and edit profile (name, email, phone, city, address, avatar).

### FR-2 Product Catalog & Search
- FR-2.1 Display products grouped by category, with brand shown.
- FR-2.2 Full-text search across product name, brand, category, description.
- FR-2.3 Filter by category, brand, store, and price range.
- FR-2.4 Sort by price (asc/desc), newest, or name.
- FR-2.5 Product detail page lists every store price, highlights the
  lowest, shows discount badges, and displays parsed specifications.
- FR-2.6 Each search is logged to `search_history` with a result count.

### FR-3 Price Comparison
- FR-3.1 Compute and display the lowest, highest, and average listed price.
- FR-3.2 Display potential savings (highest − lowest) on the card and detail page.
- FR-3.3 Provide a side-by-side comparison view for up to 4 selected products.
- FR-3.4 Record a `PriceHistory` snapshot whenever a store price changes
  (auto-logged from the Django admin's `ProductPriceAdmin.save_model`),
  exposed via a JSON API for the price-trend chart.

### FR-4 Wishlist
- FR-4.1 Add/remove a product from the wishlist via AJAX, no full reload.
- FR-4.2 View all wishlisted products with current best price.
- FR-4.3 Optionally set a target price per wishlist item.
- FR-4.4 View a personal "My Savings" report summarizing wishlist savings.

### FR-5 Contact & Feedback
- FR-5.1 Submit a contact message (name, email, subject, message).
- FR-5.2 Submit feedback with a 1–5 star rating and comment.
- FR-5.3 Subscribe to the newsletter via AJAX from the footer.
- FR-5.4 Staff can view, mark-as-read, and delete contact messages; view
  feedback and average rating; view newsletter subscribers.

### FR-6 Custom Staff Dashboard
- FR-6.1 Show aggregate counts: users, products, categories, brands,
  stores, price records, wishlist items, unread messages.
- FR-6.2 Chart average price per category (bar), listings per store (pie),
  category distribution (doughnut), and user signups over the last 6
  months (line) — each backed by a dedicated JSON endpoint.
- FR-6.3 List recent admin activity (from `admin_logs`), recent users, and
  recent products.
- FR-6.4 Full CRUD (add/edit/delete) for Categories, Brands, and Stores.
- FR-6.5 Full CRUD for Products, including multiple image uploads and
  multiple store prices, managed via Django inline formsets.
- FR-6.6 Manage Users: add, edit, delete, activate, deactivate — every
  action recorded to `admin_logs`.
- FR-6.7 Every successful login is recorded to `admin_logs` via a Django signal.

### FR-7 Reports
- FR-7.1 User Report — all users with wishlist/search activity counts.
- FR-7.2 Product Report — all products with best price, listing count,
  wishlist count.
- FR-7.3 Store Report — all stores with listing count and average price.
- FR-7.4 Price Report — most recently updated price records, aggregate
  average price, out-of-stock count.

---

## 4. Non-Functional Requirements

| ID | Requirement |
|---|---|
| NFR-1 | Responsive UI (mobile/tablet/desktop) via Bootstrap 5's grid. |
| NFR-2 | Passwords stored using Django's PBKDF2 hasher (default). |
| NFR-3 | All state-changing requests are CSRF-protected. |
| NFR-4 | Listing pages are paginated (10–12 items/page). |
| NFR-5 | MySQL uses `utf8mb4` for full Unicode support. |
| NFR-6 | SQLite fallback (`USE_SQLITE=True`) for quick local evaluation. |
| NFR-7 | Static/media files served via Django's staticfiles app in dev, `collectstatic` output in production. |
| NFR-8 | Dashboard supports both dark and light themes (persisted client-side). |
| NFR-9 | Staff-only views are protected with `@staff_member_required`. |

---

## 5. External Interface Requirements

### 5.1 Internal JSON APIs (session-authenticated where noted)
| Endpoint | Method | Purpose |
|---|---|---|
| `/api/price-history/<product_id>/<store_id>/` | GET | Price trend data for Chart.js |
| `/wishlist/toggle/<product_id>/` | POST | Add/remove wishlist item (AJAX) |
| `/contact/newsletter/subscribe/` | POST | Newsletter subscribe (AJAX) |
| `/dashboard/api/chart/category-avg-price/` | GET | Dashboard bar chart data (staff) |
| `/dashboard/api/chart/store-listing-count/` | GET | Dashboard pie chart data (staff) |
| `/dashboard/api/chart/category-distribution/` | GET | Dashboard doughnut chart data (staff) |
| `/dashboard/api/chart/user-signups/` | GET | Dashboard line chart data (staff) |

---

## 6. Data Requirements (summary — see ER.md for full detail)

`User`, `Category`, `Brand`, `Store`, `Product`, `ProductImage`,
`ProductPrice`, `PriceHistory`, `SearchHistory`, `RecentlyViewed`,
`Wishlist`, `ContactMessage`, `Feedback`, `NewsletterSubscriber`, `AdminLog`.

---

## 7. Future Enhancements (out of scope for v1.0)
See `docs/FUTURE_SCOPE.md`.
