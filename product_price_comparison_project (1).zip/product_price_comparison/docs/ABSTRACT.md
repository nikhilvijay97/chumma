# Abstract

**Project Title:** Product Price Comparison System
**Category:** Web Application (MCA Final-Year Project)
**Technology Stack:** Python, Django 5.x, MySQL, Bootstrap 5, JavaScript, jQuery

Online shoppers today are faced with dozens of e-commerce platforms, each
listing the same product at a different price. Manually visiting every
store to find the best deal is time-consuming and error-prone, and most
shoppers end up overpaying simply because they didn't check one more site.

The **Product Price Comparison System** solves this problem by aggregating
product listings from multiple partner stores into a single searchable
catalog. For any given product, the system displays the price offered by
every partner store side by side, automatically highlights the cheapest
option, calculates the potential savings, and plots a historical price
trend so shoppers can judge whether now is a good time to buy.

Beyond price comparison, the system offers a complete shopping-support
experience: keyword/category/brand/price-range search and filtering, a
personal wishlist with price-drop tracking, product reviews via a feedback
module, recently-viewed and trending product sections, and a newsletter
signup. Registered users get a full account management experience —
registration, login, forgot-password recovery, profile editing, and
password change — all secured through Django's built-in authentication
framework with CSRF protection and hashed passwords.

On the administrative side, the system provides a **custom-built staff
dashboard** — distinct from the default Django admin — offering an at-a-
glance view of platform statistics (users, products, categories, brands,
stores, price records), interactive Chart.js visualizations (average price
per category, listings per store, category distribution, monthly
signups), and full CRUD management of categories, brands, stores, products
(with multi-image upload and multi-store price entry via inline formsets),
and users (including activation/deactivation). An admin activity log
records every create/update/delete action for accountability, and four
dedicated report pages (User, Product, Store, Price) give administrators a
tabular, exportable view of the underlying data for business analysis.

The system is built on Django 5.x with a MySQL relational backend (deployed
locally via XAMPP/phpMyAdmin for development), styled with Bootstrap 5 for
a fully responsive, mobile-friendly interface, and enhanced with jQuery for
AJAX interactions (wishlist toggling, live search filtering, newsletter
subscription) and Chart.js for data visualization. The result is a
production-ready, professionally structured reference implementation
suitable for both academic evaluation and real-world extension.
