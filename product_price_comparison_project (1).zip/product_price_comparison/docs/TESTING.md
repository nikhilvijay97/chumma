# Testing Document
## Product Price Comparison System

---

## 1. Test Strategy

- **Unit tests** — Django `TestCase` classes covering model logic
  (`lowest_price`, `max_savings`, slug generation, spec parsing).
- **Integration tests** — Django test client exercising full request/
  response cycles (search, filter, wishlist toggle, CRUD forms, access
  control on staff-only views).
- **Manual/UI tests** — checklist-driven manual verification of Bootstrap
  layout, AJAX interactions, dark/light theme, and Chart.js rendering.

Run the full automated suite with:

```bash
python manage.py test
```

Every app ships its own `tests.py`: `accounts`, `categories`, `brands`,
`stores`, `products`, `wishlist`, `contact`, `dashboard`, `reports`.

---

## 2. Test Environment

| Item | Value |
|---|---|
| Python | 3.12+ |
| Django | 5.0.x |
| Database | MySQL 8 (XAMPP) or SQLite (`USE_SQLITE=True`) for CI/test runs |
| Browsers | Chrome, Firefox, Edge (latest) |

---

## 3. Sample Automated Test Cases

| ID | Module | Test | Expected Result |
|---|---|---|---|
| UT-01 | products.models | `Product.lowest_price` returns the in-stock price with the smallest amount | Correct object; `None` when no prices exist |
| UT-02 | products.models | `Product.max_savings` computes `highest - lowest` | `0.00` when only one price exists |
| UT-03 | products.models | `Product.save()` de-duplicates slug on name collision | Second product with same name gets a suffixed slug |
| UT-04 | products.models | `specifications_list` parses "Key: Value" lines | Returns list of `(key, value)` tuples |
| UT-05 | accounts.forms | `RegisterForm` rejects duplicate email | `ValidationError` on `clean_email` |
| IT-01 | products.views | `GET /` and `GET /products/` return 200 | Products present in context |
| IT-02 | products.views | `GET /products/?q=<term>` filters by name/brand/category | Only matching products returned |
| IT-03 | products.views | `GET /product/<slug>/` shows price table ordered by price | Cheapest price highlighted |
| IT-04 | wishlist.views | `POST /wishlist/toggle/<id>/` while logged out | Redirects to login (302) |
| IT-05 | wishlist.views | `POST /wishlist/toggle/<id>/` while logged in (AJAX) | JSON `{added, wishlist_count}`; toggles on repeat call |
| IT-06 | categories/brands/stores.views | Staff CRUD create/update/delete | Object created/updated/removed; non-staff blocked |
| IT-07 | products.views | Staff can create a Product with image/price formsets | Product + related rows saved atomically |
| IT-08 | dashboard.views | `GET /dashboard/` as non-staff user | Redirect (permission denied) |
| IT-09 | dashboard.views | `GET /dashboard/` as staff user | 200; aggregate counts present |
| IT-10 | dashboard.views | `POST /dashboard/users/<id>/toggle-active/` | `is_active` flips; `admin_logs` row created |
| IT-11 | contact.views | `POST /contact/` and `/contact/feedback/` with valid data | `ContactMessage`/`Feedback` row created |
| IT-12 | contact.views | `POST /contact/newsletter/subscribe/` (AJAX) | `NewsletterSubscriber` row created |
| IT-13 | reports.views | All 4 report pages return 200 for staff, redirect for guests | As described |
| IT-14 | accounts.views | Forgot-password request returns 302 and does not error | Reset email "sent" via console backend |

---

## 4. Example Test Code

```python
from decimal import Decimal
from django.test import TestCase
from categories.models import Category
from stores.models import Store
from products.models import Product, ProductPrice


class ProductPriceLogicTests(TestCase):
    def setUp(self):
        self.category = Category.objects.create(name='Test Category')
        self.store_a = Store.objects.create(name='Store A')
        self.store_b = Store.objects.create(name='Store B')
        self.product = Product.objects.create(name='Test Product', category=self.category)
        ProductPrice.objects.create(product=self.product, store=self.store_a, price=Decimal('100.00'))
        ProductPrice.objects.create(product=self.product, store=self.store_b, price=Decimal('150.00'))

    def test_lowest_price(self):
        self.assertEqual(self.product.lowest_price.price, Decimal('100.00'))

    def test_max_savings(self):
        self.assertEqual(self.product.max_savings, Decimal('50.00'))
```

---

## 5. Manual UI Test Checklist

- [ ] Home page loads with hero banner, popular categories, featured/
      trending/latest sections.
- [ ] Search box filters results (live client-side highlight + server-side submit).
- [ ] Category/brand filters and price-range filter narrow the product grid.
- [ ] Product card wishlist heart toggles instantly via AJAX (no page reload).
- [ ] Product detail: price table highlights the cheapest store, shows
      discount badges, renders the price-history line chart, shows
      recently viewed products after a second visit.
- [ ] Compare checkboxes: 2–4 selections show the sticky compare bar; a 5th is blocked.
- [ ] Contact form and feedback form submit successfully and show a confirmation message.
- [ ] Newsletter subscribe (footer) works via AJAX without leaving the page.
- [ ] Registration form validates duplicate username/email and password mismatch inline.
- [ ] Forgot-password flow: request → console "email" → reset link → new password → login.
- [ ] Dashboard (`/dashboard/`) renders all 4 charts without console errors.
- [ ] Dashboard dark/light theme toggle persists across page loads (localStorage).
- [ ] Non-staff users are redirected away from `/dashboard/` and all `/manage/` URLs.
- [ ] Manage Users: add, edit, activate/deactivate, delete all work and are reflected immediately.
- [ ] Manage Products: adding 2 images + 3 store prices in one form submit saves all rows correctly.
- [ ] All 4 report pages render correctly for a staff user.
- [ ] Responsive check at 375px (mobile), 768px (tablet), 1440px (desktop) —
      sidebar collapses to an off-canvas menu below the `lg` breakpoint.

---

## 6. Acceptance Criteria

The application is considered ready for evaluation/demo when:
1. All automated tests in `python manage.py test` pass.
2. The manual UI checklist in §5 is fully checked off.
3. `seed_data` populates a coherent demo dataset with no server errors.
4. The MySQL dump in `sql/` imports cleanly into a fresh phpMyAdmin
   database and the app runs against it without migration errors.
