# Problem Statement, Objectives & Modules

## 1. Problem Statement

Consumers shopping online for electronics, appliances, fashion, and other
goods routinely face **price fragmentation**: the same product is listed
at different prices across Amazon, Flipkart, Croma, Reliance Digital,
Vijay Sales, and countless other stores. Without a way to compare these
prices side by side:

- Shoppers waste time opening multiple tabs/apps to manually check prices.
- Shoppers frequently overpay because they never discover a cheaper listing.
- There is no historical context — a shopper cannot tell whether a "deal"
  is actually a good price or a temporary markup followed by a "discount."
- Store/product data is scattered with no single source of truth an
  administrator can manage, update, or report on.

There is a genuine need for a centralized platform that aggregates
multi-store pricing for the same product, presents it clearly, and gives
an administrator the tools to keep that data accurate and see how the
platform is being used.

## 2. Objectives

1. Build a Django-based web application that lets any visitor search for a
   product and see its price at every partner store in one place.
2. Automatically identify and highlight the lowest price and calculate the
   savings versus the highest listed price.
3. Allow registered users to maintain a wishlist, view their potential
   savings, and track recently viewed products.
4. Provide full-text search with category, brand, and price-range filters,
   and multiple sort options.
5. Give administrators a dedicated, non-default dashboard to manage
   categories, brands, stores, products (with images and multi-store
   pricing), and users — including activation/deactivation — without
   needing direct database or Django-admin access.
6. Maintain an audit trail of administrative actions.
7. Surface analytical reports (user, product, store, price) and
   interactive charts to support data-driven decisions.
8. Implement secure, role-based authentication (customer vs. staff) using
   Django's built-in framework, including a forgot-password flow.
9. Ensure the entire interface is responsive and usable on both desktop
   and mobile via Bootstrap 5.

## 3. Modules

### 3.1 User Module
- Registration, Login, Logout
- Forgot Password (email-based reset flow)
- Profile Management & Change Password
- Search Products (name, brand, category)
- Filter Products (category, brand, store, price range)
- Sort Products (price, newest, name)
- Compare Prices (side-by-side, up to 4 products)
- Wishlist (add/remove, target price)
- View Product Details (specs, images, price comparison, price history)
- Contact Admin / Submit Feedback
- Newsletter Subscription

### 3.2 Admin Module
- Custom Dashboard: platform statistics, charts, recent activity
- Manage Users: add, edit, delete, activate, deactivate
- Manage Categories: full CRUD
- Manage Brands: full CRUD
- Manage Stores: full CRUD
- Manage Products: full CRUD with image upload, description, specifications
- Manage Product Prices: add prices at multiple stores, edit, delete
- Reports: User Report, Product Report, Store Report, Price Report
- Feedback Management
- Contact Message Management
- Admin Activity Log

### 3.3 Core / Shared
- Price comparison engine (lowest/highest/average price, savings calc)
- Price history tracking and trend chart
- Search history logging
- Recently viewed products
- Featured / Trending / Latest product sections
- Popular categories section
