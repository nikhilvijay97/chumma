from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.core.paginator import Paginator
from django.db.models import Min, Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render

from brands.models import Brand
from categories.models import Category
from dashboard.utils import log_admin_action
from stores.models import Store
from wishlist.models import Wishlist

from .forms import ProductForm, ProductImageFormSet, ProductPriceFormSet, ProductSearchForm
from .models import PriceHistory, Product, ProductPrice, RecentlyViewed, SearchHistory


# ============================================================
# Public storefront views
# ============================================================

def home_view(request):
    featured = Product.objects.filter(is_active=True, is_featured=True).annotate(min_price=Min('prices__price'))[:8]
    trending = Product.objects.filter(is_active=True, is_trending=True).annotate(min_price=Min('prices__price'))[:8]
    latest = Product.objects.filter(is_active=True).annotate(min_price=Min('prices__price')).order_by('-created_at')[:8]
    popular_categories = Category.objects.filter(is_active=True).order_by('name')[:8]

    wishlist_ids = set()
    if request.user.is_authenticated:
        wishlist_ids = set(Wishlist.objects.filter(user=request.user).values_list('product_id', flat=True))

    context = {
        'featured': featured,
        'trending': trending,
        'latest': latest,
        'popular_categories': popular_categories,
        'wishlist_ids': wishlist_ids,
        'total_products': Product.objects.filter(is_active=True).count(),
        'total_stores': Store.objects.filter(is_active=True).count(),
    }
    return render(request, 'products/home.html', context)


def about_view(request):
    return render(request, 'products/about.html')


def product_list_view(request):
    form = ProductSearchForm(request.GET or None)
    products = Product.objects.filter(is_active=True).select_related('category', 'brand').prefetch_related('prices', 'images')

    query = category_slug = brand_slug = store_slug = ''
    if form.is_valid():
        query = form.cleaned_data.get('q') or ''
        category_slug = form.cleaned_data.get('category') or ''
        brand_slug = form.cleaned_data.get('brand') or ''
        store_slug = form.cleaned_data.get('store') or ''
        min_price = form.cleaned_data.get('min_price')
        max_price = form.cleaned_data.get('max_price')
        sort = form.cleaned_data.get('sort')

        if query:
            products = products.filter(
                Q(name__icontains=query) | Q(brand__name__icontains=query)
                | Q(category__name__icontains=query) | Q(description__icontains=query)
            )
            SearchHistory.objects.create(
                user=request.user if request.user.is_authenticated else None,
                query=query,
                results_count=products.distinct().count(),
            )
        if category_slug:
            products = products.filter(category__slug=category_slug)
        if brand_slug:
            products = products.filter(brand__slug=brand_slug)
        if store_slug:
            products = products.filter(prices__store__slug=store_slug)

        products = products.annotate(min_price=Min('prices__price'))

        if min_price is not None:
            products = products.filter(min_price__gte=min_price)
        if max_price is not None:
            products = products.filter(min_price__lte=max_price)

        if sort == 'price_low':
            products = products.order_by('min_price')
        elif sort == 'price_high':
            products = products.order_by('-min_price')
        elif sort == 'newest':
            products = products.order_by('-created_at')
        elif sort == 'name':
            products = products.order_by('name')
    else:
        products = products.annotate(min_price=Min('prices__price'))

    products = products.distinct()
    paginator = Paginator(products, 12)
    page_obj = paginator.get_page(request.GET.get('page'))

    wishlist_ids = set()
    if request.user.is_authenticated:
        wishlist_ids = set(Wishlist.objects.filter(user=request.user).values_list('product_id', flat=True))

    context = {
        'page_obj': page_obj,
        'products': page_obj.object_list,
        'form': form,
        'categories': Category.objects.filter(is_active=True),
        'brands': Brand.objects.filter(is_active=True),
        'stores': Store.objects.filter(is_active=True),
        'query': query,
        'selected_category': category_slug,
        'selected_brand': brand_slug,
        'wishlist_ids': wishlist_ids,
        'total_results': paginator.count,
    }
    return render(request, 'products/product_list.html', context)


def category_detail_view(request, slug):
    category = get_object_or_404(Category, slug=slug)
    products = Product.objects.filter(category=category, is_active=True).annotate(min_price=Min('prices__price'))
    paginator = Paginator(products, 12)
    page_obj = paginator.get_page(request.GET.get('page'))
    wishlist_ids = set()
    if request.user.is_authenticated:
        wishlist_ids = set(Wishlist.objects.filter(user=request.user).values_list('product_id', flat=True))
    return render(request, 'products/category_detail.html', {
        'category': category, 'page_obj': page_obj, 'products': page_obj.object_list, 'wishlist_ids': wishlist_ids,
    })


def brand_detail_view(request, slug):
    brand = get_object_or_404(Brand, slug=slug)
    products = Product.objects.filter(brand=brand, is_active=True).annotate(min_price=Min('prices__price'))
    paginator = Paginator(products, 12)
    page_obj = paginator.get_page(request.GET.get('page'))
    wishlist_ids = set()
    if request.user.is_authenticated:
        wishlist_ids = set(Wishlist.objects.filter(user=request.user).values_list('product_id', flat=True))
    return render(request, 'products/brand_detail.html', {
        'brand': brand, 'page_obj': page_obj, 'products': page_obj.object_list, 'wishlist_ids': wishlist_ids,
    })


def product_detail_view(request, slug):
    product = get_object_or_404(
        Product.objects.select_related('category', 'brand').prefetch_related('prices__store', 'images'),
        slug=slug, is_active=True,
    )
    prices = product.prices.select_related('store').order_by('price')
    cheapest = prices.filter(in_stock=True).first()

    related_products = Product.objects.filter(
        category=product.category, is_active=True
    ).exclude(pk=product.pk).annotate(min_price=Min('prices__price'))[:4]

    is_wishlisted = False
    recently_viewed = []
    if request.user.is_authenticated:
        is_wishlisted = Wishlist.objects.filter(user=request.user, product=product).exists()
        RecentlyViewed.objects.update_or_create(user=request.user, product=product)
        # trim to the most recent N
        stale_ids = list(
            RecentlyViewed.objects.filter(user=request.user).order_by('-viewed_at')
            .values_list('id', flat=True)[10:]
        )
        if stale_ids:
            RecentlyViewed.objects.filter(id__in=stale_ids).delete()
        recently_viewed = RecentlyViewed.objects.filter(user=request.user).exclude(product=product).select_related('product')[:4]

    context = {
        'product': product,
        'prices': prices,
        'cheapest': cheapest,
        'related_products': related_products,
        'is_wishlisted': is_wishlisted,
        'recently_viewed': recently_viewed,
    }
    return render(request, 'products/product_detail.html', context)


def compare_view(request):
    ids_param = request.GET.get('ids', '')
    ids = [int(i) for i in ids_param.split(',') if i.strip().isdigit()][:4]
    products = Product.objects.filter(id__in=ids).prefetch_related('prices__store') if ids else []
    return render(request, 'products/compare.html', {'products': products})


def price_history_json(request, product_id, store_id):
    """JSON endpoint consumed by Chart.js on the product detail page to
    plot the historical price trend for one store."""
    history = PriceHistory.objects.filter(
        product_price__product_id=product_id, product_price__store_id=store_id
    ).order_by('recorded_at')
    return JsonResponse({
        'labels': [h.recorded_at.strftime('%d %b %Y') for h in history],
        'prices': [float(h.price) for h in history],
    })


# ============================================================
# Staff CRUD — Product management
# ============================================================

@staff_member_required
def admin_product_list(request):
    products = Product.objects.select_related('category', 'brand').all().order_by('-created_at')
    q = request.GET.get('q', '')
    if q:
        products = products.filter(Q(name__icontains=q) | Q(brand__name__icontains=q))
    paginator = Paginator(products, 10)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'products/admin_product_list.html', {
        'page_obj': page_obj, 'products': page_obj.object_list, 'q': q,
    })


@staff_member_required
def admin_product_create(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save()
            image_formset = ProductImageFormSet(request.POST, request.FILES, instance=product)
            price_formset = ProductPriceFormSet(request.POST, instance=product)
            if image_formset.is_valid() and price_formset.is_valid():
                image_formset.save()
                price_formset.save()
                log_admin_action(request.user, 'CREATE', 'Product', str(product))
                messages.success(request, f'Product "{product.name}" created successfully.')
                return redirect('products:admin_product_list')
        else:
            image_formset = ProductImageFormSet(request.POST, request.FILES)
            price_formset = ProductPriceFormSet(request.POST)
    else:
        form = ProductForm()
        image_formset = ProductImageFormSet()
        price_formset = ProductPriceFormSet()

    return render(request, 'products/admin_product_form.html', {
        'form': form, 'image_formset': image_formset, 'price_formset': price_formset, 'title': 'Add Product',
    })


@staff_member_required
def admin_product_update(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        image_formset = ProductImageFormSet(request.POST, request.FILES, instance=product)
        price_formset = ProductPriceFormSet(request.POST, instance=product)
        if form.is_valid() and image_formset.is_valid() and price_formset.is_valid():
            form.save()
            image_formset.save()
            price_formset.save()
            log_admin_action(request.user, 'UPDATE', 'Product', str(product))
            messages.success(request, f'Product "{product.name}" updated successfully.')
            return redirect('products:admin_product_list')
    else:
        form = ProductForm(instance=product)
        image_formset = ProductImageFormSet(instance=product)
        price_formset = ProductPriceFormSet(instance=product)

    return render(request, 'products/admin_product_form.html', {
        'form': form, 'image_formset': image_formset, 'price_formset': price_formset,
        'title': 'Edit Product', 'product': product,
    })


@staff_member_required
def admin_product_delete(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        name = str(product)
        product.delete()
        log_admin_action(request.user, 'DELETE', 'Product', name)
        messages.success(request, f'Product "{name}" deleted.')
        return redirect('products:admin_product_list')
    return render(request, 'products/admin_product_confirm_delete.html', {'product': product})
