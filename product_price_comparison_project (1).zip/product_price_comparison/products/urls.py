from django.urls import path

from . import views

app_name = 'products'

urlpatterns = [
    path('', views.home_view, name='home'),
    path('about/', views.about_view, name='about'),
    path('products/', views.product_list_view, name='product_list'),
    path('compare/', views.compare_view, name='compare'),
    path('category/<slug:slug>/', views.category_detail_view, name='category_detail'),
    path('brand/<slug:slug>/', views.brand_detail_view, name='brand_detail'),
    path('product/<slug:slug>/', views.product_detail_view, name='product_detail'),
    path('api/price-history/<int:product_id>/<int:store_id>/', views.price_history_json, name='price_history_json'),

    # Staff CRUD
    path('manage/products/', views.admin_product_list, name='admin_product_list'),
    path('manage/products/add/', views.admin_product_create, name='admin_product_create'),
    path('manage/products/<int:pk>/edit/', views.admin_product_update, name='admin_product_update'),
    path('manage/products/<int:pk>/delete/', views.admin_product_delete, name='admin_product_delete'),
]
