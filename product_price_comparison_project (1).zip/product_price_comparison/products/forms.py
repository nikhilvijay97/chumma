from django import forms
from django.forms import inlineformset_factory

from .models import Product, ProductImage, ProductPrice


def _bootstrapify(fields):
    for name, field in fields.items():
        if isinstance(field.widget, forms.CheckboxInput):
            field.widget.attrs['class'] = 'form-check-input'
        elif isinstance(field.widget, forms.Select):
            field.widget.attrs['class'] = 'form-select'
        else:
            field.widget.attrs['class'] = 'form-control'


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'category', 'brand', 'description', 'specifications',
                  'is_featured', 'is_trending', 'is_active']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'specifications': forms.Textarea(attrs={'rows': 5, 'placeholder': 'RAM: 8GB\nStorage: 128GB\nColor: Black'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bootstrapify(self.fields)


class ProductImageForm(forms.ModelForm):
    class Meta:
        model = ProductImage
        fields = ['image', 'alt_text', 'is_primary']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bootstrapify(self.fields)


class ProductPriceForm(forms.ModelForm):
    class Meta:
        model = ProductPrice
        fields = ['store', 'price', 'old_price', 'product_url', 'in_stock']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bootstrapify(self.fields)


ProductImageFormSet = inlineformset_factory(
    Product, ProductImage, form=ProductImageForm, extra=3, can_delete=True,
)

ProductPriceFormSet = inlineformset_factory(
    Product, ProductPrice, form=ProductPriceForm, extra=4, can_delete=True,
)


class ProductSearchForm(forms.Form):
    q = forms.CharField(required=False, max_length=200, widget=forms.TextInput(
        attrs={'class': 'form-control', 'placeholder': 'Search products, brands...'}
    ))
    category = forms.CharField(required=False)
    brand = forms.CharField(required=False)
    store = forms.CharField(required=False)
    min_price = forms.DecimalField(required=False, min_value=0)
    max_price = forms.DecimalField(required=False, min_value=0)
    sort = forms.ChoiceField(
        required=False,
        choices=[
            ('', 'Relevance'),
            ('price_low', 'Price: Low to High'),
            ('price_high', 'Price: High to Low'),
            ('newest', 'Newest First'),
            ('name', 'Name (A-Z)'),
        ],
    )
