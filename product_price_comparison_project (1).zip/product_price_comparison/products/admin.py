from django.contrib import admin
from django.utils.html import format_html

from .models import PriceHistory, Product, ProductImage, ProductPrice, RecentlyViewed, SearchHistory


class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1


class ProductPriceInline(admin.TabularInline):
    model = ProductPrice
    extra = 1
    fields = ('store', 'price', 'old_price', 'in_stock', 'product_url')


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'brand', 'lowest_price_display', 'is_featured', 'is_trending', 'is_active', 'thumb')
    list_filter = ('category', 'brand', 'is_active', 'is_featured', 'is_trending')
    search_fields = ('name', 'description')
    prepopulated_fields = {'slug': ('name',)}
    inlines = [ProductImageInline, ProductPriceInline]
    list_per_page = 25

    def lowest_price_display(self, obj):
        cheapest = obj.lowest_price
        return f'Rs.{cheapest.price} ({cheapest.store.name})' if cheapest else '—'
    lowest_price_display.short_description = 'Best Price'

    def thumb(self, obj):
        img = obj.primary_image
        if img:
            return format_html('<img src="{}" style="height:40px;border-radius:4px;" />', img.image.url)
        return '—'
    thumb.short_description = 'Image'


@admin.register(ProductPrice)
class ProductPriceAdmin(admin.ModelAdmin):
    list_display = ('product', 'store', 'price', 'old_price', 'in_stock', 'updated_at')
    list_filter = ('store', 'in_stock')
    search_fields = ('product__name', 'store__name')
    autocomplete_fields = ['product', 'store']

    def save_model(self, request, obj, form, change):
        price_changed = True
        if change:
            old = ProductPrice.objects.get(pk=obj.pk)
            price_changed = old.price != obj.price
        super().save_model(request, obj, form, change)
        if price_changed:
            PriceHistory.objects.create(product_price=obj, price=obj.price)


@admin.register(PriceHistory)
class PriceHistoryAdmin(admin.ModelAdmin):
    list_display = ('product_price', 'price', 'recorded_at')
    list_filter = ('recorded_at',)
    date_hierarchy = 'recorded_at'


@admin.register(SearchHistory)
class SearchHistoryAdmin(admin.ModelAdmin):
    list_display = ('query', 'user', 'results_count', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('query',)


@admin.register(RecentlyViewed)
class RecentlyViewedAdmin(admin.ModelAdmin):
    list_display = ('user', 'product', 'viewed_at')
