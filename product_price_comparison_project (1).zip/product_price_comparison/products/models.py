from decimal import Decimal

from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils.text import slugify

from brands.models import Brand
from categories.models import Category
from stores.models import Store


class Product(models.Model):
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='products')
    brand = models.ForeignKey(Brand, on_delete=models.SET_NULL, related_name='products', null=True, blank=True)
    description = models.TextField(blank=True)
    specifications = models.TextField(
        blank=True,
        help_text='One specification per line, formatted as "Attribute: Value" (e.g. "RAM: 8GB").',
    )
    is_featured = models.BooleanField(default=False)
    is_trending = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'products'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['name']),
            models.Index(fields=['category']),
            models.Index(fields=['brand']),
        ]

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.name)
            slug = base_slug
            counter = 1
            while Product.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f'{base_slug}-{counter}'
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('products:product_detail', args=[self.slug])

    @property
    def specifications_list(self):
        """Parses the `specifications` textarea into a list of (key, value) tuples."""
        pairs = []
        for line in (self.specifications or '').splitlines():
            line = line.strip()
            if not line:
                continue
            if ':' in line:
                key, _, value = line.partition(':')
                pairs.append((key.strip(), value.strip()))
            else:
                pairs.append((line, ''))
        return pairs

    @property
    def primary_image(self):
        return self.images.filter(is_primary=True).first() or self.images.first()

    @property
    def lowest_price(self):
        return self.prices.filter(in_stock=True).order_by('price').first()

    @property
    def highest_price(self):
        return self.prices.filter(in_stock=True).order_by('-price').first()

    @property
    def average_price(self):
        prices = self.prices.filter(in_stock=True)
        if not prices.exists():
            return None
        total = sum((p.price for p in prices), Decimal('0'))
        return round(total / prices.count(), 2)

    @property
    def max_savings(self):
        low = self.lowest_price
        high = self.highest_price
        if low and high and high.price > low.price:
            return round(high.price - low.price, 2)
        return Decimal('0.00')


class ProductImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='products/')
    alt_text = models.CharField(max_length=150, blank=True)
    is_primary = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'product_images'
        ordering = ['-is_primary', 'id']

    def __str__(self):
        return f'Image for {self.product.name}'


class ProductPrice(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='prices')
    store = models.ForeignKey(Store, on_delete=models.CASCADE, related_name='product_prices')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    old_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True,
                                     help_text='Original price before discount (optional)')
    product_url = models.URLField(blank=True, help_text="Direct link to buy at this store")
    in_stock = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'product_prices'
        unique_together = ('product', 'store')
        ordering = ['price']
        verbose_name = 'Product Price'
        verbose_name_plural = 'Product Prices'

    def __str__(self):
        return f'{self.product.name} @ {self.store.name}: Rs.{self.price}'

    @property
    def discount_percent(self):
        if self.old_price and self.old_price > self.price:
            return round((self.old_price - self.price) / self.old_price * 100, 0)
        return 0


class PriceHistory(models.Model):
    """Snapshot of a ProductPrice, recorded whenever the price changes —
    powers the "Price History" trend chart on the product detail page."""
    product_price = models.ForeignKey(ProductPrice, on_delete=models.CASCADE, related_name='history')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    recorded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'price_history'
        ordering = ['recorded_at']
        verbose_name_plural = 'Price histories'

    def __str__(self):
        return f'{self.product_price} @ {self.recorded_at:%Y-%m-%d}: Rs.{self.price}'


class SearchHistory(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                              related_name='search_history', null=True, blank=True)
    query = models.CharField(max_length=255)
    results_count = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'search_history'
        ordering = ['-created_at']
        verbose_name_plural = 'Search histories'

    def __str__(self):
        return f'"{self.query}" ({self.created_at:%Y-%m-%d})'


class RecentlyViewed(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='recently_viewed')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='viewed_by')
    viewed_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'recently_viewed'
        unique_together = ('user', 'product')
        ordering = ['-viewed_at']

    def __str__(self):
        return f'{self.user.username} viewed {self.product.name}'
