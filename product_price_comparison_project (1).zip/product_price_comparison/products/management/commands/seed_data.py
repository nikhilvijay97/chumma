"""
Seeds the database with realistic sample data: categories, brands,
stores, products, images, prices, price history, users, wishlist
entries, contact messages, feedback and newsletter subscribers.

Usage:
    python manage.py seed_data
    python manage.py seed_data --flush
"""
import random
from datetime import timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.utils import timezone

from accounts.models import User
from brands.models import Brand
from categories.models import Category
from contact.models import ContactMessage, Feedback, NewsletterSubscriber
from products.models import PriceHistory, Product, ProductPrice, SearchHistory
from stores.models import Store
from wishlist.models import Wishlist


class Command(BaseCommand):
    help = 'Seed the database with sample categories, brands, stores, products, prices and users.'

    def add_arguments(self, parser):
        parser.add_argument('--flush', action='store_true', help='Delete existing sample data before seeding.')

    def handle(self, *args, **options):
        if options['flush']:
            self.stdout.write('Flushing existing data...')
            Wishlist.objects.all().delete()
            PriceHistory.objects.all().delete()
            ProductPrice.objects.all().delete()
            Product.objects.all().delete()
            Store.objects.all().delete()
            Brand.objects.all().delete()
            Category.objects.all().delete()
            ContactMessage.objects.all().delete()
            Feedback.objects.all().delete()
            NewsletterSubscriber.objects.all().delete()
            SearchHistory.objects.all().delete()

        # ------------------------------------------------------------
        # Categories
        # ------------------------------------------------------------
        self.stdout.write('Creating categories...')
        categories_data = [
            ('Mobiles & Accessories', 'bi-phone'),
            ('Laptops & Computers', 'bi-laptop'),
            ('Televisions', 'bi-tv'),
            ('Audio & Headphones', 'bi-headphones'),
            ('Home Appliances', 'bi-house-gear'),
            ('Fashion & Footwear', 'bi-bag'),
            ('Fitness & Wearables', 'bi-smartwatch'),
            ('Cameras', 'bi-camera'),
        ]
        categories = {}
        for name, icon in categories_data:
            cat, _ = Category.objects.get_or_create(
                name=name, defaults={'icon': icon, 'description': f'Compare prices on the best {name.lower()}.'}
            )
            categories[name] = cat

        # ------------------------------------------------------------
        # Brands
        # ------------------------------------------------------------
        self.stdout.write('Creating brands...')
        brand_names = ['Nova', 'Skyline', 'Zenith', 'Vantage', 'Orbit', 'Pulse']
        brands = {}
        for name in brand_names:
            brand, _ = Brand.objects.get_or_create(name=name, defaults={'description': f'{name} — trusted electronics and lifestyle brand.'})
            brands[name] = brand

        # ------------------------------------------------------------
        # Stores
        # ------------------------------------------------------------
        self.stdout.write('Creating stores...')
        stores_data = [
            ('Amazon.in', 'https://www.amazon.in'),
            ('Flipkart', 'https://www.flipkart.com'),
            ('Croma', 'https://www.croma.com'),
            ('Reliance Digital', 'https://www.reliancedigital.in'),
            ('Vijay Sales', 'https://www.vijaysales.com'),
        ]
        stores = {}
        for name, url in stores_data:
            store, _ = Store.objects.get_or_create(name=name, defaults={'website_url': url})
            stores[name] = store

        # ------------------------------------------------------------
        # Users
        # ------------------------------------------------------------
        self.stdout.write('Creating sample users...')
        users_data = [
            ('john_doe', 'john@example.com', 'John', 'Doe'),
            ('priya_sharma', 'priya@example.com', 'Priya', 'Sharma'),
            ('amit_kumar', 'amit@example.com', 'Amit', 'Kumar'),
        ]
        sample_users = []
        for username, email, first, last in users_data:
            user, created = User.objects.get_or_create(username=username, defaults={'email': email, 'first_name': first, 'last_name': last})
            if created:
                user.set_password('Password@123')
                user.save()
            sample_users.append(user)

        if not User.objects.filter(is_superuser=True).exists():
            self.stdout.write('Creating default admin superuser (admin / Admin@12345)...')
            admin = User.objects.create_superuser(username='admin', email='admin@pricecomparison.local', password='Admin@12345')
            admin.first_name = 'Site'
            admin.last_name = 'Administrator'
            admin.save()

        # ------------------------------------------------------------
        # Products, Prices & Price History
        # ------------------------------------------------------------
        self.stdout.write('Creating products, prices & price history...')
        products_catalog = [
            ('Mobiles & Accessories', 'Galaxy Phantom X5 (128GB)', 'Nova', Decimal('24999'), 'RAM: 8GB\nStorage: 128GB\nDisplay: 6.5" AMOLED\nBattery: 5000mAh'),
            ('Mobiles & Accessories', 'Pixel Aurora 9 Pro', 'Skyline', Decimal('54999'), 'RAM: 12GB\nStorage: 256GB\nDisplay: 6.7" OLED\nCamera: 50MP Triple'),
            ('Mobiles & Accessories', 'iSpark 15 (256GB)', 'Zenith', Decimal('69999'), 'Storage: 256GB\nDisplay: 6.1" Super Retina\nChip: A17 Bionic'),
            ('Mobiles & Accessories', 'Wireless Earbuds Pro 2', 'Nova', Decimal('2499'), 'Battery: 30hrs total\nANC: Yes\nBluetooth: 5.3'),
            ('Laptops & Computers', 'UltraBook Air 14"', 'Zenith', Decimal('64999'), 'RAM: 16GB\nStorage: 512GB SSD\nProcessor: M2 chip'),
            ('Laptops & Computers', 'GameForce Pro 16" RTX', 'Skyline', Decimal('124999'), 'RAM: 32GB\nGPU: RTX 4070\nDisplay: 165Hz QHD'),
            ('Laptops & Computers', 'Chromatic Notebook 11', 'Nova', Decimal('21999'), 'RAM: 8GB\nStorage: 128GB eMMC\nOS: ChromeOS'),
            ('Televisions', 'Crystal 55" 4K Smart TV', 'Vantage', Decimal('42999'), 'Resolution: 4K UHD\nHDR: Dolby Vision\nSmart OS: Android TV'),
            ('Televisions', 'OLED Infinity 65"', 'Zenith', Decimal('129999'), 'Resolution: 4K OLED\nRefresh: 120Hz\nHDMI: 4 ports'),
            ('Audio & Headphones', 'Bass Boost Over-Ear Headphones', 'Nova', Decimal('3999'), 'Driver: 40mm\nBattery: 40hrs\nANC: Yes'),
            ('Audio & Headphones', 'Studio Monitor Speakers (Pair)', 'Skyline', Decimal('8999'), 'Power: 100W RMS\nConnectivity: Bluetooth + AUX'),
            ('Home Appliances', 'Frost-Free Refrigerator 340L', 'Vantage', Decimal('28999'), 'Capacity: 340L\nStar Rating: 3 Star\nType: Double Door'),
            ('Home Appliances', 'Front Load Washing Machine 7kg', 'Zenith', Decimal('26999'), 'Capacity: 7kg\nRPM: 1200\nType: Front Load'),
            ('Home Appliances', 'Smart Air Purifier', 'Nova', Decimal('9999'), 'Coverage: 500 sq ft\nFilter: HEPA H13\nApp Control: Yes'),
            ('Fashion & Footwear', 'Running Shoes Aero Trail', 'Skyline', Decimal('2999'), 'Material: Mesh\nSole: EVA Foam\nType: Running'),
            ('Fashion & Footwear', 'Leather Messenger Bag', 'Vantage', Decimal('1899'), 'Material: Genuine Leather\nCapacity: 15" Laptop'),
            ('Fitness & Wearables', 'FitTrack Smartwatch Series 4', 'Nova', Decimal('7999'), 'Display: AMOLED\nBattery: 7 days\nGPS: Yes'),
            ('Fitness & Wearables', 'Pulse Fitness Band', 'Skyline', Decimal('1999'), 'Battery: 14 days\nWater Resistance: 5ATM'),
            ('Cameras', 'MirrorPro X100 Mirrorless Camera', 'Zenith', Decimal('84999'), 'Sensor: 24MP APS-C\nVideo: 4K 60fps'),
            ('Cameras', 'ActionCam 4K Waterproof', 'Vantage', Decimal('12999'), 'Video: 4K 30fps\nWaterproof: 10m\nStabilization: Yes'),
        ]

        store_names = list(stores.keys())
        products_created = []
        for cat_name, name, brand_name, base_price, specs in products_catalog:
            product, _ = Product.objects.get_or_create(
                name=name,
                defaults={
                    'category': categories[cat_name],
                    'brand': brands[brand_name],
                    'description': f'The {name} by {brand_name} offers excellent value and performance. Compare live prices below across all partner stores before you buy.',
                    'specifications': specs,
                    'is_featured': random.random() < 0.35,
                    'is_trending': random.random() < 0.3,
                },
            )
            products_created.append(product)

            num_stores = random.randint(3, 5)
            chosen_stores = random.sample(store_names, num_stores)
            for store_name in chosen_stores:
                variance = Decimal(random.uniform(-0.08, 0.08)).quantize(Decimal('0.01'))
                price = (base_price * (Decimal('1') + variance)).quantize(Decimal('0.01'))
                has_discount = random.random() < 0.5
                old_price = (price * Decimal('1.15')).quantize(Decimal('0.01')) if has_discount else None
                pp, created = ProductPrice.objects.get_or_create(
                    product=product,
                    store=stores[store_name],
                    defaults={
                        'price': price,
                        'old_price': old_price,
                        'in_stock': random.random() > 0.1,
                        'product_url': f'https://example.com/{store_name.lower().replace(" ", "-").replace(".", "")}/{product.slug}',
                    },
                )
                if created:
                    for days_ago in [30, 20, 10, 3]:
                        hist_variance = Decimal(random.uniform(-0.05, 0.05)).quantize(Decimal('0.01'))
                        hist_price = (price * (Decimal('1') + hist_variance)).quantize(Decimal('0.01'))
                        PriceHistory.objects.create(
                            product_price=pp, price=hist_price,
                            recorded_at=timezone.now() - timedelta(days=days_ago),
                        )
                    PriceHistory.objects.create(product_price=pp, price=price)

        # ------------------------------------------------------------
        # Wishlist
        # ------------------------------------------------------------
        self.stdout.write('Creating sample wishlist entries...')
        for user in sample_users:
            for product in random.sample(products_created, k=random.randint(2, 5)):
                Wishlist.objects.get_or_create(user=user, product=product)

        # ------------------------------------------------------------
        # Contact messages, feedback, newsletter
        # ------------------------------------------------------------
        self.stdout.write('Creating sample contact messages & feedback...')
        ContactMessage.objects.get_or_create(
            name='Ravi Verma', email='ravi@example.com', subject='Wrong price listed',
            defaults={'message': 'The price for the Galaxy Phantom X5 on Croma looks outdated. Please update it.'},
        )
        ContactMessage.objects.get_or_create(
            name='Sneha Iyer', email='sneha@example.com', subject='Add a new store',
            defaults={'message': 'Could you please add Tata Cliq as a partner store for comparison?'},
        )
        Feedback.objects.get_or_create(
            name='John Doe', email='john@example.com', rating=5,
            defaults={'message': 'Great platform! Saved me a lot of money on my laptop purchase.'},
        )
        Feedback.objects.get_or_create(
            name='Priya Sharma', email='priya@example.com', rating=4,
            defaults={'message': 'Very useful, would love to see more stores added.'},
        )
        for email in ['newsletter1@example.com', 'newsletter2@example.com', 'newsletter3@example.com']:
            NewsletterSubscriber.objects.get_or_create(email=email)

        self.stdout.write(self.style.SUCCESS(
            f'Done. Seeded {Category.objects.count()} categories, {Brand.objects.count()} brands, '
            f'{Store.objects.count()} stores, {Product.objects.count()} products, '
            f'{ProductPrice.objects.count()} price listings, {User.objects.count()} users.'
        ))
