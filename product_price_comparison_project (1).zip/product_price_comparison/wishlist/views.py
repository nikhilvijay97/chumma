from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from products.models import Product

from .models import Wishlist


@login_required
def wishlist_view(request):
    items = Wishlist.objects.filter(user=request.user).select_related(
        'product', 'product__category'
    ).prefetch_related('product__prices__store', 'product__images')
    return render(request, 'wishlist/wishlist.html', {'items': items})


@login_required
@require_POST
def toggle_wishlist(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    item, created = Wishlist.objects.get_or_create(user=request.user, product=product)
    if not created:
        item.delete()
        added = False
        messages.info(request, f'Removed "{product.name}" from your wishlist.')
    else:
        added = True
        messages.success(request, f'Added "{product.name}" to your wishlist.')

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'added': added, 'wishlist_count': Wishlist.objects.filter(user=request.user).count()})
    return redirect(request.META.get('HTTP_REFERER', 'products:home'))


@login_required
def remove_from_wishlist(request, item_id):
    item = get_object_or_404(Wishlist, id=item_id, user=request.user)
    item.delete()
    messages.info(request, 'Item removed from wishlist.')
    return redirect('wishlist:wishlist')
