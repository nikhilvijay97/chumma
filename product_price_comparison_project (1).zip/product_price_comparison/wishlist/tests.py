from django.test import TestCase
from django.urls import reverse

from accounts.models import User
from categories.models import Category
from products.models import Product

from .models import Wishlist


class WishlistToggleTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='tester', password='pass12345')
        self.category = Category.objects.create(name='Gadgets')
        self.product = Product.objects.create(name='Gadget One', category=self.category)

    def test_requires_login(self):
        response = self.client.post(reverse('wishlist:toggle', args=[self.product.id]))
        self.assertEqual(response.status_code, 302)

    def test_toggle_add_and_remove(self):
        self.client.login(username='tester', password='pass12345')
        url = reverse('wishlist:toggle', args=[self.product.id])
        response = self.client.post(url, HTTP_X_REQUESTED_WITH='XMLHttpRequest')
        self.assertTrue(response.json()['added'])
        self.assertEqual(Wishlist.objects.filter(user=self.user).count(), 1)
        response = self.client.post(url, HTTP_X_REQUESTED_WITH='XMLHttpRequest')
        self.assertFalse(response.json()['added'])
        self.assertEqual(Wishlist.objects.filter(user=self.user).count(), 0)

    def test_wishlist_page_requires_login(self):
        response = self.client.get(reverse('wishlist:wishlist'))
        self.assertEqual(response.status_code, 302)
