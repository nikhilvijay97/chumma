from django.test import TestCase
from django.urls import reverse

from accounts.models import User


class DashboardAccessTests(TestCase):
    def setUp(self):
        self.staff = User.objects.create_user(username='staffer', password='pass12345', is_staff=True)
        self.normal = User.objects.create_user(username='normal', password='pass12345')

    def test_dashboard_requires_staff(self):
        response = self.client.get(reverse('dashboard:home'))
        self.assertNotEqual(response.status_code, 200)

    def test_dashboard_accessible_to_staff(self):
        self.client.login(username='staffer', password='pass12345')
        response = self.client.get(reverse('dashboard:home'))
        self.assertEqual(response.status_code, 200)


class ManageUsersTests(TestCase):
    def setUp(self):
        self.staff = User.objects.create_user(username='staffer', password='pass12345', is_staff=True)
        self.target = User.objects.create_user(username='target_user', password='pass12345')
        self.client.login(username='staffer', password='pass12345')

    def test_toggle_active(self):
        self.assertTrue(self.target.is_active)
        response = self.client.post(reverse('dashboard:user_toggle_active', args=[self.target.pk]))
        self.assertEqual(response.status_code, 302)
        self.target.refresh_from_db()
        self.assertFalse(self.target.is_active)

    def test_manage_users_list(self):
        response = self.client.get(reverse('dashboard:manage_users'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'target_user')
