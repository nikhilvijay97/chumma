from django.contrib import admin

from .models import AdminLog


@admin.register(AdminLog)
class AdminLogAdmin(admin.ModelAdmin):
    list_display = ('timestamp', 'user', 'action', 'model_name', 'object_repr')
    list_filter = ('action', 'model_name')
    search_fields = ('object_repr', 'user__username')
    date_hierarchy = 'timestamp'
    readonly_fields = [f.name for f in AdminLog._meta.fields]

    def has_add_permission(self, request):
        return False
