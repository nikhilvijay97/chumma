"""Lightweight middleware that timestamps the last dashboard visit for
staff members, giving the "Recent Activity" panel something real to
show without needing a signal on every single view."""
from django.utils import timezone


class AdminAccessLogMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        user = getattr(request, 'user', None)
        if user is not None and getattr(user, 'is_authenticated', False) and user.is_staff:
            if request.path.startswith('/dashboard/'):
                # Cheap in-memory marker; avoided a DB write on every request
                # to keep the admin dashboard fast. Explicit CRUD actions are
                # logged individually via dashboard.utils.log_admin_action.
                request.session['last_dashboard_visit'] = timezone.now().isoformat()
        return response
