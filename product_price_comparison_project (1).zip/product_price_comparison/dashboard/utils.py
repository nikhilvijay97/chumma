"""Small helper used by every app's admin CRUD views to record an entry
in the admin_logs table without importing models at module load time
(avoids circular imports since many apps depend on dashboard.utils)."""


def log_admin_action(user, action, model_name, object_repr):
    from .models import AdminLog
    try:
        AdminLog.objects.create(
            user=user if getattr(user, 'is_authenticated', False) else None,
            action=action,
            model_name=model_name,
            object_repr=object_repr[:255],
        )
    except Exception:
        # Logging must never break the calling admin action.
        pass
