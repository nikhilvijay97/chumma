"""Signal handlers used to automatically populate the admin_logs table
for security-relevant events (e.g. every successful login)."""
from django.contrib.auth.signals import user_logged_in
from django.dispatch import receiver

from .utils import log_admin_action


@receiver(user_logged_in)
def log_user_login(sender, request, user, **kwargs):
    log_admin_action(user, 'LOGIN', 'User', user.username)
