from django.urls import path

from . import views

app_name = 'dashboard'

urlpatterns = [
    path('', views.dashboard_home, name='home'),
    path('logs/', views.admin_logs_view, name='admin_logs'),

    path('users/', views.manage_users, name='manage_users'),
    path('users/add/', views.user_create, name='user_create'),
    path('users/<int:pk>/edit/', views.user_update, name='user_update'),
    path('users/<int:pk>/delete/', views.user_delete, name='user_delete'),
    path('users/<int:pk>/toggle-active/', views.user_toggle_active, name='user_toggle_active'),

    path('api/chart/category-avg-price/', views.chart_category_avg_price, name='chart_category_avg_price'),
    path('api/chart/store-listing-count/', views.chart_store_listing_count, name='chart_store_listing_count'),
    path('api/chart/category-distribution/', views.chart_category_distribution, name='chart_category_distribution'),
    path('api/chart/user-signups/', views.chart_user_signups, name='chart_user_signups'),
]
