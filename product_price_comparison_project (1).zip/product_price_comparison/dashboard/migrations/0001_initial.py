import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='AdminLog',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('action', models.CharField(choices=[('CREATE', 'Create'), ('UPDATE', 'Update'), ('DELETE', 'Delete'), ('ACTIVATE', 'Activate'), ('DEACTIVATE', 'Deactivate'), ('LOGIN', 'Login'), ('OTHER', 'Other')], default='OTHER', max_length=20)),
                ('model_name', models.CharField(max_length=100)),
                ('object_repr', models.CharField(max_length=255)),
                ('timestamp', models.DateTimeField(auto_now_add=True)),
                ('user', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='admin_logs', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'Admin Log',
                'verbose_name_plural': 'Admin Logs',
                'db_table': 'admin_logs',
                'ordering': ['-timestamp'],
            },
        ),
    ]
