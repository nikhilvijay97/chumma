from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.core.paginator import Paginator
from django.db.models import Avg, Count, Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render

from accounts.forms import AdminUserForm
from accounts.models import User
from brands.models import Brand
from categories.models import Category
from contact.models import ContactMessage, Feedback
from products.models import Product, ProductPrice
from stores.models import Store
from wishlist.models import Wishlist

from .models import AdminLog
from .utils import log_admin_action


@staff_member_required
def dashboard_home(request):
    context = {
        'total_users': User.objects.count(),
        'total_products': Product.objects.filter(is_active=True).count(),
        'total_categories': Category.objects.count(),
        'total_brands': Brand.objects.count(),
        'total_stores': Store.objects.filter(is_active=True).count(),
        'total_price_records': ProductPrice.objects.count(),
        'total_wishlist_items': Wishlist.objects.count(),
        'unread_messages': ContactMessage.objects.filter(is_read=False).count(),
        'recent_users': User.objects.order_by('-date_joined')[:5],
        'recent_products': Product.objects.order_by('-created_at')[:5],
        'recent_logs': AdminLog.objects.select_related('user')[:8],
    }
    return render(request, 'dashboard/index.html', context)


@staff_member_required
def chart_category_avg_price(request):
    qs = Category.objects.annotate(avg_price=Avg('products__prices__price')).exclude(avg_price=None).order_by('name')
    return JsonResponse({'labels': [c.name for c in qs], 'values': [round(float(c.avg_price), 2) for c in qs]})


@staff_member_required
def chart_store_listing_count(request):
    qs = Store.objects.annotate(cnt=Count('product_prices')).order_by('-cnt')
    return JsonResponse({'labels': [s.name for s in qs], 'values': [s.cnt for s in qs]})


@staff_member_required
def chart_category_distribution(request):
    qs = Category.objects.annotate(cnt=Count('products')).order_by('-cnt')
    return JsonResponse({'labels': [c.name for c in qs], 'values': [c.cnt for c in qs]})


@staff_member_required
def chart_user_signups(request):
    """Users grouped by signup month (last 6 months) — simple aggregate in Python
    to stay MySQL/SQLite compatible without vendor-specific date_trunc SQL."""
    from django.utils import timezone

    now = timezone.now()
    keys = []
    y, m = now.year, now.month
    for _ in range(6):
        keys.append((y, m))
        m -= 1
        if m == 0:
            m = 12
            y -= 1
    keys.reverse()
    counts = {k: 0 for k in keys}
    for u in User.objects.all():
        key = (u.date_joined.year, u.date_joined.month)
        if key in counts:
            counts[key] += 1
    labels = [f'{k[0]}-{k[1]:02d}' for k in keys]
    values = [counts[k] for k in keys]
    return JsonResponse({'labels': labels, 'values': values})


# ============================================================
# Manage Users
# ============================================================

@staff_member_required
def manage_users(request):
    users = User.objects.all().order_by('-date_joined')
    q = request.GET.get('q', '')
    if q:
        users = users.filter(Q(username__icontains=q) | Q(email__icontains=q) | Q(first_name__icontains=q))
    paginator = Paginator(users, 10)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'dashboard/manage_users.html', {'page_obj': page_obj, 'users': page_obj.object_list, 'q': q})


@staff_member_required
def user_create(request):
    if request.method == 'POST':
        form = AdminUserForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            raw_password = form.cleaned_data.get('password') or User.objects.make_random_password()
            user.set_password(raw_password)
            user.save()
            log_admin_action(request.user, 'CREATE', 'User', user.username)
            messages.success(request, f'User "{user.username}" created successfully.')
            return redirect('dashboard:manage_users')
    else:
        form = AdminUserForm()
    return render(request, 'dashboard/user_form.html', {'form': form, 'title': 'Add User'})


@staff_member_required
def user_update(request, pk):
    user_obj = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        form = AdminUserForm(request.POST, instance=user_obj)
        if form.is_valid():
            form.save()
            log_admin_action(request.user, 'UPDATE', 'User', user_obj.username)
            messages.success(request, f'User "{user_obj.username}" updated successfully.')
            return redirect('dashboard:manage_users')
    else:
        form = AdminUserForm(instance=user_obj)
    return render(request, 'dashboard/user_form.html', {'form': form, 'title': 'Edit User', 'user_obj': user_obj})


@staff_member_required
def user_delete(request, pk):
    user_obj = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        username = user_obj.username
        user_obj.delete()
        log_admin_action(request.user, 'DELETE', 'User', username)
        messages.success(request, f'User "{username}" deleted.')
        return redirect('dashboard:manage_users')
    return render(request, 'dashboard/user_confirm_delete.html', {'user_obj': user_obj})


@staff_member_required
def user_toggle_active(request, pk):
    user_obj = get_object_or_404(User, pk=pk)
    user_obj.is_active = not user_obj.is_active
    user_obj.save(update_fields=['is_active'])
    log_admin_action(request.user, 'ACTIVATE' if user_obj.is_active else 'DEACTIVATE', 'User', user_obj.username)
    status = 'activated' if user_obj.is_active else 'deactivated'
    messages.success(request, f'User "{user_obj.username}" {status}.')
    return redirect('dashboard:manage_users')


@staff_member_required
def admin_logs_view(request):
    logs = AdminLog.objects.select_related('user').all()
    paginator = Paginator(logs, 20)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'dashboard/admin_logs.html', {'page_obj': page_obj, 'logs': page_obj.object_list})
