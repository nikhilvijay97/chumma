from django.urls import path

from . import views

app_name = 'contact'

urlpatterns = [
    path('', views.contact_view, name='contact'),
    path('feedback/', views.feedback_view, name='feedback'),
    path('newsletter/subscribe/', views.newsletter_subscribe, name='newsletter_subscribe'),

    path('manage/messages/', views.admin_contact_messages, name='admin_contact_messages'),
    path('manage/messages/<int:pk>/', views.admin_contact_message_read, name='admin_contact_message_read'),
    path('manage/messages/<int:pk>/delete/', views.admin_contact_message_delete, name='admin_contact_message_delete'),
    path('manage/feedback/', views.admin_feedback_list, name='admin_feedback_list'),
    path('manage/newsletter/', views.admin_newsletter_list, name='admin_newsletter_list'),
]
