from django.test import TestCase
from django.urls import reverse

from accounts.models import User

from .models import ContactMessage, Feedback, NewsletterSubscriber


class ContactFormTests(TestCase):
    def test_contact_form_creates_message(self):
        response = self.client.post(reverse('contact:contact'), {
            'name': 'Test User', 'email': 'test@example.com', 'subject': 'Hello', 'message': 'Test message body.',
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(ContactMessage.objects.filter(subject='Hello').exists())

    def test_feedback_form_creates_feedback(self):
        response = self.client.post(reverse('contact:feedback'), {
            'name': 'Test User', 'email': 'test@example.com', 'rating': 5, 'message': 'Great site!',
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Feedback.objects.filter(email='test@example.com').exists())

    def test_newsletter_subscribe(self):
        response = self.client.post(reverse('contact:newsletter_subscribe'), {'email': 'sub@example.com'},
                                     HTTP_X_REQUESTED_WITH='XMLHttpRequest')
        self.assertEqual(response.status_code, 200)
        self.assertTrue(NewsletterSubscriber.objects.filter(email='sub@example.com').exists())


class ContactAdminViewTests(TestCase):
    def setUp(self):
        self.staff = User.objects.create_user(username='staffer', password='pass12345', is_staff=True)
        self.msg = ContactMessage.objects.create(name='A', email='a@example.com', subject='Test', message='Hi')

    def test_admin_messages_requires_staff(self):
        response = self.client.get(reverse('contact:admin_contact_messages'))
        self.assertNotEqual(response.status_code, 200)

    def test_admin_can_view_and_mark_read(self):
        self.client.login(username='staffer', password='pass12345')
        response = self.client.get(reverse('contact:admin_contact_message_read', args=[self.msg.pk]))
        self.assertEqual(response.status_code, 200)
        self.msg.refresh_from_db()
        self.assertTrue(self.msg.is_read)
