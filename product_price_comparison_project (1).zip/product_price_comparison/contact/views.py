from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render

from dashboard.utils import log_admin_action

from .forms import ContactForm, FeedbackForm, NewsletterForm
from .models import ContactMessage, Feedback, NewsletterSubscriber


def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your message has been sent. Our team will get back to you soon.')
            return redirect('contact:contact')
    else:
        initial = {}
        if request.user.is_authenticated:
            initial = {'name': request.user.full_name, 'email': request.user.email}
        form = ContactForm(initial=initial)
    return render(request, 'contact/contact.html', {'form': form})


def feedback_view(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            if request.user.is_authenticated:
                feedback.user = request.user
            feedback.save()
            messages.success(request, 'Thank you for your feedback!')
            return redirect('contact:feedback')
    else:
        initial = {}
        if request.user.is_authenticated:
            initial = {'name': request.user.full_name, 'email': request.user.email}
        form = FeedbackForm(initial=initial)
    return render(request, 'contact/feedback.html', {'form': form})


def newsletter_subscribe(request):
    if request.method == 'POST':
        form = NewsletterForm(request.POST)
        if form.is_valid():
            form.save()
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'message': 'Subscribed successfully!'})
            messages.success(request, 'Subscribed to our newsletter!')
        else:
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'success': False, 'message': 'Invalid or already subscribed email.'})
    return redirect(request.META.get('HTTP_REFERER', 'products:home'))


# ------------------------- Staff views -------------------------

@staff_member_required
def admin_contact_messages(request):
    messages_qs = ContactMessage.objects.all()
    paginator = Paginator(messages_qs, 15)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'contact/admin_contact_messages.html', {'page_obj': page_obj, 'messages_list': page_obj.object_list})


@staff_member_required
def admin_contact_message_read(request, pk):
    msg = get_object_or_404(ContactMessage, pk=pk)
    msg.is_read = True
    msg.save(update_fields=['is_read'])
    return render(request, 'contact/admin_contact_message_detail.html', {'msg': msg})


@staff_member_required
def admin_contact_message_delete(request, pk):
    msg = get_object_or_404(ContactMessage, pk=pk)
    if request.method == 'POST':
        subject = msg.subject
        msg.delete()
        log_admin_action(request.user, 'DELETE', 'ContactMessage', subject)
        messages.success(request, 'Message deleted.')
        return redirect('contact:admin_contact_messages')
    return render(request, 'contact/admin_contact_message_confirm_delete.html', {'msg': msg})


@staff_member_required
def admin_feedback_list(request):
    feedback_qs = Feedback.objects.all()
    paginator = Paginator(feedback_qs, 15)
    page_obj = paginator.get_page(request.GET.get('page'))
    avg_rating = None
    if feedback_qs.exists():
        avg_rating = round(sum(f.rating for f in feedback_qs) / feedback_qs.count(), 1)
    return render(request, 'contact/admin_feedback_list.html', {
        'page_obj': page_obj, 'feedback_list': page_obj.object_list, 'avg_rating': avg_rating,
    })


@staff_member_required
def admin_newsletter_list(request):
    subs = NewsletterSubscriber.objects.all()
    paginator = Paginator(subs, 20)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'contact/admin_newsletter_list.html', {'page_obj': page_obj, 'subscribers': page_obj.object_list})
