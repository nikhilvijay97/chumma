-- =====================================================================
-- Product Price Comparison System — MySQL Dump
-- Compatible with MySQL 5.7+ / MySQL 8 / MariaDB (XAMPP) via phpMyAdmin
--
-- Creates the COMPLETE schema (Django core tables + all 9 app tables)
-- and inserts sample data. Full alternative to running
-- `python manage.py migrate` + `python manage.py seed_data`.
--
-- Import: phpMyAdmin -> Import tab -> choose this file -> Go.
-- Do NOT run `python manage.py migrate` after importing this file on the
-- same database — the schema is already complete.
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'STRICT_TRANS_TABLES';

CREATE DATABASE IF NOT EXISTS `pricecomparison_db`
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `pricecomparison_db`;

-- ---------------------------------------------------------------------
-- Django core tables
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `app` varchar(255) NOT NULL,
    `name` varchar(255) NOT NULL,
    `applied` datetime(6) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type` (
    `id` int NOT NULL AUTO_INCREMENT,
    `app_label` varchar(100) NOT NULL,
    `model` varchar(100) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `django_content_type_app_label_model_uniq` (`app_label`, `model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission` (
    `id` int NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `content_type_id` int NOT NULL,
    `codename` varchar(100) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `auth_permission_content_type_id_codename_uniq` (`content_type_id`, `codename`),
    CONSTRAINT `auth_permission_content_type_id_fk` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
    `id` int NOT NULL AUTO_INCREMENT,
    `name` varchar(150) NOT NULL UNIQUE,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `group_id` int NOT NULL,
    `permission_id` int NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `auth_group_permissions_group_id_permission_id_uniq` (`group_id`, `permission_id`),
    CONSTRAINT `auth_group_permissions_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
    CONSTRAINT `auth_group_permissions_permission_id_fk` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session` (
    `session_key` varchar(40) NOT NULL,
    `session_data` longtext NOT NULL,
    `expire_date` datetime(6) NOT NULL,
    PRIMARY KEY (`session_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- accounts app  (table name: users)
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `password` varchar(128) NOT NULL,
    `last_login` datetime(6) DEFAULT NULL,
    `is_superuser` tinyint(1) NOT NULL,
    `username` varchar(150) NOT NULL UNIQUE,
    `first_name` varchar(150) NOT NULL,
    `last_name` varchar(150) NOT NULL,
    `email` varchar(254) NOT NULL,
    `is_staff` tinyint(1) NOT NULL,
    `is_active` tinyint(1) NOT NULL,
    `date_joined` datetime(6) NOT NULL,
    `phone` varchar(15) DEFAULT NULL,
    `address` longtext,
    `city` varchar(100) DEFAULT NULL,
    `avatar` varchar(100) DEFAULT NULL,
    `is_verified` tinyint(1) NOT NULL,
    `created_at` datetime(6) NOT NULL,
    `updated_at` datetime(6) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE `users_groups` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `user_id` bigint NOT NULL,
    `group_id` int NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `users_groups_user_id_group_id_uniq` (`user_id`, `group_id`),
    CONSTRAINT `users_groups_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
    CONSTRAINT `users_groups_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `users_user_permissions`;
CREATE TABLE `users_user_permissions` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `user_id` bigint NOT NULL,
    `permission_id` int NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `users_user_permissions_user_id_permission_id_uniq` (`user_id`, `permission_id`),
    CONSTRAINT `users_user_permissions_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
    CONSTRAINT `users_user_permissions_permission_id_fk` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log` (
    `id` int NOT NULL AUTO_INCREMENT,
    `action_time` datetime(6) NOT NULL,
    `object_id` longtext,
    `object_repr` varchar(200) NOT NULL,
    `action_flag` smallint UNSIGNED NOT NULL,
    `change_message` longtext NOT NULL,
    `content_type_id` int DEFAULT NULL,
    `user_id` bigint NOT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT `django_admin_log_content_type_id_fk` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
    CONSTRAINT `django_admin_log_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- categories / brands / stores apps
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `name` varchar(120) NOT NULL UNIQUE,
    `slug` varchar(140) NOT NULL UNIQUE,
    `description` longtext NOT NULL,
    `icon` varchar(50) NOT NULL,
    `image` varchar(100) DEFAULT NULL,
    `is_active` tinyint(1) NOT NULL,
    `created_at` datetime(6) NOT NULL,
    `updated_at` datetime(6) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `name` varchar(120) NOT NULL UNIQUE,
    `slug` varchar(140) NOT NULL UNIQUE,
    `logo` varchar(100) DEFAULT NULL,
    `description` longtext NOT NULL,
    `is_active` tinyint(1) NOT NULL,
    `created_at` datetime(6) NOT NULL,
    `updated_at` datetime(6) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `stores`;
CREATE TABLE `stores` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `name` varchar(120) NOT NULL UNIQUE,
    `slug` varchar(140) NOT NULL UNIQUE,
    `logo` varchar(100) DEFAULT NULL,
    `website_url` varchar(200) NOT NULL,
    `address` longtext NOT NULL,
    `is_active` tinyint(1) NOT NULL,
    `created_at` datetime(6) NOT NULL,
    `updated_at` datetime(6) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- products app
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `name` varchar(200) NOT NULL,
    `slug` varchar(220) NOT NULL UNIQUE,
    `description` longtext NOT NULL,
    `specifications` longtext NOT NULL,
    `is_featured` tinyint(1) NOT NULL,
    `is_trending` tinyint(1) NOT NULL,
    `is_active` tinyint(1) NOT NULL,
    `created_at` datetime(6) NOT NULL,
    `updated_at` datetime(6) NOT NULL,
    `category_id` bigint NOT NULL,
    `brand_id` bigint DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `products_name_idx` (`name`),
    KEY `products_category_idx` (`category_id`),
    KEY `products_brand_idx` (`brand_id`),
    CONSTRAINT `products_category_id_fk` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
    CONSTRAINT `products_brand_id_fk` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `product_images`;
CREATE TABLE `product_images` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `image` varchar(100) NOT NULL,
    `alt_text` varchar(150) NOT NULL,
    `is_primary` tinyint(1) NOT NULL,
    `created_at` datetime(6) NOT NULL,
    `product_id` bigint NOT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT `product_images_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `product_prices`;
CREATE TABLE `product_prices` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `price` decimal(10,2) NOT NULL,
    `old_price` decimal(10,2) DEFAULT NULL,
    `product_url` varchar(200) NOT NULL,
    `in_stock` tinyint(1) NOT NULL,
    `updated_at` datetime(6) NOT NULL,
    `created_at` datetime(6) NOT NULL,
    `product_id` bigint NOT NULL,
    `store_id` bigint NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `product_prices_product_id_store_id_uniq` (`product_id`, `store_id`),
    CONSTRAINT `product_prices_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
    CONSTRAINT `product_prices_store_id_fk` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `price_history`;
CREATE TABLE `price_history` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `price` decimal(10,2) NOT NULL,
    `recorded_at` datetime(6) NOT NULL,
    `product_price_id` bigint NOT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT `price_history_product_price_id_fk` FOREIGN KEY (`product_price_id`) REFERENCES `product_prices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `search_history`;
CREATE TABLE `search_history` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `query` varchar(255) NOT NULL,
    `results_count` int UNSIGNED NOT NULL,
    `created_at` datetime(6) NOT NULL,
    `user_id` bigint DEFAULT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT `search_history_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `recently_viewed`;
CREATE TABLE `recently_viewed` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `viewed_at` datetime(6) NOT NULL,
    `product_id` bigint NOT NULL,
    `user_id` bigint NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `recently_viewed_user_id_product_id_uniq` (`user_id`, `product_id`),
    CONSTRAINT `recently_viewed_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
    CONSTRAINT `recently_viewed_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- wishlist app
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `wishlist`;
CREATE TABLE `wishlist` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `target_price` decimal(10,2) DEFAULT NULL,
    `added_at` datetime(6) NOT NULL,
    `product_id` bigint NOT NULL,
    `user_id` bigint NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `wishlist_user_id_product_id_uniq` (`user_id`, `product_id`),
    CONSTRAINT `wishlist_product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
    CONSTRAINT `wishlist_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- contact app
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `contact_messages`;
CREATE TABLE `contact_messages` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `name` varchar(150) NOT NULL,
    `email` varchar(254) NOT NULL,
    `subject` varchar(200) NOT NULL,
    `message` longtext NOT NULL,
    `is_read` tinyint(1) NOT NULL,
    `created_at` datetime(6) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `name` varchar(150) NOT NULL,
    `email` varchar(254) NOT NULL,
    `rating` smallint UNSIGNED NOT NULL,
    `message` longtext NOT NULL,
    `created_at` datetime(6) NOT NULL,
    `user_id` bigint DEFAULT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT `feedback_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `newsletter_subscribers`;
CREATE TABLE `newsletter_subscribers` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `email` varchar(254) NOT NULL UNIQUE,
    `subscribed_at` datetime(6) NOT NULL,
    `is_active` tinyint(1) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- dashboard app
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `admin_logs`;
CREATE TABLE `admin_logs` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `action` varchar(20) NOT NULL,
    `model_name` varchar(100) NOT NULL,
    `object_repr` varchar(255) NOT NULL,
    `timestamp` datetime(6) NOT NULL,
    `user_id` bigint DEFAULT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT `admin_logs_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- Sample data
-- =====================================================================

-- Users
-- NOTE: the password hashes below are illustrative placeholders, not
-- valid working hashes. After import, run:
--   python manage.py changepassword admin
-- or seed a fresh migrated database with `python manage.py seed_data`
-- instead, which sets real, working password hashes
-- (admin/Admin@12345, customers/Password@123).
INSERT INTO `users`
(`id`,`password`,`last_login`,`is_superuser`,`username`,`first_name`,`last_name`,`email`,`is_staff`,`is_active`,`date_joined`,`phone`,`address`,`city`,`avatar`,`is_verified`,`created_at`,`updated_at`)
VALUES
(1,'pbkdf2_sha256$720000$placeholder$hash1==',NULL,1,'admin','Site','Administrator','admin@pricecomparison.local',1,1,'2026-01-01 09:00:00.000000',NULL,NULL,NULL,NULL,1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(2,'pbkdf2_sha256$720000$placeholder$hash2==',NULL,0,'john_doe','John','Doe','john@example.com',0,1,'2026-01-02 10:00:00.000000','9876500001',NULL,'Mumbai',NULL,0,'2026-01-02 10:00:00.000000','2026-01-02 10:00:00.000000'),
(3,'pbkdf2_sha256$720000$placeholder$hash2==',NULL,0,'priya_sharma','Priya','Sharma','priya@example.com',0,1,'2026-01-02 10:05:00.000000','9876500002',NULL,'Bengaluru',NULL,0,'2026-01-02 10:05:00.000000','2026-01-02 10:05:00.000000'),
(4,'pbkdf2_sha256$720000$placeholder$hash2==',NULL,0,'amit_kumar','Amit','Kumar','amit@example.com',0,1,'2026-01-02 10:10:00.000000','9876500003',NULL,'Delhi',NULL,0,'2026-01-02 10:10:00.000000','2026-01-02 10:10:00.000000');

-- Categories
INSERT INTO `categories` (`id`,`name`,`slug`,`description`,`icon`,`image`,`is_active`,`created_at`,`updated_at`) VALUES
(1,'Mobiles & Accessories','mobiles-accessories','Compare prices on the best mobiles & accessories.','bi-phone',NULL,1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(2,'Laptops & Computers','laptops-computers','Compare prices on the best laptops & computers.','bi-laptop',NULL,1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(3,'Televisions','televisions','Compare prices on the best televisions.','bi-tv',NULL,1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(4,'Audio & Headphones','audio-headphones','Compare prices on the best audio & headphones.','bi-headphones',NULL,1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(5,'Home Appliances','home-appliances','Compare prices on the best home appliances.','bi-house-gear',NULL,1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(6,'Fashion & Footwear','fashion-footwear','Compare prices on the best fashion & footwear.','bi-bag',NULL,1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(7,'Fitness & Wearables','fitness-wearables','Compare prices on the best fitness & wearables.','bi-smartwatch',NULL,1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(8,'Cameras','cameras','Compare prices on the best cameras.','bi-camera',NULL,1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000');

-- Brands
INSERT INTO `brands` (`id`,`name`,`slug`,`logo`,`description`,`is_active`,`created_at`,`updated_at`) VALUES
(1,'Nova','nova',NULL,'Nova — trusted electronics and lifestyle brand.',1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(2,'Skyline','skyline',NULL,'Skyline — trusted electronics and lifestyle brand.',1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(3,'Zenith','zenith',NULL,'Zenith — trusted electronics and lifestyle brand.',1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(4,'Vantage','vantage',NULL,'Vantage — trusted electronics and lifestyle brand.',1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(5,'Orbit','orbit',NULL,'Orbit — trusted electronics and lifestyle brand.',1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(6,'Pulse','pulse',NULL,'Pulse — trusted electronics and lifestyle brand.',1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000');

-- Stores
INSERT INTO `stores` (`id`,`name`,`slug`,`logo`,`website_url`,`address`,`is_active`,`created_at`,`updated_at`) VALUES
(1,'Amazon.in','amazonin',NULL,'https://www.amazon.in','',1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(2,'Flipkart','flipkart',NULL,'https://www.flipkart.com','',1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(3,'Croma','croma',NULL,'https://www.croma.com','',1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(4,'Reliance Digital','reliance-digital',NULL,'https://www.reliancedigital.in','',1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000'),
(5,'Vijay Sales','vijay-sales',NULL,'https://www.vijaysales.com','',1,'2026-01-01 09:00:00.000000','2026-01-01 09:00:00.000000');

-- Products
INSERT INTO `products` (`id`,`name`,`slug`,`description`,`specifications`,`is_featured`,`is_trending`,`is_active`,`created_at`,`updated_at`,`category_id`,`brand_id`) VALUES
(1,'Galaxy Phantom X5 (128GB)','galaxy-phantom-x5-128gb','The Galaxy Phantom X5 (128GB) by Nova offers excellent value and performance.','RAM: 8GB\nStorage: 128GB\nDisplay: 6.5" AMOLED\nBattery: 5000mAh',1,1,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',1,1),
(2,'Pixel Aurora 9 Pro','pixel-aurora-9-pro','The Pixel Aurora 9 Pro by Skyline offers excellent value and performance.','RAM: 12GB\nStorage: 256GB\nDisplay: 6.7" OLED\nCamera: 50MP Triple',1,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',1,2),
(3,'iSpark 15 (256GB)','ispark-15-256gb','The iSpark 15 (256GB) by Zenith offers excellent value and performance.','Storage: 256GB\nDisplay: 6.1" Super Retina\nChip: A17 Bionic',0,1,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',1,3),
(4,'Wireless Earbuds Pro 2','wireless-earbuds-pro-2','The Wireless Earbuds Pro 2 by Nova offers excellent value and performance.','Battery: 30hrs total\nANC: Yes\nBluetooth: 5.3',0,1,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',1,1),
(5,'UltraBook Air 14"','ultrabook-air-14','The UltraBook Air 14" by Zenith offers excellent value and performance.','RAM: 16GB\nStorage: 512GB SSD\nProcessor: M2 chip',1,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',2,3),
(6,'GameForce Pro 16" RTX','gameforce-pro-16-rtx','The GameForce Pro 16" RTX by Skyline offers excellent value and performance.','RAM: 32GB\nGPU: RTX 4070\nDisplay: 165Hz QHD',1,1,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',2,2),
(7,'Chromatic Notebook 11','chromatic-notebook-11','The Chromatic Notebook 11 by Nova offers excellent value and performance.','RAM: 8GB\nStorage: 128GB eMMC\nOS: ChromeOS',0,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',2,1),
(8,'Crystal 55" 4K Smart TV','crystal-55-4k-smart-tv','The Crystal 55" 4K Smart TV by Vantage offers excellent value and performance.','Resolution: 4K UHD\nHDR: Dolby Vision\nSmart OS: Android TV',1,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',3,4),
(9,'OLED Infinity 65"','oled-infinity-65','The OLED Infinity 65" by Zenith offers excellent value and performance.','Resolution: 4K OLED\nRefresh: 120Hz\nHDMI: 4 ports',0,1,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',3,3),
(10,'Bass Boost Over-Ear Headphones','bass-boost-over-ear-headphones','The Bass Boost Over-Ear Headphones by Nova offers excellent value and performance.','Driver: 40mm\nBattery: 40hrs\nANC: Yes',0,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',4,1),
(11,'Studio Monitor Speakers (Pair)','studio-monitor-speakers-pair','The Studio Monitor Speakers (Pair) by Skyline offers excellent value and performance.','Power: 100W RMS\nConnectivity: Bluetooth + AUX',0,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',4,2),
(12,'Frost-Free Refrigerator 340L','frost-free-refrigerator-340l','The Frost-Free Refrigerator 340L by Vantage offers excellent value and performance.','Capacity: 340L\nStar Rating: 3 Star\nType: Double Door',1,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',5,4),
(13,'Front Load Washing Machine 7kg','front-load-washing-machine-7kg','The Front Load Washing Machine 7kg by Zenith offers excellent value and performance.','Capacity: 7kg\nRPM: 1200\nType: Front Load',0,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',5,3),
(14,'Smart Air Purifier','smart-air-purifier','The Smart Air Purifier by Nova offers excellent value and performance.','Coverage: 500 sq ft\nFilter: HEPA H13\nApp Control: Yes',0,1,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',5,1),
(15,'Running Shoes Aero Trail','running-shoes-aero-trail','The Running Shoes Aero Trail by Skyline offers excellent value and performance.','Material: Mesh\nSole: EVA Foam\nType: Running',0,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',6,2),
(16,'Leather Messenger Bag','leather-messenger-bag','The Leather Messenger Bag by Vantage offers excellent value and performance.','Material: Genuine Leather\nCapacity: 15" Laptop',0,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',6,4),
(17,'FitTrack Smartwatch Series 4','fittrack-smartwatch-series-4','The FitTrack Smartwatch Series 4 by Nova offers excellent value and performance.','Display: AMOLED\nBattery: 7 days\nGPS: Yes',1,1,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',7,1),
(18,'Pulse Fitness Band','pulse-fitness-band','The Pulse Fitness Band by Skyline offers excellent value and performance.','Battery: 14 days\nWater Resistance: 5ATM',0,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',7,2),
(19,'MirrorPro X100 Mirrorless Camera','mirrorpro-x100-mirrorless-camera','The MirrorPro X100 Mirrorless Camera by Zenith offers excellent value and performance.','Sensor: 24MP APS-C\nVideo: 4K 60fps',0,0,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',8,3),
(20,'ActionCam 4K Waterproof','actioncam-4k-waterproof','The ActionCam 4K Waterproof by Vantage offers excellent value and performance.','Video: 4K 30fps\nWaterproof: 10m\nStabilization: Yes',0,1,1,'2026-01-03 09:00:00.000000','2026-01-03 09:00:00.000000',8,4);

-- Product Prices (3-4 stores per product; lowest price varies per store
-- so the "best price" highlight logic is visible on each product page)
INSERT INTO `product_prices` (`id`,`price`,`old_price`,`product_url`,`in_stock`,`updated_at`,`created_at`,`product_id`,`store_id`) VALUES
(1,24999.00,27999.00,'https://example.com/amazonin/galaxy-phantom-x5-128gb',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',1,1),
(2,25999.00,NULL,'https://example.com/flipkart/galaxy-phantom-x5-128gb',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',1,2),
(3,26999.00,NULL,'https://example.com/croma/galaxy-phantom-x5-128gb',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',1,3),
(4,54999.00,NULL,'https://example.com/amazonin/pixel-aurora-9-pro',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',2,1),
(5,52999.00,58999.00,'https://example.com/reliance-digital/pixel-aurora-9-pro',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',2,4),
(6,56999.00,NULL,'https://example.com/vijay-sales/pixel-aurora-9-pro',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',2,5),
(7,69999.00,NULL,'https://example.com/amazonin/ispark-15-256gb',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',3,1),
(8,67999.00,74999.00,'https://example.com/croma/ispark-15-256gb',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',3,3),
(9,2499.00,2999.00,'https://example.com/flipkart/wireless-earbuds-pro-2',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',4,2),
(10,2299.00,2699.00,'https://example.com/amazonin/wireless-earbuds-pro-2',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',4,1),
(11,64999.00,NULL,'https://example.com/amazonin/ultrabook-air-14',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',5,1),
(12,62999.00,68999.00,'https://example.com/croma/ultrabook-air-14',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',5,3),
(13,124999.00,137999.00,'https://example.com/flipkart/gameforce-pro-16-rtx',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',6,2),
(14,119999.00,NULL,'https://example.com/vijay-sales/gameforce-pro-16-rtx',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',6,5),
(15,21999.00,NULL,'https://example.com/amazonin/chromatic-notebook-11',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',7,1),
(16,20999.00,23999.00,'https://example.com/reliance-digital/chromatic-notebook-11',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',7,4),
(17,42999.00,49999.00,'https://example.com/croma/crystal-55-4k-smart-tv',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',8,3),
(18,44999.00,NULL,'https://example.com/vijay-sales/crystal-55-4k-smart-tv',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',8,5),
(19,129999.00,NULL,'https://example.com/amazonin/oled-infinity-65',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',9,1),
(20,124999.00,138999.00,'https://example.com/reliance-digital/oled-infinity-65',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',9,4),
(21,3999.00,NULL,'https://example.com/flipkart/bass-boost-over-ear-headphones',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',10,2),
(22,3799.00,4299.00,'https://example.com/amazonin/bass-boost-over-ear-headphones',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',10,1),
(23,8999.00,NULL,'https://example.com/croma/studio-monitor-speakers-pair',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',11,3),
(24,8499.00,9999.00,'https://example.com/vijay-sales/studio-monitor-speakers-pair',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',11,5),
(25,28999.00,NULL,'https://example.com/reliance-digital/frost-free-refrigerator-340l',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',12,4),
(26,27499.00,29999.00,'https://example.com/croma/frost-free-refrigerator-340l',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',12,3),
(27,26999.00,NULL,'https://example.com/amazonin/front-load-washing-machine-7kg',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',13,1),
(28,25999.00,28999.00,'https://example.com/vijay-sales/front-load-washing-machine-7kg',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',13,5),
(29,9999.00,NULL,'https://example.com/flipkart/smart-air-purifier',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',14,2),
(30,9499.00,10999.00,'https://example.com/amazonin/smart-air-purifier',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',14,1),
(31,2999.00,3699.00,'https://example.com/amazonin/running-shoes-aero-trail',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',15,1),
(32,2799.00,3299.00,'https://example.com/flipkart/running-shoes-aero-trail',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',15,2),
(33,1899.00,NULL,'https://example.com/croma/leather-messenger-bag',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',16,3),
(34,1799.00,2099.00,'https://example.com/amazonin/leather-messenger-bag',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',16,1),
(35,7999.00,8999.00,'https://example.com/flipkart/fittrack-smartwatch-series-4',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',17,2),
(36,7599.00,8999.00,'https://example.com/amazonin/fittrack-smartwatch-series-4',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',17,1),
(37,1999.00,NULL,'https://example.com/croma/pulse-fitness-band',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',18,3),
(38,1899.00,2199.00,'https://example.com/vijay-sales/pulse-fitness-band',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',18,5),
(39,84999.00,NULL,'https://example.com/amazonin/mirrorpro-x100-mirrorless-camera',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',19,1),
(40,82999.00,89999.00,'https://example.com/reliance-digital/mirrorpro-x100-mirrorless-camera',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',19,4),
(41,12999.00,14999.00,'https://example.com/flipkart/actioncam-4k-waterproof',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',20,2),
(42,12499.00,NULL,'https://example.com/croma/actioncam-4k-waterproof',1,'2026-01-20 09:00:00.000000','2026-01-03 09:00:00.000000',20,3);

-- Price History (short trailing history per listing so the trend chart
-- on the product detail page has real data points)
INSERT INTO `price_history` (`id`,`price`,`recorded_at`,`product_price_id`) VALUES
(1,26999.00,'2025-12-21 09:00:00.000000',1),
(2,25999.00,'2025-12-31 09:00:00.000000',1),
(3,25499.00,'2026-01-10 09:00:00.000000',1),
(4,24999.00,'2026-01-20 09:00:00.000000',1),
(5,27999.00,'2025-12-21 09:00:00.000000',2),
(6,26999.00,'2025-12-31 09:00:00.000000',2),
(7,26499.00,'2026-01-10 09:00:00.000000',2),
(8,25999.00,'2026-01-20 09:00:00.000000',2),
(9,58999.00,'2025-12-21 09:00:00.000000',4),
(10,56999.00,'2025-12-31 09:00:00.000000',4),
(11,55999.00,'2026-01-10 09:00:00.000000',4),
(12,54999.00,'2026-01-20 09:00:00.000000',4),
(13,2999.00,'2025-12-21 09:00:00.000000',9),
(14,2799.00,'2025-12-31 09:00:00.000000',9),
(15,2599.00,'2026-01-10 09:00:00.000000',9),
(16,2499.00,'2026-01-20 09:00:00.000000',9),
(17,46999.00,'2025-12-21 09:00:00.000000',17),
(18,44999.00,'2025-12-31 09:00:00.000000',17),
(19,43999.00,'2026-01-10 09:00:00.000000',17),
(20,42999.00,'2026-01-20 09:00:00.000000',17);

-- Wishlist
INSERT INTO `wishlist` (`id`,`target_price`,`added_at`,`product_id`,`user_id`) VALUES
(1,23000.00,'2026-01-19 09:00:00.000000',1,2),
(2,NULL,'2026-01-19 09:05:00.000000',5,2),
(3,NULL,'2026-01-19 10:00:00.000000',9,3),
(4,120000.00,'2026-01-19 10:05:00.000000',9,4),
(5,NULL,'2026-01-19 11:00:00.000000',17,3),
(6,NULL,'2026-01-19 11:15:00.000000',19,4);

-- Contact Messages
INSERT INTO `contact_messages` (`id`,`name`,`email`,`subject`,`message`,`is_read`,`created_at`) VALUES
(1,'Ravi Verma','ravi@example.com','Wrong price listed','The price for the Galaxy Phantom X5 on Croma looks outdated. Please update it.',0,'2026-01-21 10:00:00.000000'),
(2,'Sneha Iyer','sneha@example.com','Add a new store','Could you please add Tata Cliq as a partner store for comparison?',0,'2026-01-21 11:00:00.000000');

-- Feedback
INSERT INTO `feedback` (`id`,`name`,`email`,`rating`,`message`,`created_at`,`user_id`) VALUES
(1,'John Doe','john@example.com',5,'Great platform! Saved me a lot of money on my laptop purchase.','2026-01-18 09:00:00.000000',2),
(2,'Priya Sharma','priya@example.com',4,'Very useful, would love to see more stores added.','2026-01-18 10:00:00.000000',3);

-- Newsletter Subscribers
INSERT INTO `newsletter_subscribers` (`id`,`email`,`subscribed_at`,`is_active`) VALUES
(1,'newsletter1@example.com','2026-01-15 09:00:00.000000',1),
(2,'newsletter2@example.com','2026-01-16 09:00:00.000000',1),
(3,'newsletter3@example.com','2026-01-17 09:00:00.000000',1);

-- =====================================================================
-- End of dump
-- =====================================================================
