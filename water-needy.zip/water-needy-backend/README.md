# Water-Needy — Backend (Django + DRF + JWT)

The backend of the **Water-Needy** platform — a centralized water connect
service for consumers, suppliers, drivers, and admins.

## Quick start

```bash
cd backend
python -m venv venv && source venv/bin/activate   # optional but recommended
pip install -r requirements.txt

# Create the SQLite database & apply schema migrations
python manage.py makemigrations
python manage.py migrate

# (Highly recommended) populate with sample users + orders
python manage.py seed_data

# Boot the dev server at http://127.0.0.1:8000
python manage.py runserver
```

## Sample credentials

| Role      | Username  | Password      |
| --------- | --------- | ------------- |
| Admin     | `admin`   | `admin123`    |
| Consumer  | `alice`   | `consumer123` |
| Supplier  | `aquapure`| `supplier123` |
| Driver    | `dravi`   | `driver123`   |

## Endpoints (all JSON, prefixed with `/api`)

### Auth & profile
- `POST /api/auth/token/` — obtain JWT (used internally; the frontend calls `/api/accounts/login/` instead)
- `POST /api/accounts/register/`
- `POST /api/accounts/login/` — returns `{access, refresh, user}`
- `POST /api/accounts/forgot-password/`
- `POST /api/accounts/change-password/`
- `GET/PUT /api/accounts/profile/`

### Consumer
- `GET /api/consumer/dashboard/`
- `POST /api/consumer/orders/create/`
- `GET /api/consumer/orders/`
- `GET /api/consumer/orders/<id>/`
- `POST /api/consumer/orders/<id>/cancel/`
- `GET /api/consumer/suppliers/nearby/?city=…&pincode=…`
- `POST /api/consumer/reviews/`

### Supplier
- `GET /api/supplier/dashboard/`
- `GET/POST /api/supplier/inventory/`
- `GET/PUT/DELETE /api/supplier/inventory/<id>/`
- `GET /api/supplier/orders/`
- `POST /api/supplier/orders/<id>/approve/`
- `POST /api/supplier/orders/<id>/reject/`
- `POST /api/supplier/orders/<id>/assign-driver/`
- `GET /api/supplier/drivers/available/`
- `GET /api/supplier/reviews/`

### Driver
- `GET /api/driver/dashboard/`
- `GET /api/driver/orders/`
- `GET /api/driver/orders/history/`
- `GET /api/driver/orders/<id>/`
- `POST /api/driver/orders/<id>/status/` — body: `{ "status": "picked_up" | "on_the_way" | "delivered" }`

### Admin
- `GET /api/admin-panel/dashboard/`
- `GET /api/admin-panel/users/?role=…`
- `POST /api/admin-panel/users/<id>/toggle/`
- `GET /api/admin-panel/suppliers/pending/`
- `POST /api/admin-panel/suppliers/<id>/approve/`
- `GET /api/admin-panel/drivers/pending/`
- `POST /api/admin-panel/drivers/<id>/approve/`
- `GET /api/admin-panel/orders/`
- `GET /api/admin-panel/payments/`
- `GET /api/admin-panel/reports/`
- `GET /api/admin-panel/complaints/`
- `POST /api/admin-panel/complaints/<id>/resolve/`

### Cross-cutting
- `GET /api/core/notifications/`
- `POST /api/core/notifications/read/`
- `POST /api/core/complaints/`
- `POST /api/core/payments/`
- `GET /api/core/reviews/<supplier_id>/`

## Tech

- Django 4.2 + DRF 3.14 + SimpleJWT
- SQLite (`db.sqlite3`) — perfect for MCA mini project
- CORS configured for the Next.js dev server at `http://localhost:3000`
