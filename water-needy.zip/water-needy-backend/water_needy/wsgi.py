"""WSGI config for water_needy project."""
import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'water_needy.settings')
application = get_wsgi_application()
