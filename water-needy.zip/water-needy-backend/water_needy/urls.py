"""
Root URL configuration for the Water-Needy project.

Routes every app's endpoints under /api/.
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    # Django admin
    path('admin/', admin.site.urls),

    # Auth endpoints (JWT obtain + refresh)
    path('api/auth/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/auth/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # App routers
    path('api/accounts/', include('apps.accounts.urls')),
    path('api/consumer/', include('apps.consumer.urls')),
    path('api/supplier/', include('apps.supplier.urls')),
    path('api/driver/', include('apps.driver.urls')),
    path('api/admin-panel/', include('apps.admin_panel.urls')),
    path('api/core/', include('apps.core.urls')),
]

# Serve media in DEBUG
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
