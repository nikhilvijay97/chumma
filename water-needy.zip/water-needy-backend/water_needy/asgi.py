"""ASGI config for water_needy project."""
import os
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'water_needy.settings')
application = get_asgi_application()
