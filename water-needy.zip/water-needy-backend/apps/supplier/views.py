"""Supplier endpoints: inventory CRUD, order approval, driver assignment."""
from django.db.models import Sum
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.models import DriverProfile
from apps.core.models import Notification, WaterRequest

from .models import WaterInventory
from .serializers import AssignDriverSerializer, SupplierOrderSerializer, WaterInventorySerializer


class IsSupplier(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.role == 'supplier')


class SupplierDashboardView(APIView):
    permission_classes = [IsSupplier]

    def get(self, request):
        inv = WaterInventory.objects.filter(supplier=request.user)
        orders = WaterRequest.objects.filter(supplier=request.user)
        revenue = orders.filter(status='delivered').aggregate(
            total=Sum('total_amount')
        )['total'] or 0
        return Response({
            'inventory_count': inv.count(),
            'active_orders': orders.exclude(status__in=['delivered', 'cancelled']).count(),
            'revenue': float(revenue),
        })


class InventoryListCreateView(generics.ListCreateAPIView):
    serializer_class = WaterInventorySerializer
    permission_classes = [IsSupplier]

    def get_queryset(self):
        return WaterInventory.objects.filter(supplier=self.request.user)

    def perform_create(self, serializer):
        serializer.save(supplier=self.request.user)


class InventoryDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = WaterInventorySerializer
    permission_classes = [IsSupplier]

    def get_queryset(self):
        return WaterInventory.objects.filter(supplier=self.request.user)


class SupplierOrdersView(generics.ListAPIView):
    """GET all orders for this supplier."""
    serializer_class = SupplierOrderSerializer
    permission_classes = [IsSupplier]

    def get_queryset(self):
        return WaterRequest.objects.filter(supplier=self.request.user).order_by('-created_at')


class ApproveOrderView(APIView):
    permission_classes = [IsSupplier]

    def post(self, request, pk):
        try:
            order = WaterRequest.objects.get(pk=pk, supplier=request.user)
        except WaterRequest.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)
        order.status = 'approved'
        order.save()
        Notification.objects.create(
            user=order.consumer,
            title='Order approved',
            message=f'Your water request #{order.id} has been approved.',
            kind='order',
        )
        return Response({'detail': 'Order approved.', 'status': order.status})


class RejectOrderView(APIView):
    permission_classes = [IsSupplier]

    def post(self, request, pk):
        try:
            order = WaterRequest.objects.get(pk=pk, supplier=request.user)
        except WaterRequest.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)
        order.status = 'cancelled'
        order.save()
        Notification.objects.create(
            user=order.consumer,
            title='Order rejected',
            message=f'Your water request #{order.id} was rejected.',
            kind='order',
        )
        return Response({'detail': 'Order rejected.'})


class AssignDriverView(APIView):
    permission_classes = [IsSupplier]

    def post(self, request, pk):
        serializer = AssignDriverSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            order = WaterRequest.objects.get(pk=pk, supplier=request.user)
        except WaterRequest.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)
        order.driver_id = serializer.validated_data['driver_id']
        order.status = 'assigned'
        order.save()

        driver_profile = DriverProfile.objects.get(user_id=serializer.validated_data['driver_id'])
        driver_profile.is_available = False
        driver_profile.save()

        Notification.objects.create(
            user_id=serializer.validated_data['driver_id'],
            title='New delivery assigned',
            message=f'You have been assigned order #{order.id}.',
            kind='order',
        )
        return Response({'detail': 'Driver assigned.', 'status': order.status})


class AvailableDriversView(APIView):
    permission_classes = [IsSupplier]

    def get(self, request):
        drivers = DriverProfile.objects.filter(is_approved=True, is_available=True)
        data = [{
            'id': d.user_id,
            'full_name': d.full_name,
            'vehicle_number': d.vehicle_number,
            'vehicle_type': d.vehicle_type,
            'city': d.city,
        } for d in drivers]
        return Response(data)


class SupplierReviewsView(APIView):
    permission_classes = [IsSupplier]

    def get(self, request):
        from apps.core.models import Review
        reviews = Review.objects.filter(supplier=request.user).order_by('-created_at')
        from apps.core.serializers import ReviewReadSerializer
        return Response(ReviewReadSerializer(reviews, many=True).data)
