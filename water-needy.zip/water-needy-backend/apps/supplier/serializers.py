"""Serializers for supplier inventory and order approval."""
from rest_framework import serializers

from apps.accounts.models import DriverProfile
from apps.core.models import WaterRequest

from .models import WaterInventory


class WaterInventorySerializer(serializers.ModelSerializer):
    class Meta:
        model = WaterInventory
        fields = [
            'id', 'water_type', 'description', 'price_per_litre',
            'available_litres', 'image', 'is_active',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['created_at', 'updated_at']


class SupplierOrderSerializer(serializers.ModelSerializer):
    """Orders received by this supplier with consumer + inventory snippets."""
    consumer_name = serializers.CharField(source='consumer.username', read_only=True)
    inventory_detail = WaterInventorySerializer(source='inventory', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = WaterRequest
        fields = [
            'id', 'consumer_name', 'inventory', 'inventory_detail',
            'water_type', 'quantity_litres', 'delivery_address',
            'preferred_date', 'status', 'status_display',
            'total_amount', 'driver', 'created_at',
        ]


class AssignDriverSerializer(serializers.Serializer):
    driver_id = serializers.IntegerField()

    def validate_driver_id(self, value):
        try:
            driver = DriverProfile.objects.get(user_id=value, is_approved=True, is_available=True)
        except DriverProfile.DoesNotExist:
            raise serializers.ValidationError("Driver not available.")
        return value
