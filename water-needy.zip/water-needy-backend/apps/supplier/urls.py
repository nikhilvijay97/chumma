from django.urls import path
from .views import (
    ApproveOrderView,
    AssignDriverView,
    AvailableDriversView,
    InventoryDetailView,
    InventoryListCreateView,
    RejectOrderView,
    SupplierDashboardView,
    SupplierOrdersView,
    SupplierReviewsView,
)

urlpatterns = [
    path('dashboard/', SupplierDashboardView.as_view(), name='supplier_dashboard'),
    path('inventory/', InventoryListCreateView.as_view(), name='inventory_list_create'),
    path('inventory/<int:pk>/', InventoryDetailView.as_view(), name='inventory_detail'),
    path('orders/', SupplierOrdersView.as_view(), name='supplier_orders'),
    path('orders/<int:pk>/approve/', ApproveOrderView.as_view(), name='supplier_approve'),
    path('orders/<int:pk>/reject/', RejectOrderView.as_view(), name='supplier_reject'),
    path('orders/<int:pk>/assign-driver/', AssignDriverView.as_view(), name='supplier_assign_driver'),
    path('drivers/available/', AvailableDriversView.as_view(), name='supplier_drivers'),
    path('reviews/', SupplierReviewsView.as_view(), name='supplier_reviews'),
]
