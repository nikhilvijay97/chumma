"""Supplier-side models: water inventory that consumers can order from."""
from django.conf import settings
from django.db import models


class WaterInventory(models.Model):
    """A SKU of water offered by a supplier (mineral, RO, tanker, etc.)."""
    WATER_TYPES = (
        ('mineral', 'Mineral Water'),
        ('ro', 'RO Purified'),
        ('tanker', 'Tanker (Bulk)'),
        ('distilled', 'Distilled'),
    )
    supplier = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='inventory_items')
    water_type = models.CharField(max_length=20, choices=WATER_TYPES)
    description = models.CharField(max_length=200, blank=True)
    price_per_litre = models.DecimalField(max_digits=8, decimal_places=2)
    available_litres = models.PositiveIntegerField(default=0)
    image = models.ImageField(upload_to='inventory/', blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.water_type} — {self.supplier.username} ({self.available_litres}L @ ₹{self.price_per_litre})"
