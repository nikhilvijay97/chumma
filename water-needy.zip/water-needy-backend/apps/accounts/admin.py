from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import ConsumerProfile, DriverProfile, SupplierProfile, User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'role', 'is_verified', 'is_staff')
    list_filter = ('role', 'is_verified', 'is_staff')
    fieldsets = UserAdmin.fieldsets + (
        ('Water-Needy Info', {'fields': ('role', 'phone', 'address', 'profile_picture', 'is_verified')}),
    )


admin.site.register(ConsumerProfile)
admin.site.register(SupplierProfile)
admin.site.register(DriverProfile)
