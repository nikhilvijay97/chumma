"""
Custom User model for Water-Needy.

Extends AbstractUser to add a `role` field (RBAC) and a phone number.
Roles: consumer, supplier, driver, admin.
"""

from django.contrib.auth.models import AbstractUser
from django.db import models


class Role(models.TextChoices):
    CONSUMER = 'consumer', 'Consumer'
    SUPPLIER = 'supplier', 'Supplier'
    DRIVER = 'driver', 'Driver'
    ADMIN = 'admin', 'Admin'


class User(AbstractUser):
    """Single auth account for every role in the platform."""
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.CONSUMER)
    phone = models.CharField(max_length=15, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    profile_picture = models.ImageField(upload_to='profiles/', blank=True, null=True)
    is_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'

    def __str__(self):
        return f"{self.username} ({self.role})"


class ConsumerProfile(models.Model):
    """Profile details for a consumer user."""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='consumer_profile')
    full_name = models.CharField(max_length=100, blank=True)
    city = models.CharField(max_length=80, blank=True)
    pincode = models.CharField(max_length=10, blank=True)
    default_address = models.TextField(blank=True)

    def __str__(self):
        return f"Consumer: {self.user.username}"


class SupplierProfile(models.Model):
    """Business information for a water supplier."""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='supplier_profile')
    business_name = models.CharField(max_length=150)
    license_number = models.CharField(max_length=80, blank=True)
    business_document = models.FileField(upload_to='supplier_docs/', blank=True, null=True)
    city = models.CharField(max_length=80)
    pincode = models.CharField(max_length=10)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    description = models.TextField(blank=True)
    is_approved = models.BooleanField(default=False)

    def __str__(self):
        return f"Supplier: {self.business_name}"


class DriverProfile(models.Model):
    """Vehicle + verification details for a driver."""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='driver_profile')
    full_name = models.CharField(max_length=100)
    license_number = models.CharField(max_length=80)
    vehicle_number = models.CharField(max_length=20)
    vehicle_type = models.CharField(max_length=40, default='Tanker')
    city = models.CharField(max_length=80, blank=True)
    is_approved = models.BooleanField(default=False)
    is_available = models.BooleanField(default=True)

    def __str__(self):
        return f"Driver: {self.full_name} ({self.vehicle_number})"
