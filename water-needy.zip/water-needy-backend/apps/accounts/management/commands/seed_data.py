"""Django management command to populate the database with sample data.

Usage:  python manage.py seed_data
"""
import random
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils import timezone

from apps.core.models import Notification, Payment, Review, WaterRequest
from apps.supplier.models import WaterInventory

User = get_user_model()

CONSUMERS = [
    ('alice', 'alice@example.com', 'Alice Sharma'),
    ('bob', 'bob@example.com', 'Bob Verma'),
    ('carol', 'carol@example.com', 'Carol Iyer'),
]
SUPPLIERS = [
    ('aquapure', 'aquapure@example.com', 'AquaPure Industries', 'Mumbai', '400001'),
    ('hydroflow', 'hydroflow@example.com', 'HydroFlow Bottles', 'Pune', '411001'),
    ('clearwater', 'clearwater@example.com', 'ClearWater Co.', 'Delhi', '110001'),
]
DRIVERS = [
    ('dravi', 'dravi@example.com', 'Ravi Kumar', 'MH-12-AB-1234', 'Tanker'),
    ('drajay', 'drajay@example.com', 'Ajay Singh', 'DL-05-CD-5678', 'Mini-Truck'),
]


class Command(BaseCommand):
    help = 'Populate database with sample Water-Needy data.'

    def handle(self, *args, **kwargs):
        self.stdout.write('Seeding…')

        # Admin
        admin, _ = User.objects.get_or_create(
            username='admin', defaults={
                'email': 'admin@waterneedy.com',
                'role': 'admin',
                'is_staff': True,
                'is_superuser': True,
                'is_verified': True,
            },
        )
        admin.set_password('admin123')
        admin.save()

        for uname, email, name in CONSUMERS:
            user, _ = User.objects.get_or_create(username=uname, defaults={
                'email': email, 'role': 'consumer', 'is_verified': True
            })
            user.set_password('consumer123')
            user.save()
            # Profile
            from apps.accounts.models import ConsumerProfile
            ConsumerProfile.objects.update_or_create(
                user=user, defaults={'full_name': name, 'city': 'Mumbai', 'pincode': '400001'}
            )

        for uname, email, biz, city, pin in SUPPLIERS:
            user, _ = User.objects.get_or_create(username=uname, defaults={
                'email': email, 'role': 'supplier', 'is_verified': True
            })
            user.set_password('supplier123')
            user.save()
            from apps.accounts.models import SupplierProfile
            sp, _ = SupplierProfile.objects.update_or_create(
                user=user, defaults={
                    'business_name': biz, 'city': city, 'pincode': pin,
                    'license_number': f'LIC-{random.randint(1000, 9999)}',
                    'description': f'Premium drinking water supplier in {city}.',
                    'is_approved': True,
                    'latitude': 19.076 + random.random(),
                    'longitude': 72.8777 + random.random(),
                }
            )
            # Seed inventory
            for wtype, price in [('mineral', 30.00), ('ro', 35.00), ('tanker', 18.00)]:
                WaterInventory.objects.get_or_create(
                    supplier=user, water_type=wtype, defaults={
                        'description': f'{wtype.title()} water from {biz}',
                        'price_per_litre': price,
                        'available_litres': random.randint(500, 5000),
                        'is_active': True,
                    }
                )

        for uname, email, name, vnum, vtype in DRIVERS:
            user, _ = User.objects.get_or_create(username=uname, defaults={
                'email': email, 'role': 'driver', 'is_verified': True
            })
            user.set_password('driver123')
            user.save()
            from apps.accounts.models import DriverProfile
            DriverProfile.objects.update_or_create(
                user=user, defaults={
                    'full_name': name, 'license_number': f'LIC-{uname.upper()}',
                    'vehicle_number': vnum, 'vehicle_type': vtype,
                    'city': 'Mumbai', 'is_approved': True, 'is_available': True,
                }
            )

        # Sample orders + notifications
        consumer = User.objects.get(username='alice')
        supplier = User.objects.get(username='aquapure')
        inv = WaterInventory.objects.filter(supplier=supplier, water_type='mineral').first()
        if inv:
            for i in range(3):
                wr = WaterRequest.objects.create(
                    consumer=consumer, supplier=supplier, inventory=inv,
                    water_type='mineral', quantity_litres=random.choice([20, 50, 100]),
                    delivery_address=f'#{i+1}, Marine Drive, Mumbai',
                    preferred_date=timezone.now().date() + timedelta(days=i),
                    status=random.choice(['pending', 'approved', 'delivered']),
                    total_amount=inv.price_per_litre * 20,
                )
                Notification.objects.create(
                    user=consumer,
                    title=f'Order #{wr.id}',
                    message=f'Water order placed: {wr.quantity_litres}L of {wr.water_type}.',
                    kind='order',
                )
                if wr.status == 'delivered':
                    Payment.objects.create(
                        order=wr, amount=wr.total_amount, method='upi', status='success',
                        transaction_ref=f'TX{wr.id:04d}',
                    )

        self.stdout.write(self.style.SUCCESS('Sample data created.'))
        self.stdout.write('  Admin:      admin / admin123')
        self.stdout.write('  Consumer:   alice / consumer123  (bob, carol)')
        self.stdout.write('  Supplier:   aquapure / supplier123  (hydroflow, clearwater)')
        self.stdout.write('  Driver:     dravi / driver123  (drajay)')
