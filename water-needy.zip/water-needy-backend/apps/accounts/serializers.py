"""Serializers for registration, login, and profile endpoints."""
from django.contrib.auth import authenticate
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken

from .models import ConsumerProfile, DriverProfile, SupplierProfile, User


class ConsumerProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = ConsumerProfile
        fields = ['full_name', 'city', 'pincode', 'default_address']


class SupplierProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupplierProfile
        fields = [
            'business_name', 'license_number', 'business_document',
            'city', 'pincode', 'latitude', 'longitude',
            'description', 'is_approved',
        ]


class DriverProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = DriverProfile
        fields = [
            'full_name', 'license_number', 'vehicle_number',
            'vehicle_type', 'city', 'is_approved', 'is_available',
        ]


class UserSerializer(serializers.ModelSerializer):
    """Safe user representation (no password leakage)."""
    consumer_profile = ConsumerProfileSerializer(read_only=True)
    supplier_profile = SupplierProfileSerializer(read_only=True)
    driver_profile = DriverProfileSerializer(read_only=True)

    class Meta:
        model = User
        fields = [
            'id', 'username', 'email', 'role', 'phone', 'address',
            'profile_picture', 'is_verified', 'created_at',
            'consumer_profile', 'supplier_profile', 'driver_profile',
        ]
        read_only_fields = ['id', 'is_verified', 'created_at']


class RegisterSerializer(serializers.ModelSerializer):
    """Generic registration based on `role`."""
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    password2 = serializers.CharField(write_only=True, required=True)
    # Role-specific fields (optional at register time)
    full_name = serializers.CharField(required=False, allow_blank=True)
    city = serializers.CharField(required=False, allow_blank=True)
    pincode = serializers.CharField(required=False, allow_blank=True)
    business_name = serializers.CharField(required=False, allow_blank=True)
    license_number = serializers.CharField(required=False, allow_blank=True)
    vehicle_number = serializers.CharField(required=False, allow_blank=True)

    class Meta:
        model = User
        fields = [
            'username', 'email', 'password', 'password2',
            'role', 'phone', 'address',
            'full_name', 'city', 'pincode',
            'business_name', 'license_number', 'vehicle_number',
        ]

    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password2": "Passwords do not match."})
        if User.objects.filter(username=attrs['username']).exists():
            raise serializers.ValidationError({"username": "Username already taken."})
        if User.objects.filter(email=attrs['email']).exists():
            raise serializers.ValidationError({"email": "Email already registered."})
        return attrs

    def create(self, validated_data):
        validated_data.pop('password2')
        role = validated_data.pop('role', 'consumer')
        extras = {k: validated_data.pop(k, '') for k in (
            'full_name', 'city', 'pincode',
            'business_name', 'license_number', 'vehicle_number',
        )}

        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            role=role,
            phone=validated_data.get('phone', ''),
            address=validated_data.get('address', ''),
        )

        if role == 'consumer':
            ConsumerProfile.objects.create(
                user=user,
                full_name=extras.get('full_name', ''),
                city=extras.get('city', ''),
                pincode=extras.get('pincode', ''),
            )
        elif role == 'supplier':
            SupplierProfile.objects.create(
                user=user,
                business_name=extras.get('business_name') or user.username,
                license_number=extras.get('license_number', ''),
                city=extras.get('city', ''),
                pincode=extras.get('pincode', ''),
            )
        elif role == 'driver':
            DriverProfile.objects.create(
                user=user,
                full_name=extras.get('full_name', ''),
                license_number=extras.get('license_number', ''),
                vehicle_number=extras.get('vehicle_number', ''),
            )
        return user


class LoginSerializer(serializers.Serializer):
    """Authenticate by username + password and return JWT + user data."""
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        user = authenticate(username=attrs['username'], password=attrs['password'])
        if not user:
            raise serializers.ValidationError({"detail": "Invalid credentials."})
        if not user.is_active:
            raise serializers.ValidationError({"detail": "Account disabled."})

        refresh = RefreshToken.for_user(user)
        refresh['role'] = user.role
        refresh['username'] = user.username

        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token),
            'user': UserSerializer(user).data,
        }


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(write_only=True)
    new_password = serializers.CharField(write_only=True, validators=[validate_password])

    def validate_old(self, attrs):
        user = self.context['request'].user
        if not user.check_password(attrs['old_password']):
            raise serializers.ValidationError({"old_password": "Wrong password."})
        return attrs

    def save(self, **kwargs):
        user = self.context['request'].user
        user.set_password(self.validated_data['new_password'])
        user.save()
        return user


class ForgotPasswordSerializer(serializers.Serializer):
    """Simplified forgot-password: looks up the user and lets them set a new password.

    (In a real production system this would email a token; for the mini project
    we expose a verify + reset endpoint pair based on username + email.)
    """
    username = serializers.CharField()
    email = serializers.EmailField()
    new_password = serializers.CharField(write_only=True, validators=[validate_password])

    def validate(self, attrs):
        try:
            user = User.objects.get(username=attrs['username'], email=attrs['email'])
        except User.DoesNotExist:
            raise serializers.ValidationError({"detail": "No matching account."})
        user.set_password(attrs['new_password'])
        user.save()
        return attrs


class ProfileUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['email', 'phone', 'address', 'profile_picture']
