"""Driver endpoints: assigned deliveries, status updates, earnings."""
from django.db.models import Sum
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.models import DriverProfile
from apps.core.models import Notification, WaterRequest

from .serializers import DriverOrderSerializer


class IsDriver(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.role == 'driver')


class DriverDashboardView(APIView):
    permission_classes = [IsDriver]

    def get(self, request):
        qs = WaterRequest.objects.filter(driver=request.user)
        earnings = qs.filter(status='delivered').aggregate(total=Sum('total_amount'))['total'] or 0
        return Response({
            'assigned_deliveries': qs.exclude(status__in=['delivered', 'cancelled']).count(),
            'completed_deliveries': qs.filter(status='delivered').count(),
            'earnings': float(earnings),
        })


class AssignedDeliveriesView(generics.ListAPIView):
    serializer_class = DriverOrderSerializer
    permission_classes = [IsDriver]

    def get_queryset(self):
        return WaterRequest.objects.filter(driver=self.request.user).order_by('-created_at')


class DeliveryDetailView(generics.RetrieveAPIView):
    serializer_class = DriverOrderSerializer
    permission_classes = [IsDriver]

    def get_queryset(self):
        return WaterRequest.objects.filter(driver=self.request.user)


class UpdateDeliveryStatusView(APIView):
    """POST /api/driver/orders/<id>/status/ with body {status: 'picked_up' | ...}"""
    permission_classes = [IsDriver]

    ALLOWED = ('assigned', 'picked_up', 'on_the_way', 'delivered')

    def post(self, request, pk):
        new_status = request.data.get('status')
        if new_status not in self.ALLOWED:
            return Response({'detail': 'Invalid status.'}, status=400)
        try:
            order = WaterRequest.objects.get(pk=pk, driver=request.user)
        except WaterRequest.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)

        order.status = new_status
        order.save()

        # On delivery: free up the driver & notify consumer/supplier.
        if new_status == 'delivered':
            dp = DriverProfile.objects.get(user=request.user)
            dp.is_available = True
            dp.save()
            Notification.objects.create(
                user=order.consumer,
                title='Order delivered',
                message=f'Your water request #{order.id} has been delivered.',
                kind='order',
            )

        return Response({'detail': 'Status updated.', 'status': order.status})


class DeliveryHistoryView(APIView):
    permission_classes = [IsDriver]

    def get(self, request):
        qs = WaterRequest.objects.filter(driver=request.user, status='delivered').order_by('-created_at')
        return Response(DriverOrderSerializer(qs, many=True).data)
