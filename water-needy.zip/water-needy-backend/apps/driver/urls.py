from django.urls import path
from .views import (
    AssignedDeliveriesView,
    DeliveryDetailView,
    DeliveryHistoryView,
    DriverDashboardView,
    UpdateDeliveryStatusView,
)

urlpatterns = [
    path('dashboard/', DriverDashboardView.as_view(), name='driver_dashboard'),
    path('orders/', AssignedDeliveriesView.as_view(), name='driver_orders'),
    path('orders/history/', DeliveryHistoryView.as_view(), name='driver_history'),
    path('orders/<int:pk>/', DeliveryDetailView.as_view(), name='driver_order_detail'),
    path('orders/<int:pk>/status/', UpdateDeliveryStatusView.as_view(), name='driver_status_update'),
]
