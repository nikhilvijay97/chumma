"""Driver-specific models (none currently — driver state is held in core)."""
