from rest_framework import serializers
from apps.core.models import WaterRequest


class DriverOrderSerializer(serializers.ModelSerializer):
    consumer_name = serializers.CharField(source='consumer.username', read_only=True)
    supplier_name = serializers.CharField(source='supplier.business_name', read_only=True)

    class Meta:
        model = WaterRequest
        fields = [
            'id', 'consumer_name', 'supplier_name',
            'water_type', 'quantity_litres', 'delivery_address',
            'preferred_date', 'status', 'total_amount', 'created_at',
        ]
