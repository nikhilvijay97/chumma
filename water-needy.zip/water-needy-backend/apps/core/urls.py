from django.urls import path
from .views import (
    ComplaintCreateView,
    MarkNotificationsReadView,
    NotificationListView,
    PaymentCreateView,
    SupplierReviewsListView,
)

urlpatterns = [
    path('notifications/', NotificationListView.as_view(), name='notifications'),
    path('notifications/read/', MarkNotificationsReadView.as_view(), name='notifications_read'),
    path('complaints/', ComplaintCreateView.as_view(), name='complaints_create'),
    path('payments/', PaymentCreateView.as_view(), name='payments_create'),
    path('reviews/<int:supplier_id>/', SupplierReviewsListView.as_view(), name='supplier_reviews'),
]
