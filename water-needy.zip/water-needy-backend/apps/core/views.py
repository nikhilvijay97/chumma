"""Cross-cutting endpoints: notifications, complaints, payments, reviews."""
from django.db.models import Q
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Complaint, Notification, Payment, Review
from .serializers import (
    ComplaintSerializer,
    NotificationSerializer,
    PaymentSerializer,
    ReviewReadSerializer,
)


class NotificationListView(generics.ListAPIView):
    serializer_class = NotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user).order_by('-created_at')


class MarkNotificationsReadView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        ids = request.data.get('ids')
        if ids:
            Notification.objects.filter(user=request.user, id__in=ids).update(is_read=True)
        else:
            Notification.objects.filter(user=request.user).update(is_read=True)
        return Response({'detail': 'Marked as read.'})


class ComplaintCreateView(generics.CreateAPIView):
    serializer_class = ComplaintSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class PaymentCreateView(generics.CreateAPIView):
    """Simulated payment: marks a COD/UPI/etc. order as either success or pending."""
    serializer_class = PaymentSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        payment = serializer.save()
        # Simulate gateway response
        if payment.method != 'cod':
            payment.status = 'success'
            payment.transaction_ref = f"TX{payment.id:06d}"
            payment.save()
        # Mirror to consumer notification
        from .models import Notification
        Notification.objects.create(
            user=self.request.user,
            title='Payment recorded',
            message=f'Payment ₹{payment.amount} for order #{payment.order_id} recorded.',
            kind='order',
        )


class SupplierReviewsListView(APIView):
    """Public reviews for a given supplier."""
    permission_classes = [permissions.AllowAny]

    def get(self, request, supplier_id):
        qs = Review.objects.filter(supplier_id=supplier_id).order_by('-created_at')
        return Response(ReviewReadSerializer(qs, many=True).data)
