"""Serializers for cross-cutting entities (notifications, complaints, payments, reviews)."""
from rest_framework import serializers

from .models import Complaint, Notification, Payment, Review


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ['id', 'title', 'message', 'kind', 'is_read', 'created_at']


class MarkReadSerializer(serializers.Serializer):
    ids = serializers.ListField(child=serializers.IntegerField(), required=False)


class ComplaintSerializer(serializers.ModelSerializer):
    class Meta:
        model = Complaint
        fields = ['id', 'subject', 'message', 'related_order', 'status', 'created_at']
        read_only_fields = ['status', 'created_at']


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = ['id', 'order', 'amount', 'method', 'status', 'transaction_ref', 'created_at']
        read_only_fields = ['status', 'transaction_ref', 'created_at']


class ReviewReadSerializer(serializers.ModelSerializer):
    consumer_name = serializers.CharField(source='consumer.username', read_only=True)

    class Meta:
        model = Review
        fields = ['id', 'consumer_name', 'rating', 'comment', 'created_at']
