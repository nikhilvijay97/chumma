"""Cross-cutting models shared by every user role.

These entities span multiple roles:
    * WaterRequest — created by consumer, owned by supplier, executed by driver
    * Payment     — generated alongside a request
    * Review      — consumer rates supplier after a delivery
    * Notification — in-app alert for any user
    * Complaint   — any user reports an issue to admin
"""
from django.conf import settings
from django.db import models


class WaterRequest(models.Model):
    """Central ordering entity (referred to as 'order' in the UI)."""
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('assigned', 'Driver Assigned'),
        ('picked_up', 'Picked Up'),
        ('on_the_way', 'On the Way'),
        ('delivered', 'Delivered'),
        ('cancelled', 'Cancelled'),
    )
    consumer = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='orders_placed',
    )
    supplier = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='orders_received',
    )
    inventory = models.ForeignKey(
        'supplier.WaterInventory', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='orders',
    )
    driver = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='orders_delivering',
    )
    water_type = models.CharField(max_length=20)
    quantity_litres = models.PositiveIntegerField()
    delivery_address = models.TextField()
    preferred_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Order #{self.id} — {self.status}"


class Payment(models.Model):
    METHOD_CHOICES = (
        ('cod', 'Cash on Delivery'),
        ('upi', 'UPI'),
        ('card', 'Credit/Debit Card'),
        ('netbank', 'Net Banking'),
    )
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('success', 'Successful'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
    )
    order = models.OneToOneField(WaterRequest, on_delete=models.CASCADE, related_name='payment')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    method = models.CharField(max_length=20, choices=METHOD_CHOICES, default='cod')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    transaction_ref = models.CharField(max_length=80, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Payment #{self.id} — {self.status}"


class Review(models.Model):
    supplier = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reviews_received'
    )
    consumer = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reviews_given'
    )
    rating = models.IntegerField()  # 1–5
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        unique_together = (('supplier', 'consumer'),)  # one per pair

    def __str__(self):
        return f"{self.rating}★ for {self.supplier.username}"


class Notification(models.Model):
    KIND_CHOICES = (
        ('order', 'Order Update'),
        ('system', 'System'),
        ('promo', 'Promotion'),
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications'
    )
    title = models.CharField(max_length=120)
    message = models.TextField()
    kind = models.CharField(max_length=20, choices=KIND_CHOICES, default='system')
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Notification: {self.title}"


class Complaint(models.Model):
    STATUS_CHOICES = (
        ('open', 'Open'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved'),
        ('rejected', 'Rejected'),
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='complaints',
    )
    subject = models.CharField(max_length=200)
    message = models.TextField()
    related_order = models.ForeignKey(
        WaterRequest, on_delete=models.SET_NULL, null=True, blank=True, related_name='complaints'
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Complaint: {self.subject}"
