"""Serializers for consumer-side endpoints.

WaterRequest is the central ordering entity shared across roles.
"""
from rest_framework import serializers

from apps.core.models import Review, WaterRequest
from apps.supplier.models import WaterInventory


class WaterInventoryMiniSerializer(serializers.ModelSerializer):
    class Meta:
        model = WaterInventory
        fields = ['id', 'water_type', 'price_per_litre', 'available_litres']


class WaterRequestSerializer(serializers.ModelSerializer):
    """Read serializer — includes nested consumer & supplier info."""
    consumer_name = serializers.CharField(source='consumer.username', read_only=True)
    supplier_name = serializers.CharField(source='supplier.business_name', read_only=True)
    inventory_detail = WaterInventoryMiniSerializer(source='inventory', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = WaterRequest
        fields = [
            'id', 'consumer', 'consumer_name', 'supplier', 'supplier_name',
            'inventory', 'inventory_detail',
            'water_type', 'quantity_litres',
            'delivery_address', 'preferred_date',
            'status', 'status_display',
            'total_amount', 'driver',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['consumer', 'status', 'supplier', 'driver', 'total_amount', 'created_at', 'updated_at']


class WaterRequestCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = WaterRequest
        fields = [
            'inventory', 'water_type', 'quantity_litres',
            'delivery_address', 'preferred_date',
        ]

    def validate(self, attrs):
        inv = attrs['inventory']
        if attrs['quantity_litres'] > inv.available_litres:
            raise serializers.ValidationError({"quantity_litres": "Requested quantity exceeds supplier stock."})
        return attrs

    def create(self, validated_data):
        request = self.context['request']
        inv = validated_data['inventory']
        validated_data['consumer'] = request.user
        validated_data['supplier'] = inv.supplier
        validated_data['total_amount'] = inv.price_per_litre * validated_data['quantity_litres']
        validated_data['status'] = 'pending'
        return super().create(validated_data)


class ReviewSerializer(serializers.ModelSerializer):
    consumer_name = serializers.CharField(source='consumer.username', read_only=True)

    class Meta:
        model = Review
        fields = ['id', 'supplier', 'consumer_name', 'rating', 'comment', 'created_at']
        read_only_fields = ['consumer_name']
