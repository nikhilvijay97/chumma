from django.urls import path
from .views import (
    AddReviewView,
    CancelOrderView,
    ConsumerDashboardView,
    MyOrdersView,
    NearbySuppliersView,
    OrderDetailView,
    WaterRequestCreateView,
)

urlpatterns = [
    path('dashboard/', ConsumerDashboardView.as_view(), name='consumer_dashboard'),
    path('orders/', MyOrdersView.as_view(), name='consumer_orders'),
    path('orders/create/', WaterRequestCreateView.as_view(), name='consumer_order_create'),
    path('orders/<int:pk>/', OrderDetailView.as_view(), name='consumer_order_detail'),
    path('orders/<int:pk>/cancel/', CancelOrderView.as_view(), name='consumer_order_cancel'),
    path('suppliers/nearby/', NearbySuppliersView.as_view(), name='nearby_suppliers'),
    path('reviews/', AddReviewView.as_view(), name='consumer_reviews'),
]
