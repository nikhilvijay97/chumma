"""Consumer-facing endpoints: search suppliers, request water, view history,
cancel orders, submit reviews."""
from django.db.models import Q
from rest_framework import generics, permissions, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.core.models import Notification, Review, WaterRequest

from .serializers import ReviewSerializer, WaterRequestCreateSerializer, WaterRequestSerializer


class IsConsumer(permissions.BasePermission):
    """Simple RBAC guard."""
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.role == 'consumer')


class ConsumerDashboardView(APIView):
    permission_classes = [IsConsumer]

    def get(self, request):
        qs = WaterRequest.objects.filter(consumer=request.user)
        return Response({
            'total_orders': qs.count(),
            'pending_orders': qs.filter(status__in=['pending', 'approved', 'assigned', 'picked_up', 'on_the_way']).count(),
            'delivered_orders': qs.filter(status='delivered').count(),
        })


class WaterRequestCreateView(generics.CreateAPIView):
    """POST a new water request from the consumer."""
    serializer_class = WaterRequestCreateSerializer
    permission_classes = [IsConsumer]

    def perform_create(self, serializer):
        wr = serializer.save()
        # Notify supplier
        Notification.objects.create(
            user=wr.supplier.user,
            title='New water request',
            message=f'{wr.consumer.username} requested {wr.quantity_litres}L of {wr.water_type}.',
            kind='order',
        )


class MyOrdersView(generics.ListAPIView):
    """GET all orders belonging to the logged-in consumer."""
    serializer_class = WaterRequestSerializer
    permission_classes = [IsConsumer]

    def get_queryset(self):
        return WaterRequest.objects.filter(consumer=self.request.user).order_by('-created_at')


class OrderDetailView(generics.RetrieveAPIView):
    serializer_class = WaterRequestSerializer
    permission_classes = [IsConsumer]

    def get_queryset(self):
        return WaterRequest.objects.filter(consumer=self.request.user)


class CancelOrderView(APIView):
    permission_classes = [IsConsumer]

    def post(self, request, pk):
        try:
            order = WaterRequest.objects.get(pk=pk, consumer=request.user)
        except WaterRequest.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=status.HTTP_404_NOT_FOUND)
        if order.status not in ('pending',):
            return Response({'detail': 'Only pending orders can be cancelled.'}, status=400)
        order.status = 'cancelled'
        order.save()
        return Response({'detail': 'Order cancelled.', 'status': order.status})


class NearbySuppliersView(APIView):
    """Search suppliers by city / pincode (simple text-based 'nearby' lookup)."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        from apps.accounts.models import SupplierProfile
        qs = SupplierProfile.objects.filter(is_approved=True)
        city = request.query_params.get('city')
        pincode = request.query_params.get('pincode')
        q = request.query_params.get('q')

        if city:
            qs = qs.filter(Q(city__iexact=city) | Q(pincode__iexact=city))
        if pincode:
            qs = qs.filter(pincode__iexact=pincode)
        if q:
            qs = qs.filter(Q(business_name__icontains=q) | Q(city__icontains=q))

        data = [{
            'id': s.user_id,
            'business_name': s.business_name,
            'city': s.city,
            'pincode': s.pincode,
            'description': s.description,
        } for s in qs]
        return Response(data)


class AddReviewView(generics.CreateAPIView):
    serializer_class = ReviewSerializer
    permission_classes = [IsConsumer]

    def perform_create(self, serializer):
        serializer.save(consumer=self.request.user)
