"""Consumer-specific models live in core.shared; this file is reserved for
future consumer-only entities (saved addresses, payment methods, etc.)."""
