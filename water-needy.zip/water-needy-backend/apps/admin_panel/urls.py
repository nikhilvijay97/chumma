from django.urls import path
from .views import (
    AdminDashboardView,
    AllOrdersView,
    ApproveDriverView,
    ApproveSupplierView,
    ComplaintsListView,
    DriverApprovalListView,
    PaymentsListView,
    ReportsView,
    ResolveComplaintView,
    SupplierApprovalListView,
    UserActivateView,
    UserListView,
)

urlpatterns = [
    path('dashboard/', AdminDashboardView.as_view(), name='admin_dashboard'),
    path('users/', UserListView.as_view(), name='admin_users'),
    path('users/<int:pk>/toggle/', UserActivateView.as_view(), name='admin_user_toggle'),
    path('suppliers/pending/', SupplierApprovalListView.as_view(), name='admin_supplier_pending'),
    path('suppliers/<int:pk>/approve/', ApproveSupplierView.as_view(), name='admin_supplier_approve'),
    path('drivers/pending/', DriverApprovalListView.as_view(), name='admin_driver_pending'),
    path('drivers/<int:pk>/approve/', ApproveDriverView.as_view(), name='admin_driver_approve'),
    path('orders/', AllOrdersView.as_view(), name='admin_orders'),
    path('payments/', PaymentsListView.as_view(), name='admin_payments'),
    path('reports/', ReportsView.as_view(), name='admin_reports'),
    path('complaints/', ComplaintsListView.as_view(), name='admin_complaints'),
    path('complaints/<int:pk>/resolve/', ResolveComplaintView.as_view(), name='admin_complaint_resolve'),
]
