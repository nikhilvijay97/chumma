"""Admin endpoints: dashboard stats, user management, approvals, orders, payments, reports."""
from django.contrib.auth import get_user_model
from django.db.models import Count, Sum
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.models import DriverProfile, SupplierProfile
from apps.core.models import Payment, WaterRequest

from .serializers import (
    AdminUserSerializer,
    DriverApprovalSerializer,
    SupplierApprovalSerializer,
)

User = get_user_model()


class IsAdmin(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.role == 'admin')


class AdminDashboardView(APIView):
    permission_classes = [IsAdmin]

    def get(self, request):
        total_revenue = WaterRequest.objects.filter(status='delivered').aggregate(
            total=Sum('total_amount')
        )['total'] or 0
        return Response({
            'total_users': User.objects.count(),
            'consumers': User.objects.filter(role='consumer').count(),
            'suppliers': User.objects.filter(role='supplier').count(),
            'drivers': User.objects.filter(role='driver').count(),
            'orders': WaterRequest.objects.count(),
            'revenue': float(total_revenue),
        })


class UserListView(generics.ListAPIView):
    serializer_class = AdminUserSerializer
    permission_classes = [IsAdmin]

    def get_queryset(self):
        qs = User.objects.all().order_by('-created_at')
        role = self.request.query_params.get('role')
        if role:
            qs = qs.filter(role=role)
        return qs


class UserActivateView(APIView):
    permission_classes = [IsAdmin]

    def post(self, request, pk):
        try:
            user = User.objects.get(pk=pk)
        except User.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)
        user.is_active = not user.is_active
        user.save()
        return Response({'is_active': user.is_active})


class SupplierApprovalListView(generics.ListAPIView):
    serializer_class = SupplierApprovalSerializer
    permission_classes = [IsAdmin]

    def get_queryset(self):
        return SupplierProfile.objects.filter(is_approved=False)


class ApproveSupplierView(APIView):
    permission_classes = [IsAdmin]

    def post(self, request, pk):
        try:
            sp = SupplierProfile.objects.get(pk=pk)
        except SupplierProfile.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)
        sp.is_approved = True
        sp.save()
        sp.user.is_verified = True
        sp.user.save()
        return Response({'detail': 'Supplier approved.'})


class DriverApprovalListView(generics.ListAPIView):
    serializer_class = DriverApprovalSerializer
    permission_classes = [IsAdmin]

    def get_queryset(self):
        return DriverProfile.objects.filter(is_approved=False)


class ApproveDriverView(APIView):
    permission_classes = [IsAdmin]

    def post(self, request, pk):
        try:
            dp = DriverProfile.objects.get(pk=pk)
        except DriverProfile.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)
        dp.is_approved = True
        dp.save()
        dp.user.is_verified = True
        dp.user.save()
        return Response({'detail': 'Driver approved.'})


class AllOrdersView(generics.ListAPIView):
    permission_classes = [IsAdmin]

    def get(self, request):
        qs = WaterRequest.objects.all().order_by('-created_at')[:200]
        data = [{
            'id': o.id,
            'consumer': o.consumer.username,
            'supplier': o.supplier.business_name if o.supplier else None,
            'driver': o.driver.username if o.driver else None,
            'water_type': o.water_type,
            'quantity_litres': o.quantity_litres,
            'total_amount': float(o.total_amount),
            'status': o.status,
            'created_at': o.created_at,
        } for o in qs]
        return Response(data)


class PaymentsListView(generics.ListAPIView):
    permission_classes = [IsAdmin]

    def get(self, request):
        qs = Payment.objects.all().order_by('-created_at')[:200]
        data = [{
            'id': p.id,
            'order_id': p.order_id,
            'amount': float(p.amount),
            'method': p.method,
            'status': p.status,
            'created_at': p.created_at,
        } for p in qs]
        return Response(data)


class ReportsView(APIView):
    permission_classes = [IsAdmin]

    def get(self, request):
        by_status = WaterRequest.objects.values('status').annotate(count=Count('id'))
        by_type = WaterRequest.objects.values('water_type').annotate(count=Count('id'))
        return Response({
            'by_status': list(by_status),
            'by_type': list(by_type),
        })


class ComplaintsListView(APIView):
    permission_classes = [IsAdmin]

    def get(self, request):
        from apps.core.models import Complaint
        qs = Complaint.objects.all().order_by('-created_at')[:200]
        return Response([{
            'id': c.id, 'user': c.user.username if c.user else None,
            'subject': c.subject, 'message': c.message,
            'status': c.status, 'created_at': c.created_at,
        } for c in qs])


class ResolveComplaintView(APIView):
    permission_classes = [IsAdmin]

    def post(self, request, pk):
        from apps.core.models import Complaint
        try:
            c = Complaint.objects.get(pk=pk)
        except Complaint.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)
        c.status = 'resolved'
        c.save()
        return Response({'detail': 'Complaint resolved.'})
