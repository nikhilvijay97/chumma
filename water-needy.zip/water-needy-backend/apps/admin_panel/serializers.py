from rest_framework import serializers
from apps.accounts.models import ConsumerProfile, DriverProfile, SupplierProfile, User


class AdminUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            'id', 'username', 'email', 'role', 'phone', 'address',
            'is_verified', 'is_active', 'created_at',
        ]
        read_only_fields = fields


class SupplierApprovalSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    email = serializers.CharField(source='user.email', read_only=True)

    class Meta:
        model = SupplierProfile
        fields = ['id', 'username', 'email', 'business_name', 'city', 'pincode',
                  'license_number', 'is_approved']
        read_only_fields = ['username', 'email', 'business_name', 'city',
                            'pincode', 'license_number']


class DriverApprovalSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    email = serializers.CharField(source='user.email', read_only=True)

    class Meta:
        model = DriverProfile
        fields = ['id', 'username', 'email', 'full_name', 'vehicle_number',
                  'vehicle_type', 'city', 'is_approved']
        read_only_fields = ['username', 'email', 'full_name', 'vehicle_number',
                            'vehicle_type', 'city']
