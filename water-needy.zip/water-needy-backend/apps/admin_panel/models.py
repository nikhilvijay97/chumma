"""Admin-side models live in core/shared; reserved for future admin-only entities."""
