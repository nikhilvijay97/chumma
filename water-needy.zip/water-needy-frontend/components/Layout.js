import Head from 'next/head';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useAuth } from '../context/AuthContext';
import { dashboardPath } from '../utils/auth';
import Footer from './Footer';
import NavBar from './NavBar';

/**
 * Wraps every authenticated page with the navbar + footer and a consistent Head.
 */
export default function Layout({ children, title = 'Water-Needy' }) {
  const { user, logout } = useAuth();
  const router = useRouter();

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  return (
    <>
      <Head>
        <title>{title} · Water-Needy</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet"
        />
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        />
      </Head>
      <NavBar user={user} onLogout={handleLogout} />
      <main>{children}</main>
      <Footer />
      {/* Bootstrap JS for collapse & dropdowns */}
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" async />
    </>
  );
}
