import { Bar, Doughnut } from 'react-chartjs-2';
import {
  ArcElement,
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Legend,
  LinearScale,
  Title,
  Tooltip,
} from 'chart.js';

ChartJS.register(ArcElement, BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend);

/**
 * Reusable charts built on Chart.js + react-chartjs-2.
 * Pass either `kind` "bar" or "doughnut".
 */
export default function OrdersChart({ kind = 'bar', labels, data, title }) {
  const options = {
    responsive: true,
    plugins: {
      legend: { position: 'bottom' },
      title: { display: !!title, text: title },
    },
  };
  const colors = ['#0077b6', '#00b4d8', '#90e0ef', '#caf0f8', '#ffd166', '#ef476f'];
  const chartData = {
    labels,
    datasets: [
      {
        label: title || 'Count',
        data,
        backgroundColor: colors.slice(0, labels.length),
        borderRadius: 6,
      },
    ],
  };
  if (kind === 'doughnut') {
    return <Doughnut data={chartData} options={options} />;
  }
  return <Bar data={chartData} options={options} />;
}
