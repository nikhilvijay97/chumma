/** Renders a coloured badge for an order status. */
export default function StatusBadge({ status }) {
  return (
    <span className={`badge badge-status status-${status}`}>
      {status?.replaceAll('_', ' ')}
    </span>
  );
}
