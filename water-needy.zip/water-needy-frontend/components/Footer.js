import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="footer-wn mt-5">
      <div className="container">
        <div className="row g-4">
          <div className="col-12 col-md-4">
            <h5>
              <i className="bi bi-droplet-fill text-warning me-2"></i>
              Water-Needy
            </h5>
            <p className="small mb-2">
              Connecting consumers with verified water suppliers and drivers.
              Clean water, on demand.
            </p>
          </div>
          <div className="col-6 col-md-2">
            <h6>Platform</h6>
            <ul className="list-unstyled small">
              <li><Link href="/">Home</Link></li>
              <li><Link href="/about">About</Link></li>
              <li><Link href="/services">Services</Link></li>
              <li><Link href="/contact">Contact</Link></li>
            </ul>
          </div>
          <div className="col-6 col-md-2">
            <h6>For You</h6>
            <ul className="list-unstyled small">
              <li><Link href="/register?role=consumer">I'm a Consumer</Link></li>
              <li><Link href="/register?role=supplier">I'm a Supplier</Link></li>
              <li><Link href="/register?role=driver">Driver Sign-up</Link></li>
            </ul>
          </div>
          <div className="col-12 col-md-4">
            <h6>Get the App</h6>
            <p className="small">Optimized for desktop, tablet & mobile — pure Bootstrap 5 responsiveness.</p>
            <div>
              <span className="badge bg-light text-dark me-1">MCA Mini Project</span>
              <span className="badge bg-warning text-dark">Django + Next.js</span>
            </div>
          </div>
        </div>
        <hr className="border-secondary opacity-25" />
        <div className="d-flex justify-content-between small flex-wrap">
          <span>© {new Date().getFullYear()} Water-Needy Platform</span>
          <span>Built with Next.js · Django · Bootstrap</span>
        </div>
      </div>
    </footer>
  );
}
