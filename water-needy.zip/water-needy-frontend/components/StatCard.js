/** A reusable stat card used on every dashboard. */
export default function StatCard({ label, value, icon, color = 'aqua' }) {
  return (
    <div className="card-stat position-relative">
      <div className={`icon text-${color}`}>
        <i className={`bi bi-${icon}`}></i>
      </div>
      <div className="label">{label}</div>
      <div className="value">{value}</div>
    </div>
  );
}
