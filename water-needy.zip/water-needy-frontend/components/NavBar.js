import Link from 'next/link';
import { useRouter } from 'next/router';
import { dashboardPath } from '../utils/auth';

const PUBLIC_LINKS = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'About' },
  { href: '/services', label: 'Services' },
  { href: '/contact', label: 'Contact' },
];

export default function NavBar({ user, onLogout }) {
  const router = useRouter();

  return (
    <nav className="navbar navbar-expand-lg navbar-wn shadow-sm sticky-top">
      <div className="container">
        <Link href="/" className="navbar-brand fw-bold">
          <i className="bi bi-droplet-fill text-warning me-2"></i>
          Water-Needy
        </Link>
        <button
          className="navbar-toggler bg-light"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#wnNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="wnNav">
          <ul className="navbar-nav me-auto">
            {PUBLIC_LINKS.map((l) => (
              <li className="nav-item" key={l.href}>
                <Link href={l.href} className={`nav-link ${router.pathname === l.href ? 'active' : ''}`}>
                  {l.label}
                </Link>
              </li>
            ))}
            {user && (
              <li className="nav-item">
                <Link href={dashboardPath(user.role)} className="nav-link">
                  Dashboard
                </Link>
              </li>
            )}
          </ul>
          <ul className="navbar-nav ms-auto align-items-lg-center">
            {!user ? (
              <>
                <li className="nav-item">
                  <Link href="/login" className="nav-link">Login</Link>
                </li>
                <li className="nav-item">
                  <Link href="/register" className="btn btn-wn ms-lg-2">
                    <i className="bi bi-person-plus me-1"></i> Register
                  </Link>
                </li>
              </>
            ) : (
              <>
                <li className="nav-item d-flex align-items-center me-2 text-white">
                  <i className="bi bi-person-circle me-1"></i>
                  {user.username} <small className="ms-1 opacity-75">({user.role})</small>
                </li>
                <li className="nav-item">
                  <button className="btn btn-sm btn-light" onClick={onLogout}>
                    <i className="bi bi-box-arrow-right me-1"></i>Logout
                  </button>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}
