# Water-Needy · Frontend (Next.js + Bootstrap)

The Next.js 14 frontend for the Water-Needy water-connect platform. All UI is
built with **Bootstrap 5**, **React 18**, and **Chart.js + react-chartjs-2**.

## Quick start

```bash
cd frontend
npm install          # installs dependencies
npm run dev          # http://localhost:3000
```

The dev server proxies `/api/*` to your local Django backend at
`http://localhost:8000`. If you change the URL, edit `.env.local`.

## Pages

| Path | Purpose | Auth |
| --- | --- | --- |
| `/` | Marketing landing page with hero, stats, how-it-works, role CTAs | Public |
| `/about` | About page | Public |
| `/services` | Services & pricing | Public |
| `/contact` | Contact form | Public |
| `/login` | Login (with Forgot Password flow) | Public |
| `/register?role=consumer\|supplier\|driver` | Role-aware registration | Public |
| `/consumer` | Consumer dashboard (stats, recent orders, donut chart) | Consumer |
| `/consumer/request-water` | Place a water request | Consumer |
| `/consumer/orders` | Order history with filter & cancel | Consumer |
| `/consumer/notifications` | In-app notifications | Consumer |
| `/consumer/profile` | Edit profile & change password | Consumer |
| `/supplier` | Supplier console | Supplier |
| `/supplier/inventory` | Inventory CRUD | Supplier |
| `/supplier/orders` | Approve / reject / assign driver | Supplier |
| `/supplier/reviews` | Customer reviews & ratings | Supplier |
| `/driver` | Driver console with status updates | Driver |
| `/driver/history` | Completed deliveries | Driver |
| `/admin` | Admin console with stats | Admin |
| `/admin/users` | User management | Admin |
| `/admin/approvals` | Approve suppliers & drivers | Admin |
| `/admin/orders` | All orders | Admin |
| `/admin/payments` | Payments ledger | Admin |
| `/admin/reports` | Charts | Admin |
| `/admin/complaints` | Complaint resolution | Admin |
| `/404` | Custom 404 page | Public |

## Demo credentials (after running `seed_data` in the backend)

| Role | Username | Password |
| --- | --- | --- |
| Admin | `admin` | `admin123` |
| Consumer | `alice` | `consumer123` |
| Supplier | `aquapure` | `supplier123` |
| Driver | `dravi` | `driver123` |

## Folder map

```
frontend/
├── components/   Layout · NavBar · Footer · StatCard · StatusBadge · OrdersChart
├── context/      AuthContext
├── hooks/        useRequireAuth
├── pages/
│   ├── index.js / about.js / services.js / contact.js
│   ├── login.js / register.js / 404.js
│   ├── consumer/[index, request-water, orders, notifications, profile].js
│   ├── supplier/[index, inventory, orders, reviews].js
│   ├── driver/[index, history, profile].js
│   └── admin/[index, users, approvals, orders, payments, reports, complaints].js
├── styles/globals.css  ←  Blue + Aqua palette
└── utils/api.js · auth.js
```
