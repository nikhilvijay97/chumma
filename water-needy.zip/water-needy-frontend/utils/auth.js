/** Auth helpers used by pages and AuthContext. */
import api from './api';

export const loginRequest = async (username, password) => {
  const { data } = await api.post('/accounts/login/', { username, password });
  if (typeof window !== 'undefined') {
    localStorage.setItem('access_token', data.access);
    localStorage.setItem('refresh_token', data.refresh);
    localStorage.setItem('user', JSON.stringify(data.user));
  }
  return data.user;
};

export const registerRequest = async (payload) => {
  await api.post('/accounts/register/', payload);
};

export const logoutLocal = () => {
  if (typeof window === 'undefined') return;
  localStorage.removeItem('access_token');
  localStorage.removeItem('refresh_token');
  localStorage.removeItem('user');
};

export const currentUser = () => {
  if (typeof window === 'undefined') return null;
  const raw = localStorage.getItem('user');
  return raw ? JSON.parse(raw) : null;
};

export const isAuthenticated = () => {
  if (typeof window === 'undefined') return false;
  return !!localStorage.getItem('access_token');
};

export const dashboardPath = (role) => {
  switch (role) {
    case 'admin': return '/admin';
    case 'supplier': return '/supplier';
    case 'driver': return '/driver';
    default: return '/consumer';
  }
};
