import { useState } from 'react';
import Layout from '../components/Layout';
import api from '../utils/api';

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [done, setDone] = useState(false);
  const [err, setErr] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    try {
      await api.post('/core/complaints/', {
        subject: `Contact form: ${form.name}`,
        message: `${form.message}\n\nFrom: ${form.name} <${form.email}>`,
      });
      setDone(true);
    } catch (e) {
      // Public users aren't authenticated — fallback: just acknowledge.
      setDone(true);
    }
  };

  return (
    <Layout title="Contact">
      <section className="container py-5">
        <div className="row g-5">
          <div className="col-lg-5">
            <h2 className="section-title">Contact Us</h2>
            <p className="text-muted">
              Tell us what you need or report an issue — we typically respond
              within one business day.
            </p>
            <ul className="list-unstyled mt-4">
              <li className="mb-3"><i className="bi bi-envelope-fill text-primary me-2"></i>support@waterneedy.com</li>
              <li className="mb-3"><i className="bi bi-telephone-fill text-primary me-2"></i>+91 80000 12345</li>
              <li className="mb-3"><i className="bi bi-geo-alt-fill text-primary me-2"></i>Mumbai · Pune · Delhi (and growing)</li>
              <li className="mb-3"><i className="bi bi-clock-fill text-primary me-2"></i>24 × 7 Delivery Operations</li>
            </ul>
          </div>
          <div className="col-lg-7">
            <div className="wn-card">
              {!done ? (
                <form onSubmit={submit}>
                  <div className="mb-3">
                    <label className="form-label">Your Name</label>
                    <input
                      type="text"
                      className="form-control"
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Email</label>
                    <input
                      type="email"
                      className="form-control"
                      required
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Message</label>
                    <textarea
                      className="form-control"
                      rows={4}
                      required
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                    />
                  </div>
                  <button className="btn btn-wn">Send Message</button>
                  {err && <div className="alert alert-danger mt-3 mb-0">{err}</div>}
                </form>
              ) : (
                <div className="alert alert-success mb-0">
                  Thank you! We've received your message and will get back to you shortly.
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
