import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="page-404">
      <div>
        <h1 className="display-1 fw-bold">404</h1>
        <p className="lead">We couldn't find the page you were looking for.</p>
        <Link href="/" className="btn btn-light btn-lg mt-3">
          <i className="bi bi-house-door me-2"></i>Back to Home
        </Link>
      </div>
    </div>
  );
}
