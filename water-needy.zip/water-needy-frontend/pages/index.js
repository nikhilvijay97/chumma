import Link from 'next/link';
import Layout from '../components/Layout';
import StatCard from '../components/StatCard';

export default function HomePage() {
  return (
    <Layout title="Home">
      {/* Hero */}
      <section className="hero">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-7">
              <h1 className="display-4 mb-3">Clean Water, On Demand.</h1>
              <p className="lead mb-4" style={{ maxWidth: 620 }}>
                Water-Needy is a centralized water-connect platform that links
                consumers, suppliers, and drivers — so a tanker or a 20-L can is
                always minutes away.
              </p>
              <div className="d-flex gap-2 flex-wrap">
                <Link href="/register?role=consumer" className="btn btn-wn btn-lg">
                  <i className="bi bi-droplet me-2"></i>Request Water
                </Link>
                <Link href="/register?role=supplier" className="btn btn-outline-light btn-lg">
                  I'm a Supplier
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="container py-5">
        <div className="row g-3">
          <div className="col-6 col-md-3"><StatCard label="Active Users" value="5,200+" icon="people-fill" /></div>
          <div className="col-6 col-md-3"><StatCard label="Verified Suppliers" value="180+" icon="shield-check" /></div>
          <div className="col-6 col-md-3"><StatCard label="Drivers On-Road" value="320+" icon="truck" /></div>
          <div className="col-6 col-md-3"><StatCard label="Litres Delivered" value="12.4M" icon="droplet-half" /></div>
        </div>
      </section>

      {/* How it works */}
      <section className="container py-5">
        <h2 className="section-title">How It Works</h2>
        <div className="row g-4">
          {[
            { i: 'search', t: '1. Find a Supplier', d: 'Search verified water suppliers in your city. Compare rates, water types, distances.' },
            { i: 'cart-plus', t: '2. Place a Request', d: 'Choose your water type, quantity, delivery date and address — confirmed in seconds.' },
            { i: 'truck', t: '3. We Deliver', d: 'Approved orders are routed to the nearest available driver. Track in real-time.' },
            { i: 'star-fill', t: '4. Rate & Review', d: 'After delivery, leave a rating. Your feedback keeps the platform honest.' },
          ].map((s, i) => (
            <div className="col-md-6 col-lg-3" key={i}>
              <div className="wn-card h-100 text-center">
                <i className={`bi bi-${s.i} fs-1 text-primary`}></i>
                <h5 className="mt-3">{s.t}</h5>
                <p className="text-muted small mb-0">{s.d}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Roles */}
      <section className="container py-5">
        <h2 className="section-title">Built for Everyone in the Chain</h2>
        <div className="row g-4">
          {[
            { role: 'Consumer', icon: 'house-heart', desc: 'Find suppliers, request water, track delivery, leave reviews.', link: '/register?role=consumer' },
            { role: 'Supplier', icon: 'building', desc: 'Manage inventory, approve orders, assign drivers, see revenue.', link: '/register?role=supplier' },
            { role: 'Driver', icon: 'truck-front', desc: 'Accept deliveries, update status, view earnings & history.', link: '/register?role=driver' },
            { role: 'Admin', icon: 'shield-lock', desc: 'Verify users, monitor orders, manage payments, handle complaints.', link: '/login' },
          ].map((r) => (
            <div className="col-md-6 col-lg-3" key={r.role}>
              <div className="wn-card h-100">
                <i className={`bi bi-${r.icon} fs-2 text-primary`}></i>
                <h5 className="mt-2">{r.role}</h5>
                <p className="small text-muted">{r.desc}</p>
                <Link href={r.link} className="btn btn-wn-outline btn-sm">Get Started</Link>
              </div>
            </div>
          ))}
        </div>
      </section>
    </Layout>
  );
}
