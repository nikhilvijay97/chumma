import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import StatusBadge from '../../components/StatusBadge';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function AdminOrdersPage() {
  const { user } = useRequireAuth('admin');
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    if (!user) return;
    api.get('/admin-panel/orders/').then((r) => setOrders(r.data || []));
  }, [user]);

  return (
    <Layout title="Orders">
      <section className="container py-4">
        <h2 className="section-title">All Orders</h2>
        <div className="wn-card">
          {orders.length === 0 ? (
            <div className="small text-muted">No orders yet.</div>
          ) : (
            <div className="table-responsive">
              <table className="table table-sm align-middle">
                <thead>
                  <tr><th>#</th><th>Consumer</th><th>Supplier</th><th>Driver</th><th>Type</th><th>Qty</th><th>Total</th><th>Status</th><th>Date</th></tr>
                </thead>
                <tbody>
                  {orders.map((o) => (
                    <tr key={o.id}>
                      <td>#{o.id}</td>
                      <td>{o.consumer}</td>
                      <td>{o.supplier || '-'}</td>
                      <td>{o.driver || '-'}</td>
                      <td className="text-capitalize">{o.water_type}</td>
                      <td>{o.quantity_litres} L</td>
                      <td>₹{o.total_amount}</td>
                      <td><StatusBadge status={o.status} /></td>
                      <td className="small">{new Date(o.created_at).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}
