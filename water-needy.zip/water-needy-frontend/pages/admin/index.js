import { useEffect, useState } from 'react';
import Link from 'next/link';
import Layout from '../../components/Layout';
import StatCard from '../../components/StatCard';
import OrdersChart from '../../components/OrdersChart';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function AdminDashboard() {
  const { user } = useRequireAuth('admin');
  const [stats, setStats] = useState({
    total_users: 0, consumers: 0, suppliers: 0, drivers: 0,
    orders: 0, revenue: 0,
  });
  const [complaints, setComplaints] = useState([]);

  useEffect(() => {
    if (!user) return;
    api.get('/admin-panel/dashboard/').then((r) => setStats(r.data));
    api.get('/admin-panel/complaints/').then((r) => setComplaints((r.data || []).slice(0, 5)));
  }, [user]);

  const byRole = [
    { name: 'Consumers', v: stats.consumers },
    { name: 'Suppliers', v: stats.suppliers },
    { name: 'Drivers', v: stats.drivers },
  ];

  return (
    <Layout title="Admin Dashboard">
      <section className="container py-4">
        <h2 className="section-title">Admin Console</h2>
        <div className="row g-3 mb-4">
          <div className="col-md-2"><StatCard label="Total Users" value={stats.total_users} icon="people" /></div>
          <div className="col-md-2"><StatCard label="Consumers" value={stats.consumers} icon="house" /></div>
          <div className="col-md-2"><StatCard label="Suppliers" value={stats.suppliers} icon="building" /></div>
          <div className="col-md-2"><StatCard label="Drivers" value={stats.drivers} icon="truck" /></div>
          <div className="col-md-2"><StatCard label="Orders" value={stats.orders} icon="bag" /></div>
          <div className="col-md-2"><StatCard label="Revenue" value={`₹${stats.revenue.toLocaleString()}`} icon="currency-rupee" /></div>
        </div>

        <div className="row g-4">
          <div className="col-lg-6">
            <div className="wn-card">
              <h6>User Mix</h6>
              <OrdersChart kind="doughnut" labels={byRole.map((x) => x.name)} data={byRole.map((x) => x.v)} />
            </div>
            <div className="wn-card">
              <h6>Quick Links</h6>
              <div className="d-flex flex-wrap gap-2">
                <Link href="/admin/users" className="btn btn-wn-outline btn-sm">Users</Link>
                <Link href="/admin/approvals" className="btn btn-wn-outline btn-sm">Approvals</Link>
                <Link href="/admin/orders" className="btn btn-wn-outline btn-sm">Orders</Link>
                <Link href="/admin/payments" className="btn btn-wn-outline btn-sm">Payments</Link>
                <Link href="/admin/reports" className="btn btn-wn-outline btn-sm">Reports</Link>
                <Link href="/admin/complaints" className="btn btn-wn-outline btn-sm">Complaints</Link>
              </div>
            </div>
          </div>
          <div className="col-lg-6">
            <div className="wn-card">
              <h6>Latest Complaints</h6>
              {complaints.length === 0 ? (
                <div className="text-muted small">No complaints.</div>
              ) : (
                <ul className="list-unstyled mb-0">
                  {complaints.map((c) => (
                    <li key={c.id} className="border-bottom py-2">
                      <strong>{c.subject}</strong>
                      <div className="small text-muted">{c.message.slice(0, 100)}…</div>
                      <span className="badge bg-secondary">{c.status}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
