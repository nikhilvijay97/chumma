import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function AdminApprovals() {
  const { user } = useRequireAuth('admin');
  const [suppliers, setSuppliers] = useState([]);
  const [drivers, setDrivers] = useState([]);

  const load = () => {
    api.get('/admin-panel/suppliers/pending/').then((r) => setSuppliers(r.data || []));
    api.get('/admin-panel/drivers/pending/').then((r) => setDrivers(r.data || []));
  };
  useEffect(() => { if (user) load(); }, [user]);

  const approve = async (kind, id) => {
    await api.post(`/admin-panel/${kind}s/${id}/approve/`);
    load();
  };

  return (
    <Layout title="Approvals">
      <section className="container py-4">
        <h2 className="section-title">Pending Approvals</h2>
        <div className="row g-4">
          <div className="col-lg-6">
            <div className="wn-card">
              <h6>Suppliers</h6>
              {suppliers.length === 0 ? (
                <div className="small text-muted">No pending suppliers.</div>
              ) : (
                <table className="table table-sm">
                  <thead><tr><th>Business</th><th>City</th><th>License</th><th></th></tr></thead>
                  <tbody>
                    {suppliers.map((s) => (
                      <tr key={s.id}>
                        <td>{s.business_name}</td>
                        <td>{s.city}</td>
                        <td>{s.license_number}</td>
                        <td><button className="btn btn-sm btn-success" onClick={() => approve('supplier', s.id)}>Approve</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
          <div className="col-lg-6">
            <div className="wn-card">
              <h6>Drivers</h6>
              {drivers.length === 0 ? (
                <div className="small text-muted">No pending drivers.</div>
              ) : (
                <table className="table table-sm">
                  <thead><tr><th>Name</th><th>Vehicle</th><th>City</th><th></th></tr></thead>
                  <tbody>
                    {drivers.map((d) => (
                      <tr key={d.id}>
                        <td>{d.full_name}</td>
                        <td>{d.vehicle_number}</td>
                        <td>{d.city}</td>
                        <td><button className="btn btn-sm btn-success" onClick={() => approve('driver', d.id)}>Approve</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
