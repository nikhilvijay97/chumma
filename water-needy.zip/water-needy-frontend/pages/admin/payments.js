import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function AdminPaymentsPage() {
  const { user } = useRequireAuth('admin');
  const [payments, setPayments] = useState([]);

  useEffect(() => {
    if (!user) return;
    api.get('/admin-panel/payments/').then((r) => setPayments(r.data || []));
  }, [user]);

  return (
    <Layout title="Payments">
      <section className="container py-4">
        <h2 className="section-title">Payments</h2>
        <div className="wn-card">
          {payments.length === 0 ? (
            <div className="small text-muted">No payments yet.</div>
          ) : (
            <table className="table table-sm align-middle">
              <thead>
                <tr><th>#</th><th>Order</th><th>Amount</th><th>Method</th><th>Status</th><th>Date</th></tr>
              </thead>
              <tbody>
                {payments.map((p) => (
                  <tr key={p.id}>
                    <td>#{p.id}</td>
                    <td>#{p.order_id}</td>
                    <td>₹{p.amount}</td>
                    <td className="text-uppercase">{p.method}</td>
                    <td><span className={`badge bg-${p.status === 'success' ? 'success' : 'secondary'}`}>{p.status}</span></td>
                    <td className="small">{new Date(p.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </Layout>
  );
}
