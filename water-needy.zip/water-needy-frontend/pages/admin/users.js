import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function AdminUsersPage() {
  const { user } = useRequireAuth('admin');
  const [users, setUsers] = useState([]);
  const [role, setRole] = useState('');

  const load = () => {
    const q = role ? `?role=${role}` : '';
    api.get(`/admin-panel/users/${q}`).then((r) => setUsers(r.data || []));
  };
  useEffect(() => { if (user) load(); }, [user, role]);

  const toggle = async (id) => {
    await api.post(`/admin-panel/users/${id}/toggle/`);
    load();
  };

  return (
    <Layout title="Users">
      <section className="container py-4">
        <div className="d-flex justify-content-between mb-3">
          <h2 className="section-title mb-0">User Management</h2>
          <select className="form-select w-auto" value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="">All Roles</option>
            <option value="consumer">Consumer</option>
            <option value="supplier">Supplier</option>
            <option value="driver">Driver</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <div className="wn-card">
          <table className="table align-middle">
            <thead>
              <tr><th>#</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Action</th></tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.id}</td>
                  <td>{u.username}</td>
                  <td>{u.email}</td>
                  <td className="text-capitalize">{u.role}</td>
                  <td><span className={`badge bg-${u.is_active ? 'success' : 'danger'}`}>{u.is_active ? 'Active' : 'Disabled'}</span></td>
                  <td>
                    <button className="btn btn-sm btn-wn-outline" onClick={() => toggle(u.id)}>Toggle</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </Layout>
  );
}
