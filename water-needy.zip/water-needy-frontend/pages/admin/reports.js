import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import OrdersChart from '../../components/OrdersChart';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function AdminReports() {
  const { user } = useRequireAuth('admin');
  const [data, setData] = useState({ by_status: [], by_type: [] });

  useEffect(() => {
    if (!user) return;
    api.get('/admin-panel/reports/').then((r) => setData(r.data));
  }, [user]);

  return (
    <Layout title="Reports">
      <section className="container py-4">
        <h2 className="section-title">Reports &amp; Analytics</h2>
        <div className="row g-4">
          <div className="col-lg-6">
            <div className="wn-card">
              <h6>Orders by Status</h6>
              <OrdersChart
                kind="bar"
                labels={(data.by_status || []).map((s) => s.status)}
                data={(data.by_status || []).map((s) => s.count)}
              />
            </div>
          </div>
          <div className="col-lg-6">
            <div className="wn-card">
              <h6>Orders by Water Type</h6>
              <OrdersChart
                kind="doughnut"
                labels={(data.by_type || []).map((t) => t.water_type)}
                data={(data.by_type || []).map((t) => t.count)}
              />
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
