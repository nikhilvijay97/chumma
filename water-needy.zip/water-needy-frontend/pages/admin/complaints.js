import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function AdminComplaints() {
  const { user } = useRequireAuth('admin');
  const [list, setList] = useState([]);

  const load = () => api.get('/admin-panel/complaints/').then((r) => setList(r.data || []));
  useEffect(() => { if (user) load(); }, [user]);

  const resolve = async (id) => {
    await api.post(`/admin-panel/complaints/${id}/resolve/`);
    load();
  };

  return (
    <Layout title="Complaints">
      <section className="container py-4">
        <h2 className="section-title">Complaints</h2>
        <div className="wn-card">
          {list.length === 0 ? (
            <div className="text-muted small">No complaints.</div>
          ) : (
            <table className="table align-middle">
              <thead>
                <tr><th>#</th><th>User</th><th>Subject</th><th>Message</th><th>Status</th><th></th></tr>
              </thead>
              <tbody>
                {list.map((c) => (
                  <tr key={c.id}>
                    <td>#{c.id}</td>
                    <td>{c.user || '-'}</td>
                    <td>{c.subject}</td>
                    <td className="small text-muted">{c.message}</td>
                    <td><span className={`badge bg-${c.status === 'resolved' ? 'success' : 'secondary'}`}>{c.status}</span></td>
                    <td>
                      {c.status !== 'resolved' && (
                        <button className="btn btn-sm btn-success" onClick={() => resolve(c.id)}>Resolve</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </Layout>
  );
}
