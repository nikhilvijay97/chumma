import Layout from '../components/Layout';

const SERVICES = [
  {
    icon: 'droplet-fill',
    title: 'Mineral Water',
    desc: '20 L can & 1 L bottles from BIS-certified plants.',
  },
  {
    icon: 'cup-straw',
    title: 'RO Purified',
    desc: 'Multi-stage RO + UV purification, TDS reports shared.',
  },
  {
    icon: 'truck',
    title: 'Bulk Tanker',
    desc: '1000–5000 L tanker loads for housing societies & events.',
  },
  {
    icon: 'thermometer-half',
    title: 'Hot & Ambient',
    desc: 'Temperature-controlled options for offices & gyms.',
  },
  {
    icon: 'geo-alt',
    title: 'Nearby Search',
    desc: 'Find suppliers around you, ranked by distance & rating.',
  },
  {
    icon: 'bell',
    title: 'Smart Notifications',
    desc: 'Real-time order & delivery status, in-app and via email.',
  },
];

export default function ServicesPage() {
  return (
    <Layout title="Services">
      <section className="container py-5">
        <h2 className="section-title">Our Services</h2>
        <p className="text-muted mb-4">
          From a single bottle to a housing-society tanker, Water-Needy's
          platform supports every need — with the right quality, the right
          price, and the right supplier.
        </p>
        <div className="row g-4">
          {SERVICES.map((s) => (
            <div className="col-md-6 col-lg-4" key={s.title}>
              <div className="wn-card h-100">
                <i className={`bi bi-${s.icon} fs-2 text-primary`}></i>
                <h5 className="mt-3">{s.title}</h5>
                <p className="text-muted small mb-0">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="container py-5">
        <h2 className="section-title">Plans</h2>
        <div className="row g-4">
          <div className="col-md-4">
            <div className="wn-card text-center">
              <h5>Pay-as-you-go</h5>
              <h2 className="text-primary">₹ / L</h2>
              <p className="text-muted small">No commitment, no minimum order.</p>
              <button className="btn btn-wn-outline">Order Once</button>
            </div>
          </div>
          <div className="col-md-4">
            <div className="wn-card text-center border-warning border-2">
              <span className="badge bg-warning text-dark mb-2">Popular</span>
              <h5>Monthly Subscription</h5>
              <h2 className="text-primary">5% off</h2>
              <p className="text-muted small">Auto-refill on your schedule.</p>
              <button className="btn btn-wn">Subscribe</button>
            </div>
          </div>
          <div className="col-md-4">
            <div className="wn-card text-center">
              <h5>Society Bulk</h5>
              <h2 className="text-primary">Tanker</h2>
              <p className="text-muted small">For RWAs, hostels, corporates.</p>
              <button className="btn btn-wn-outline">Enquire</button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
