import { useEffect, useState } from 'react';
import Link from 'next/link';
import Layout from '../../components/Layout';
import StatCard from '../../components/StatCard';
import StatusBadge from '../../components/StatusBadge';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function DriverDashboard() {
  const { user } = useRequireAuth('driver');
  const [stats, setStats] = useState({ assigned_deliveries: 0, completed_deliveries: 0, earnings: 0 });
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    if (!user) return;
    api.get('/driver/dashboard/').then((r) => setStats(r.data));
    api.get('/driver/orders/').then((r) => setOrders(r.data || []));
  }, [user]);

  const updateStatus = async (id, status) => {
    await api.post(`/driver/orders/${id}/status/`, { status });
    api.get('/driver/dashboard/').then((r) => setStats(r.data));
    api.get('/driver/orders/').then((r) => setOrders(r.data || []));
  };

  return (
    <Layout title="Driver Dashboard">
      <section className="container py-4">
        <h2 className="section-title">Driver Console</h2>
        <div className="row g-3 mb-4">
          <div className="col-md-4"><StatCard label="Assigned" value={stats.assigned_deliveries} icon="truck" /></div>
          <div className="col-md-4"><StatCard label="Completed" value={stats.completed_deliveries} icon="check2-circle" /></div>
          <div className="col-md-4"><StatCard label="Earnings (₹)" value={`₹${stats.earnings.toLocaleString()}`} icon="currency-rupee" /></div>
        </div>

        <div className="wn-card">
          <div className="d-flex justify-content-between mb-3">
            <h5 className="mb-0">My Active Deliveries</h5>
            <Link href="/driver/history" className="btn btn-sm btn-wn-outline">History</Link>
          </div>
          {orders.length === 0 ? (
            <div className="text-muted small">No assignments at this moment.</div>
          ) : (
            <table className="table align-middle">
              <thead>
                <tr>
                  <th>#</th><th>Consumer</th><th>Supplier</th><th>Address</th>
                  <th>Water</th><th>Qty</th><th>Status</th><th>Update</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((o) => (
                  <tr key={o.id}>
                    <td>#{o.id}</td>
                    <td>{o.consumer_name}</td>
                    <td className="small">{o.supplier_name || '-'}</td>
                    <td className="small">{o.delivery_address}</td>
                    <td className="text-capitalize">{o.water_type}</td>
                    <td>{o.quantity_litres} L</td>
                    <td><StatusBadge status={o.status} /></td>
                    <td>
                      <div className="d-flex gap-1">
                        {o.status === 'assigned' && (
                          <button className="btn btn-sm btn-info" onClick={() => updateStatus(o.id, 'picked_up')}>Picked Up</button>
                        )}
                        {o.status === 'picked_up' && (
                          <button className="btn btn-sm btn-primary" onClick={() => updateStatus(o.id, 'on_the_way')}>On Way</button>
                        )}
                        {o.status === 'on_the_way' && (
                          <button className="btn btn-sm btn-success" onClick={() => updateStatus(o.id, 'delivered')}>Delivered</button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </Layout>
  );
}
