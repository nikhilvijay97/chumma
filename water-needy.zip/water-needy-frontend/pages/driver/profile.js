import { useState } from 'react';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { useAuth } from '../../context/AuthContext';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function DriverProfilePage() {
  const { user, setUser } = useAuth();
  const { } = useRequireAuth();
  const [form, setForm] = useState({
    email: user?.email || '',
    phone: user?.phone || '',
    address: user?.address || '',
  });
  const [saved, setSaved] = useState(false);

  const save = async (e) => {
    e.preventDefault();
    const r = await api.put('/accounts/profile/', form);
    setUser(r.data);
    setSaved(true);
  };

  return (
    <Layout title="Profile">
      <section className="container py-4">
        <h2 className="section-title">My Profile</h2>
        <div className="row g-4">
          <div className="col-md-6">
            <div className="wn-card">
              <h6>Account</h6>
              <div><strong>Username:</strong> {user?.username}</div>
              <div className="small text-muted text-capitalize">Role: {user?.role}</div>
              <hr />
              <form onSubmit={save}>
                <div className="mb-2">
                  <label className="form-label small">Email</label>
                  <input className="form-control" value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })} />
                </div>
                <div className="mb-2">
                  <label className="form-label small">Phone</label>
                  <input className="form-control" value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                </div>
                <div className="mb-2">
                  <label className="form-label small">Address</label>
                  <textarea className="form-control" rows={2} value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })} />
                </div>
                <button className="btn btn-wn">Save</button>
                {saved && <span className="ms-3 text-success small">Saved.</span>}
              </form>
            </div>
          </div>
          <div className="col-md-6">
            <div className="wn-card">
              <h6>Vehicle Details</h6>
              {user?.driver_profile ? (
                <ul className="list-unstyled mb-0">
                  <li><strong>Name:</strong> {user.driver_profile.full_name}</li>
                  <li><strong>License:</strong> {user.driver_profile.license_number}</li>
                  <li><strong>Vehicle:</strong> {user.driver_profile.vehicle_number} ({user.driver_profile.vehicle_type})</li>
                  <li><strong>Status:</strong> {user.driver_profile.is_approved ? '✅ Approved' : '⏳ Pending approval'}</li>
                </ul>
              ) : (
                <div className="text-muted small">No driver profile yet.</div>
              )}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
