import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import StatusBadge from '../../components/StatusBadge';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function DriverHistoryPage() {
  const { user } = useRequireAuth('driver');
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    if (!user) return;
    api.get('/driver/orders/history/').then((r) => setOrders(r.data || []));
  }, [user]);

  return (
    <Layout title="Delivery History">
      <section className="container py-4">
        <h2 className="section-title">Delivery History</h2>
        <div className="wn-card">
          {orders.length === 0 ? (
            <div className="text-muted small">No completed deliveries yet.</div>
          ) : (
            <table className="table align-middle">
              <thead><tr><th>#</th><th>Consumer</th><th>Water</th><th>Qty</th><th>Amount</th><th>Date</th><th>Status</th></tr></thead>
              <tbody>
                {orders.map((o) => (
                  <tr key={o.id}>
                    <td>#{o.id}</td>
                    <td>{o.consumer_name}</td>
                    <td className="text-capitalize">{o.water_type}</td>
                    <td>{o.quantity_litres} L</td>
                    <td>₹{o.total_amount}</td>
                    <td className="small">{new Date(o.created_at).toLocaleDateString()}</td>
                    <td><StatusBadge status={o.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </Layout>
  );
}
