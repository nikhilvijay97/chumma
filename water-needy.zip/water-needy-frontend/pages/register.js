import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import Layout from '../components/Layout';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { dashboardPath } from '../utils/auth';

const ROLE_FIELDS = {
  consumer: ['full_name', 'city', 'pincode', 'default_address'],
  supplier: ['business_name', 'license_number', 'city', 'pincode', 'description'],
  driver: ['full_name', 'license_number', 'vehicle_number', 'vehicle_type'],
};

const EXTRA_FIELDS = {
  full_name: { label: 'Full Name', type: 'text' },
  city: { label: 'City', type: 'text' },
  pincode: { label: 'Pincode', type: 'text' },
  default_address: { label: 'Default Delivery Address', type: 'textarea' },
  business_name: { label: 'Business Name', type: 'text' },
  license_number: { label: 'License Number', type: 'text' },
  description: { label: 'Description', type: 'textarea' },
  vehicle_number: { label: 'Vehicle Number', type: 'text' },
  vehicle_type: { label: 'Vehicle Type', type: 'text' },
};

export default function RegisterPage() {
  const router = useRouter();
  const { user } = useAuth();
  const [role, setRole] = useState('consumer');
  const [form, setForm] = useState({
    username: '', email: '', password: '', password2: '',
    phone: '', address: '',
  });
  const [extras, setExtras] = useState({});
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const r = router.query.role;
    if (r && ['consumer', 'supplier', 'driver'].includes(r)) setRole(r);
  }, [router.query.role]);

  useEffect(() => {
    if (user) router.replace(dashboardPath(user.role));
  }, [user, router]);

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    if (form.password !== form.password2) {
      setErr('Passwords do not match.');
      return;
    }
    setBusy(true);
    try {
      await api.post('/accounts/register/', { ...form, role, ...extras });
      alert('Account created! Please log in.');
      router.push('/login');
    } catch (e) {
      const d = e?.response?.data;
      const first = typeof d === 'object' ? Object.values(d)[0] : null;
      setErr(Array.isArray(first) ? first[0] : 'Registration failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Layout title="Register">
      <section className="container py-5">
        <div className="row justify-content-center">
          <div className="col-md-8 col-lg-6">
            <div className="wn-card">
              <h3 className="mb-4">
                <i className="bi bi-person-plus-fill text-primary me-2"></i>
                Create your account
              </h3>

              <div className="mb-3">
                <label className="form-label">I am a…</label>
                <div className="d-flex gap-2 flex-wrap">
                  {['consumer', 'supplier', 'driver'].map((r) => (
                    <button
                      key={r}
                      type="button"
                      className={`btn ${role === r ? 'btn-wn' : 'btn-wn-outline'} flex-grow-1`}
                      onClick={() => setRole(r)}
                    >
                      {r[0].toUpperCase() + r.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              <form onSubmit={submit}>
                <div className="row g-2">
                  <div className="col-md-6">
                    <label className="form-label">Username</label>
                    <input className="form-control" required
                      onChange={(e) => setForm({ ...form, username: e.target.value })} />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Email</label>
                    <input type="email" className="form-control" required
                      onChange={(e) => setForm({ ...form, email: e.target.value })} />
                  </div>
                </div>
                <div className="row g-2 mt-1">
                  <div className="col-md-6">
                    <label className="form-label">Password</label>
                    <input type="password" className="form-control" required
                      onChange={(e) => setForm({ ...form, password: e.target.value })} />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Confirm</label>
                    <input type="password" className="form-control" required
                      onChange={(e) => setForm({ ...form, password2: e.target.value })} />
                  </div>
                </div>

                <div className="row g-2 mt-1">
                  <div className="col-md-6">
                    <label className="form-label">Phone</label>
                    <input className="form-control"
                      onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                  </div>
                </div>

                <hr className="my-3" />
                <h6 className="text-muted">{role.toUpperCase()} details</h6>
                {ROLE_FIELDS[role].map((key) => {
                  const f = EXTRA_FIELDS[key];
                  return (
                    <div className="mb-2" key={key}>
                      <label className="form-label">{f.label}</label>
                      {f.type === 'textarea' ? (
                        <textarea
                          className="form-control"
                          onChange={(e) => setExtras({ ...extras, [key]: e.target.value })}
                          rows={2}
                        />
                      ) : (
                        <input
                          className="form-control"
                          onChange={(e) => setExtras({ ...extras, [key]: e.target.value })}
                        />
                      )}
                    </div>
                  );
                })}

                {err && <div className="alert alert-danger py-2 small">{err}</div>}
                <div className="d-flex justify-content-between align-items-center mt-3">
                  <Link href="/login">Have an account? Login</Link>
                  <button className="btn btn-wn" disabled={busy}>
                    {busy ? 'Creating…' : 'Create Account'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
