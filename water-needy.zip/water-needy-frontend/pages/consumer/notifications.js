import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function NotificationsPage() {
  const { user } = useRequireAuth();
  const [notifs, setNotifs] = useState([]);

  const load = () => {
    api.get('/core/notifications/').then((r) => setNotifs(r.data || []));
  };
  useEffect(() => { if (user) load(); }, [user]);

  const markAll = async () => {
    await api.post('/core/notifications/read/');
    load();
  };

  return (
    <Layout title="Notifications">
      <section className="container py-4">
        <div className="d-flex justify-content-between mb-3">
          <h2 className="section-title mb-0">Notifications</h2>
          <button className="btn btn-wn-outline btn-sm" onClick={markAll}>Mark all read</button>
        </div>
        <div className="wn-card">
          {notifs.length === 0 ? (
            <div className="text-muted small">No notifications yet.</div>
          ) : (
            <ul className="list-unstyled mb-0">
              {notifs.map((n) => (
                <li key={n.id} className={`border-bottom py-2 ${n.is_read ? '' : 'bg-light rounded'}`}>
                  <div className="d-flex justify-content-between">
                    <strong>{n.title}</strong>
                    <small className="text-muted">{new Date(n.created_at).toLocaleString()}</small>
                  </div>
                  <div className="small text-muted">{n.message}</div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </Layout>
  );
}
