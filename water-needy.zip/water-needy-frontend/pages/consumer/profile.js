import { useState } from 'react';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { useAuth } from '../../context/AuthContext';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function ProfilePage() {
  const { user, setUser } = useAuth();
  const { } = useRequireAuth();
  const [form, setForm] = useState({
    email: user?.email || '',
    phone: user?.phone || '',
    address: user?.address || '',
  });
  const [saved, setSaved] = useState(false);
  const [pwdForm, setPwdForm] = useState({ old_password: '', new_password: '' });
  const [pwdMsg, setPwdMsg] = useState('');

  const save = async (e) => {
    e.preventDefault();
    setSaved(false);
    const r = await api.put('/accounts/profile/', form);
    setUser(r.data);
    setSaved(true);
  };

  const changePwd = async (e) => {
    e.preventDefault();
    setPwdMsg('');
    try {
      await api.post('/accounts/change-password/', pwdForm);
      setPwdMsg('Password changed.');
      setPwdForm({ old_password: '', new_password: '' });
    } catch (e) {
      setPwdMsg('Old password incorrect.');
    }
  };

  return (
    <Layout title="Profile">
      <section className="container py-4">
        <h2 className="section-title">My Profile</h2>
        <div className="row g-4">
          <div className="col-md-7">
            <div className="wn-card">
              <h6>Account Details</h6>
              <div className="d-flex align-items-center mb-3">
                <div className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style={{ width: 60, height: 60, fontSize: 24 }}>
                  {user?.username?.[0]?.toUpperCase() || '?'}
                </div>
                <div>
                  <strong>{user?.username}</strong>
                  <div className="small text-muted text-capitalize">{user?.role}</div>
                </div>
              </div>
              <form onSubmit={save}>
                <div className="mb-2">
                  <label className="form-label small">Email</label>
                  <input className="form-control" value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })} />
                </div>
                <div className="mb-2">
                  <label className="form-label small">Phone</label>
                  <input className="form-control" value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                </div>
                <div className="mb-2">
                  <label className="form-label small">Address</label>
                  <textarea className="form-control" rows={2} value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })} />
                </div>
                <button className="btn btn-wn">Save Changes</button>
                {saved && <span className="ms-3 text-success small">Saved!</span>}
              </form>
            </div>
          </div>

          <div className="col-md-5">
            <div className="wn-card">
              <h6>Change Password</h6>
              <form onSubmit={changePwd}>
                <div className="mb-2">
                  <input type="password" className="form-control" placeholder="Old password"
                    required onChange={(e) => setPwdForm({ ...pwdForm, old_password: e.target.value })} />
                </div>
                <div className="mb-2">
                  <input type="password" className="form-control" placeholder="New password"
                    required onChange={(e) => setPwdForm({ ...pwdForm, new_password: e.target.value })} />
                </div>
                <button className="btn btn-wn">Update Password</button>
                {pwdMsg && <div className="alert alert-info py-2 small mt-2 mb-0">{pwdMsg}</div>}
              </form>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
