import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function RequestWaterPage() {
  const { user } = useRequireAuth('consumer');
  const router = useRouter();
  const [suppliers, setSuppliers] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [form, setForm] = useState({
    supplier_id: '',
    inventory_id: '',
    water_type: 'mineral',
    quantity_litres: 20,
    delivery_address: '',
    preferred_date: '',
  });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.get('/consumer/suppliers/nearby/').then((r) => setSuppliers(r.data || [])).catch(() => {});
  }, []);

  useEffect(() => {
    if (!form.supplier_id) { setInventory([]); return; }
    api.get(`/supplier/inventory/?supplier=${form.supplier_id}`)
      .then((r) => setInventory(r.data.results || r.data || []))
      .catch(() => setInventory([]));
  }, [form.supplier_id]);

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    setBusy(true);
    try {
      await api.post('/consumer/orders/create/', {
        inventory: parseInt(form.inventory_id, 10),
        water_type: form.water_type,
        quantity_litres: parseInt(form.quantity_litres, 10),
        delivery_address: form.delivery_address,
        preferred_date: form.preferred_date || null,
      });
      router.push('/consumer/orders');
    } catch (e) {
      const d = e?.response?.data;
      setErr(typeof d === 'object' ? JSON.stringify(d) : 'Could not place order.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Layout title="Request Water">
      <section className="container py-4">
        <h2 className="section-title">Request Water</h2>
        <div className="row g-4">
          <div className="col-lg-8">
            <div className="wn-card">
              <form onSubmit={submit}>
                <div className="mb-3">
                  <label className="form-label">Choose Supplier</label>
                  <select
                    className="form-select"
                    required
                    value={form.supplier_id}
                    onChange={(e) => setForm({ ...form, supplier_id: e.target.value, inventory_id: '' })}
                  >
                    <option value="">-- Select a supplier --</option>
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.business_name} · {s.city} – {s.pincode}
                      </option>
                    ))}
                  </select>
                </div>

                {inventory.length > 0 && (
                  <div className="mb-3">
                    <label className="form-label">SKU</label>
                    <select
                      className="form-select"
                      required
                      value={form.inventory_id}
                      onChange={(e) => setForm({ ...form, inventory_id: e.target.value })}
                    >
                      <option value="">-- Select SKU --</option>
                      {inventory.map((inv) => (
                        <option key={inv.id} value={inv.id}>
                          {inv.water_type} — {inv.available_litres}L @ ₹{inv.price_per_litre}/L
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="row g-2">
                  <div className="col-md-6">
                    <label className="form-label">Water Type</label>
                    <select
                      className="form-select"
                      value={form.water_type}
                      onChange={(e) => setForm({ ...form, water_type: e.target.value })}
                    >
                      <option value="mineral">Mineral</option>
                      <option value="ro">RO</option>
                      <option value="tanker">Tanker</option>
                      <option value="distilled">Distilled</option>
                    </select>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Quantity (Litres)</label>
                    <input
                      type="number"
                      min="1"
                      className="form-control"
                      required
                      value={form.quantity_litres}
                      onChange={(e) => setForm({ ...form, quantity_litres: e.target.value })}
                    />
                  </div>
                </div>

                <div className="mb-3 mt-2">
                  <label className="form-label">Delivery Address</label>
                  <textarea
                    rows={2}
                    className="form-control"
                    required
                    value={form.delivery_address}
                    onChange={(e) => setForm({ ...form, delivery_address: e.target.value })}
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Preferred Delivery Date</label>
                  <input
                    type="date"
                    className="form-control"
                    value={form.preferred_date}
                    onChange={(e) => setForm({ ...form, preferred_date: e.target.value })}
                  />
                </div>

                {err && <div className="alert alert-danger py-2 small">{err}</div>}
                <button className="btn btn-wn" disabled={busy}>
                  {busy ? 'Placing…' : 'Place Request'}
                </button>
              </form>
            </div>
          </div>

          <div className="col-lg-4">
            <div className="wn-card">
              <h6>Tips</h6>
              <ul className="small text-muted">
                <li>Quantities over 1000 L trigger tanker delivery.</li>
                <li>Suppliers with 4★+ rating are flagged as Pro.</li>
                <li>You can cancel only while the order is still pending.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
