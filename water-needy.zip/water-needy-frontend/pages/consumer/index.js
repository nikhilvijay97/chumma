import { useEffect, useState } from 'react';
import Link from 'next/link';
import Layout from '../../components/Layout';
import StatCard from '../../components/StatCard';
import StatusBadge from '../../components/StatusBadge';
import OrdersChart from '../../components/OrdersChart';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function ConsumerDashboard() {
  const { user } = useRequireAuth('consumer');
  const [stats, setStats] = useState({ total_orders: 0, pending_orders: 0, delivered_orders: 0 });
  const [orders, setOrders] = useState([]);
  const [notifs, setNotifs] = useState([]);

  useEffect(() => {
    if (!user) return;
    api.get('/consumer/dashboard/').then((r) => setStats(r.data)).catch(() => {});
    api.get('/consumer/orders/').then((r) => setOrders(r.data.results || r.data || [])).catch(() => {});
    api.get('/core/notifications/').then((r) => setNotifs((r.data || []).slice(0, 5))).catch(() => {});
  }, [user]);

  const byStatus = ['pending', 'approved', 'assigned', 'on_the_way', 'delivered', 'cancelled'].map((s) => ({
    name: s,
    count: orders.filter((o) => o.status === s).length,
  }));

  return (
    <Layout title="Consumer Dashboard">
      <section className="container py-4">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h2 className="section-title mb-0">Welcome, {user?.username}!</h2>
            <small className="text-muted">Track and request water deliveries.</small>
          </div>
          <Link href="/consumer/request-water" className="btn btn-wn">
            <i className="bi bi-plus-circle me-2"></i>Request Water
          </Link>
        </div>

        <div className="row g-3 mb-4">
          <div className="col-md-4"><StatCard label="Total Orders" value={stats.total_orders} icon="bag-fill" /></div>
          <div className="col-md-4"><StatCard label="Pending" value={stats.pending_orders} icon="hourglass-split" /></div>
          <div className="col-md-4"><StatCard label="Delivered" value={stats.delivered_orders} icon="check-circle-fill" /></div>
        </div>

        <div className="row g-4">
          <div className="col-lg-7">
            <div className="wn-card">
              <h5 className="mb-3">Recent Orders</h5>
              {orders.length === 0 ? (
                <div className="text-muted small">No orders yet. <Link href="/consumer/request-water">Place one</Link>.</div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-sm align-middle">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Water</th>
                        <th>Qty (L)</th>
                        <th>Total</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.slice(0, 10).map((o) => (
                        <tr key={o.id}>
                          <td>#{o.id}</td>
                          <td className="text-capitalize">{o.water_type}</td>
                          <td>{o.quantity_litres}</td>
                          <td>₹{o.total_amount}</td>
                          <td><StatusBadge status={o.status} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          <div className="col-lg-5">
            <div className="wn-card">
              <h6>Orders by Status</h6>
              <OrdersChart
                kind="doughnut"
                labels={byStatus.map((s) => s.name)}
                data={byStatus.map((s) => s.count)}
              />
            </div>

            <div className="wn-card">
              <h6><i className="bi bi-bell-fill text-warning me-2"></i>Notifications</h6>
              {notifs.length === 0 ? (
                <div className="small text-muted">All caught up!</div>
              ) : (
                <ul className="list-unstyled small mb-0">
                  {notifs.map((n) => (
                    <li key={n.id} className="border-bottom py-2">
                      <strong>{n.title}</strong>
                      <div className="text-muted">{n.message}</div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
