import { useEffect, useState } from 'react';
import Link from 'next/link';
import Layout from '../../components/Layout';
import StatusBadge from '../../components/StatusBadge';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function ConsumerOrdersPage() {
  const { user } = useRequireAuth('consumer');
  const [orders, setOrders] = useState([]);
  const [filter, setFilter] = useState('all');

  const load = () => {
    api.get('/consumer/orders/').then((r) => setOrders(r.data.results || r.data || []));
  };
  useEffect(() => { if (user) load(); }, [user]);

  const cancel = async (id) => {
    if (!confirm('Cancel this order?')) return;
    await api.post(`/consumer/orders/${id}/cancel/`);
    load();
  };

  const filtered = filter === 'all' ? orders : orders.filter((o) => o.status === filter);

  return (
    <Layout title="My Orders">
      <section className="container py-4">
        <div className="d-flex justify-content-between mb-3">
          <h2 className="section-title mb-0">My Orders</h2>
          <Link href="/consumer/request-water" className="btn btn-wn">
            <i className="bi bi-plus me-2"></i>New Request
          </Link>
        </div>

        <div className="mb-3 d-flex gap-2 flex-wrap">
          {['all', 'pending', 'approved', 'on_the_way', 'delivered', 'cancelled'].map((f) => (
            <button
              key={f}
              className={`btn btn-sm ${filter === f ? 'btn-wn' : 'btn-wn-outline'}`}
              onClick={() => setFilter(f)}
            >
              {f.replaceAll('_', ' ')}
            </button>
          ))}
        </div>

        <div className="wn-card">
          {filtered.length === 0 ? (
            <div className="text-muted small">No orders to show.</div>
          ) : (
            <div className="table-responsive">
              <table className="table align-middle">
                <thead>
                  <tr>
                    <th>Order #</th>
                    <th>Water</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Address</th>
                    <th>Supplier</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((o) => (
                    <tr key={o.id}>
                      <td>#{o.id}</td>
                      <td className="text-capitalize">{o.water_type}</td>
                      <td>{o.quantity_litres} L</td>
                      <td>₹{o.total_amount}</td>
                      <td className="small">{o.delivery_address}</td>
                      <td>{o.supplier_name || '-'}</td>
                      <td><StatusBadge status={o.status} /></td>
                      <td>
                        {o.status === 'pending' && (
                          <button className="btn btn-sm btn-outline-danger" onClick={() => cancel(o.id)}>
                            Cancel
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}
