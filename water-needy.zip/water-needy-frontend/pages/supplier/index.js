import { useEffect, useState } from 'react';
import Link from 'next/link';
import Layout from '../../components/Layout';
import StatCard from '../../components/StatCard';
import OrdersChart from '../../components/OrdersChart';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function SupplierDashboard() {
  const { user } = useRequireAuth('supplier');
  const [stats, setStats] = useState({ inventory_count: 0, active_orders: 0, revenue: 0 });
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    if (!user) return;
    api.get('/supplier/dashboard/').then((r) => setStats(r.data));
    api.get('/supplier/orders/').then((r) => setOrders(r.data || []));
  }, [user]);

  const byType = ['mineral', 'ro', 'tanker', 'distilled'].map((t) => ({
    type: t,
    count: orders.filter((o) => o.water_type === t).length,
  }));

  return (
    <Layout title="Supplier Dashboard">
      <section className="container py-4">
        <h2 className="section-title">Supplier Console</h2>
        <div className="row g-3 mb-4">
          <div className="col-md-4"><StatCard label="Inventory Items" value={stats.inventory_count} icon="boxes" /></div>
          <div className="col-md-4"><StatCard label="Active Orders" value={stats.active_orders} icon="hourglass" /></div>
          <div className="col-md-4"><StatCard label="Revenue (₹)" value={`₹${stats.revenue.toLocaleString()}`} icon="currency-rupee" /></div>
        </div>

        <div className="row g-4">
          <div className="col-lg-7">
            <div className="wn-card">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h5 className="mb-0">Pending Requests</h5>
                <Link href="/supplier/orders" className="btn btn-sm btn-wn-outline">View All</Link>
              </div>
              {orders.filter((o) => o.status === 'pending').length === 0 ? (
                <div className="text-muted small">No pending requests right now.</div>
              ) : (
                <ul className="list-unstyled mb-0">
                  {orders.filter((o) => o.status === 'pending').slice(0, 5).map((o) => (
                    <li key={o.id} className="border-bottom py-2 d-flex justify-content-between">
                      <div>
                        <strong>#{o.id}</strong> — {o.consumer_name} · {o.quantity_litres}L {o.water_type}
                      </div>
                      <Link href="/supplier/orders" className="btn btn-sm btn-wn">Review</Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
          <div className="col-lg-5">
            <div className="wn-card">
              <h6>Order Mix</h6>
              <OrdersChart kind="bar" labels={byType.map((t) => t.type)} data={byType.map((t) => t.count)} />
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
