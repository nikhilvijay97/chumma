import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import StatusBadge from '../../components/StatusBadge';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function SupplierOrdersPage() {
  const { user } = useRequireAuth('supplier');
  const [orders, setOrders] = useState([]);
  const [drivers, setDrivers] = useState([]);

  const load = () => api.get('/supplier/orders/').then((r) => setOrders(r.data || []));
  useEffect(() => {
    if (!user) return;
    load();
    api.get('/supplier/drivers/available/').then((r) => setDrivers(r.data || []));
  }, [user]);

  const approve = async (id) => { await api.post(`/supplier/orders/${id}/approve/`); load(); };
  const reject = async (id) => { await api.post(`/supplier/orders/${id}/reject/`); load(); };
  const assign = async (id, driverId) => {
    await api.post(`/supplier/orders/${id}/assign-driver/`, { driver_id: parseInt(driverId, 10) });
    load();
  };

  return (
    <Layout title="Supplier Orders">
      <section className="container py-4">
        <h2 className="section-title">Order Management</h2>
        <div className="wn-card">
          {orders.length === 0 ? (
            <div className="text-muted small">No orders yet.</div>
          ) : (
            <div className="table-responsive">
              <table className="table align-middle">
                <thead>
                  <tr>
                    <th>#</th><th>Consumer</th><th>Type</th><th>Qty</th>
                    <th>Total</th><th>Status</th><th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((o) => (
                    <tr key={o.id}>
                      <td>#{o.id}</td>
                      <td>{o.consumer_name}</td>
                      <td className="text-capitalize">{o.water_type}</td>
                      <td>{o.quantity_litres} L</td>
                      <td>₹{o.total_amount}</td>
                      <td><StatusBadge status={o.status} /></td>
                      <td>
                        {o.status === 'pending' && (
                          <>
                            <button className="btn btn-sm btn-success me-1" onClick={() => approve(o.id)}>Approve</button>
                            <button className="btn btn-sm btn-outline-danger" onClick={() => reject(o.id)}>Reject</button>
                          </>
                        )}
                        {o.status === 'approved' && (
                          <div className="d-flex gap-1">
                            <select className="form-select form-select-sm" id={`drv-${o.id}`}>
                              <option value="">Driver…</option>
                              {drivers.map((d) => (
                                <option key={d.id} value={d.id}>{d.full_name} ({d.vehicle_number})</option>
                              ))}
                            </select>
                            <button className="btn btn-sm btn-wn" onClick={() => {
                              const v = document.getElementById(`drv-${o.id}`).value;
                              if (v) assign(o.id, v);
                            }}>Assign</button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}
