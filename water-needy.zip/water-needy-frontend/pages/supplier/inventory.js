import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

const EMPTY = { water_type: 'mineral', description: '', price_per_litre: 30, available_litres: 100 };

export default function SupplierInventoryPage() {
  const { user } = useRequireAuth('supplier');
  const [items, setItems] = useState([]);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);

  const load = () => api.get('/supplier/inventory/').then((r) => setItems(r.data || []));
  useEffect(() => { if (user) load(); }, [user]);

  const submit = async (e) => {
    e.preventDefault();
    if (editing) {
      await api.put(`/supplier/inventory/${editing}/`, form);
    } else {
      await api.post('/supplier/inventory/', form);
    }
    setForm(EMPTY);
    setEditing(null);
    load();
  };

  const edit = (it) => {
    setEditing(it.id);
    setForm({
      water_type: it.water_type,
      description: it.description,
      price_per_litre: it.price_per_litre,
      available_litres: it.available_litres,
    });
  };

  const del = async (id) => {
    if (!confirm('Delete this SKU?')) return;
    await api.delete(`/supplier/inventory/${id}/`);
    load();
  };

  return (
    <Layout title="Inventory">
      <section className="container py-4">
        <h2 className="section-title">Inventory</h2>
        <div className="row g-4">
          <div className="col-lg-5">
            <div className="wn-card">
              <h6>{editing ? 'Edit SKU' : 'Add new SKU'}</h6>
              <form onSubmit={submit}>
                <div className="mb-2">
                  <label className="form-label small">Water Type</label>
                  <select className="form-select" value={form.water_type}
                    onChange={(e) => setForm({ ...form, water_type: e.target.value })}>
                    <option value="mineral">Mineral</option>
                    <option value="ro">RO</option>
                    <option value="tanker">Tanker</option>
                    <option value="distilled">Distilled</option>
                  </select>
                </div>
                <div className="mb-2">
                  <label className="form-label small">Description</label>
                  <input className="form-control" value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })} />
                </div>
                <div className="row g-2">
                  <div className="col-6">
                    <label className="form-label small">Price / L</label>
                    <input type="number" className="form-control" value={form.price_per_litre}
                      onChange={(e) => setForm({ ...form, price_per_litre: e.target.value })} />
                  </div>
                  <div className="col-6">
                    <label className="form-label small">Available (L)</label>
                    <input type="number" className="form-control" value={form.available_litres}
                      onChange={(e) => setForm({ ...form, available_litres: e.target.value })} />
                  </div>
                </div>
                <button className="btn btn-wn mt-3">{editing ? 'Save' : 'Add SKU'}</button>
                {editing && (
                  <button type="button" className="btn btn-link" onClick={() => { setEditing(null); setForm(EMPTY); }}>
                    Cancel
                  </button>
                )}
              </form>
            </div>
          </div>

          <div className="col-lg-7">
            <div className="wn-card">
              <h6>My SKUs</h6>
              <table className="table table-sm align-middle">
                <thead>
                  <tr>
                    <th>Water</th><th>Description</th><th>Price</th><th>Stock</th><th></th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((it) => (
                    <tr key={it.id}>
                      <td className="text-capitalize">{it.water_type}</td>
                      <td className="small">{it.description}</td>
                      <td>₹{it.price_per_litre}</td>
                      <td>{it.available_litres} L</td>
                      <td>
                        <button className="btn btn-sm btn-wn-outline me-1" onClick={() => edit(it)}>Edit</button>
                        <button className="btn btn-sm btn-outline-danger" onClick={() => del(it.id)}>Delete</button>
                      </td>
                    </tr>
                  ))}
                  {items.length === 0 && (
                    <tr><td colSpan={5} className="text-muted small text-center">No SKUs yet.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
