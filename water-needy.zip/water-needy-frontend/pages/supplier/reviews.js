import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { useRequireAuth } from '../../hooks/useRequireAuth';

export default function SupplierReviewsPage() {
  const { user } = useRequireAuth('supplier');
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    if (!user) return;
    api.get('/supplier/reviews/').then((r) => setReviews(r.data || []));
  }, [user]);

  return (
    <Layout title="Customer Reviews">
      <section className="container py-4">
        <h2 className="section-title">Customer Reviews</h2>
        <div className="wn-card">
          {reviews.length === 0 ? (
            <div className="text-muted small">No reviews yet.</div>
          ) : (
            <ul className="list-unstyled mb-0">
              {reviews.map((r) => (
                <li key={r.id} className="border-bottom py-3">
                  <div className="d-flex justify-content-between">
                    <strong>{r.consumer_name}</strong>
                    <span className="text-warning">
                      {'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}
                    </span>
                  </div>
                  <small className="text-muted">{new Date(r.created_at).toLocaleString()}</small>
                  <div>{r.comment || <em className="text-muted small">(no comment)</em>}</div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </Layout>
  );
}
