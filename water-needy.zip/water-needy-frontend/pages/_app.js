import '../styles/globals.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { AuthProvider } from '../context/AuthContext';

export default function MyApp({ Component, pageProps }) {
  return (
    <AuthProvider>
      <Component {...pageProps} />
    </AuthProvider>
  );
}
