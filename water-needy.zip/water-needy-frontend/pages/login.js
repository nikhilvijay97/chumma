import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import Layout from '../components/Layout';
import { useAuth } from '../context/AuthContext';
import { dashboardPath } from '../utils/auth';

export default function LoginPage() {
  const { login, user } = useAuth();
  const router = useRouter();
  const [form, setForm] = useState({ username: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [showForgot, setShowForgot] = useState(false);
  const [forgot, setForgot] = useState({ username: '', email: '', new_password: '' });

  useEffect(() => {
    if (user) router.replace(dashboardPath(user.role));
  }, [user, router]);

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    setBusy(true);
    try {
      const u = await login(form.username, form.password);
      router.push(dashboardPath(u.role));
    } catch (e) {
      setErr(e?.response?.data?.detail || 'Invalid credentials.');
    } finally {
      setBusy(false);
    }
  };

  const submitForgot = async (e) => {
    e.preventDefault();
    setErr('');
    try {
      await (await import('../utils/api')).default.post('/accounts/forgot-password/', forgot);
      setShowForgot(false);
      setErr('');
      alert('Password reset! Please log in with your new password.');
    } catch (e) {
      setErr('No matching user with that username + email.');
    }
  };

  return (
    <Layout title="Login">
      <section className="container py-5">
        <div className="row justify-content-center">
          <div className="col-md-6 col-lg-5">
            <div className="wn-card">
              <h3 className="mb-4">
                <i className="bi bi-box-arrow-in-right text-primary me-2"></i>
                Login
              </h3>
              {!showForgot ? (
                <form onSubmit={submit}>
                  <div className="mb-3">
                    <label className="form-label">Username</label>
                    <input
                      className="form-control"
                      required
                      value={form.username}
                      onChange={(e) => setForm({ ...form, username: e.target.value })}
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Password</label>
                    <input
                      type="password"
                      className="form-control"
                      required
                      value={form.password}
                      onChange={(e) => setForm({ ...form, password: e.target.value })}
                    />
                  </div>
                  {err && <div className="alert alert-danger py-2 small">{err}</div>}
                  <button className="btn btn-wn w-100" disabled={busy}>
                    {busy ? 'Signing in…' : 'Sign In'}
                  </button>
                  <div className="d-flex justify-content-between mt-3 small">
                    <button
                      type="button"
                      className="btn btn-link p-0"
                      onClick={() => setShowForgot(true)}
                    >
                      Forgot password?
                    </button>
                    <Link href="/register">Create account</Link>
                  </div>
                  <hr />
                  <p className="small text-muted mb-2">Demo credentials:</p>
                  <ul className="small text-muted">
                    <li><code>admin / admin123</code></li>
                    <li><code>alice / consumer123</code></li>
                    <li><code>aquapure / supplier123</code></li>
                    <li><code>dravi / driver123</code></li>
                  </ul>
                </form>
              ) : (
                <form onSubmit={submitForgot}>
                  <h5>Forgot Password</h5>
                  <div className="mb-2">
                    <input className="form-control" placeholder="Username" required
                      onChange={(e) => setForgot({ ...forgot, username: e.target.value })} />
                  </div>
                  <div className="mb-2">
                    <input className="form-control" type="email" placeholder="Email" required
                      onChange={(e) => setForgot({ ...forgot, email: e.target.value })} />
                  </div>
                  <div className="mb-3">
                    <input className="form-control" type="password" placeholder="New Password" required
                      onChange={(e) => setForgot({ ...forgot, new_password: e.target.value })} />
                  </div>
                  {err && <div className="alert alert-danger py-2 small">{err}</div>}
                  <button className="btn btn-wn w-100">Reset Password</button>
                  <button
                    type="button"
                    className="btn btn-link w-100 mt-2"
                    onClick={() => setShowForgot(false)}
                  >
                    Back to login
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
