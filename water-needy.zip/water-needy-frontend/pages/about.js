import Layout from '../components/Layout';

export default function AboutPage() {
  return (
    <Layout title="About">
      <section className="container py-5">
        <div className="row align-items-center g-5">
          <div className="col-lg-6">
            <h2 className="section-title">About Water-Needy</h2>
            <p className="text-muted">
              Water-Needy was born out of a simple observation: in many cities,
              water delivery is fragmented, unreliable, and expensive. Our
              platform brings every stakeholder onto one tech-driven network.
            </p>
            <ul className="list-unstyled mt-3">
              <li className="mb-2"><i className="bi bi-check-circle-fill text-success me-2"></i>Verified suppliers & drivers</li>
              <li className="mb-2"><i className="bi bi-check-circle-fill text-success me-2"></i>Transparent order tracking & payments</li>
              <li className="mb-2"><i className="bi bi-check-circle-fill text-success me-2"></i>Fair ratings & reviews</li>
              <li className="mb-2"><i className="bi bi-check-circle-fill text-success me-2"></i>Admin-monitored compliance</li>
            </ul>
          </div>
          <div className="col-lg-6">
            <img
              src="https://images.unsplash.com/photo-1502740479091-635887520276?auto=format&fit=crop&w=1200&q=70"
              alt="Water delivery"
              className="img-fluid rounded shadow"
            />
          </div>
        </div>

        <div className="row g-4 mt-5">
          <div className="col-md-6">
            <div className="wn-card">
              <h5><i className="bi bi-bullseye text-primary me-2"></i>Our Mission</h5>
              <p className="mb-0 text-muted">
                Ensure every household has access to clean, affordable water —
                delivered reliably by trusted local suppliers.
              </p>
            </div>
          </div>
          <div className="col-md-6">
            <div className="wn-card">
              <h5><i className="bi bi-eye text-primary me-2"></i>Our Vision</h5>
              <p className="mb-0 text-muted">
                Build India's most trusted water-connect network, city by city,
                with technology that benefits every participant in the chain.
              </p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
