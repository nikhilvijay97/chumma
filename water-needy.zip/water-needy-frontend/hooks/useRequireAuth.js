import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../context/AuthContext';

/**
 * Redirect to /login if the user isn't signed in — and optionally enforce a role.
 * Usage:
 *   const { user } = useRequireAuth('supplier');
 */
export function useRequireAuth(requiredRole = null) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace('/login');
      return;
    }
    if (requiredRole && user.role !== requiredRole) {
      router.replace('/');
    }
  }, [loading, user, requiredRole, router]);

  return { user, loading };
}
