import { createContext, useContext, useEffect, useState } from 'react';
import {
  currentUser,
  isAuthenticated as hasToken,
  loginRequest,
  logoutLocal,
  registerRequest,
} from '../utils/auth';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setUser(hasToken() ? currentUser() : null);
    setLoading(false);
  }, []);

  const login = async (username, password) => {
    const u = await loginRequest(username, password);
    setUser(u);
    return u;
  };

  const register = async (payload) => {
    await registerRequest(payload);
  };

  const logout = () => {
    logoutLocal();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
