/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Allow calls to Django at a different origin (dev server)
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: 'http://localhost:8000/api/:path*',
      },
    ];
  },
};

module.exports = nextConfig;
