#!/usr/bin/env bash
# Launch both the Django backend and Next.js frontend in development.
# Use this after you have run:
#   cd backend && pip install -r requirements.txt
#   python manage.py migrate && python manage.py seed_data
# AND
#   cd frontend && npm install
set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"

cd "$ROOT/backend"
echo "→ Starting Django on http://localhost:8000"
python manage.py runserver 0.0.0.0:8000 &
BACK_PID=$!

cd "$ROOT/frontend"
echo "→ Starting Next.js on http://localhost:3000"
npm run dev &
FRONT_PID=$!

trap "kill $BACK_PID $FRONT_PID 2>/dev/null || true" EXIT
echo "Both servers running. Press Ctrl-C to stop."
wait
