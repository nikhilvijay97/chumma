# Water-Needy — Installation Guide

A complete full-stack mini project for the Water Connect platform built with:

- **Frontend:** Next.js 14 · React 18 · Bootstrap 5 · Chart.js
- **Backend:** Django 4.2 · DRF · SimpleJWT (JWT Auth + RBAC)
- **Database:** SQLite (`db.sqlite3`)

The repository ships with **two folders**:
- `backend/` — Django REST API
- `frontend/` — Next.js client

A `run_dev.sh` script is provided to start both servers together.

---

## 1. Prerequisites

- Python 3.10+
- Node.js 18+
- `git`, `pip`, `npm`

## 2. Backend Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate     # Windows: venv\Scripts\activate
pip install -r requirements.txt

python manage.py makemigrations
python manage.py migrate
python manage.py seed_data   # populates sample admin / consumer / supplier / driver

python manage.py runserver   # http://localhost:8000
```

## 3. Frontend Setup

```bash
cd frontend
npm install
npm run dev                  # http://localhost:3000
```

## 4. One-shot launcher

```bash
bash run_dev.sh
```

## 5. Demo credentials

| Role | Username | Password |
| --- | --- | --- |
| Admin | `admin` | `admin123` |
| Consumer | `alice` | `consumer123` |
| Supplier | `aquapure` | `supplier123` |
| Driver | `dravi` | `driver123` |

> Additional sample users: `bob`, `carol` (consumers); `hydroflow`, `clearwater` (suppliers); `drajay` (driver). All use the same password pattern.

## 6. Architecture

```
┌──────────────────┐  HTTP (JSON + JWT)
│  Next.js client  │ ─────────────────┐
└──────────────────┘                  ▼
                       ┌──────────────────────────────┐
                       │  Django REST Framework API   │
                       │  · accounts (auth, profile)  │
                       │  · consumer / supplier       │
                       │  · driver / admin_panel      │
                       │  · core (notifications, etc) │
                       └──────────────────────────────┘
                                       │
                                       ▼
                              ┌────────────────┐
                              │ SQLite (db.sqlite3) │
                              └────────────────┘
```

## 7. Testing the JWT flow manually

```bash
# Obtain a token
curl -X POST http://localhost:8000/api/accounts/login/ \
     -H 'Content-Type: application/json' \
     -d '{"username":"alice","password":"consumer123"}'

# Use it
TOKEN="eyJ…"
curl http://localhost:8000/api/consumer/dashboard/ \
     -H "Authorization: Bearer $TOKEN"
```

## 8. Project Structure

```
water-needy/
├── backend/
│   ├── manage.py
│   ├── requirements.txt
│   ├── water_needy/        ← Django project
│   ├── apps/
│   │   ├── accounts/       ← User model + JWT auth
│   │   ├── consumer/       ← Consumer endpoints
│   │   ├── supplier/       ← Inventory + order approval
│   │   ├── driver/         ← Delivery flow
│   │   ├── admin_panel/    ← Admin actions
│   │   └── core/           ← Shared models: WaterRequest, Payment, Review, Notification, Complaint
│   ├── media/              ← Uploads (profile pics, docs)
│   └── README.md
├── frontend/
│   ├── pages/              ← Every page in the app
│   ├── components/         ← Layout, NavBar, StatCard, OrdersChart…
│   ├── context/            ← AuthContext
│   ├── hooks/              ← useRequireAuth
│   ├── styles/             ← Custom Bootstrap palette
│   ├── utils/              ← api.js, auth.js
│   ├── package.json
│   └── README.md
├── run_dev.sh              ← One-shot launcher
└── INSTALLATION.md         ← This file
```

## 9. Notes for Submissions

- The codebase is fully commented for an MCA mini project submission.
- All dependencies pinned in `requirements.txt` & `package.json`.
- Sample data is reproducible via the Django `seed_data` command.
- The system supports end-to-end demo flows without any external payments /
  email / SMS gateway (those are stubbed with realistic in-app behaviour).
